# Source helpers:
# ********************** Ceros consecutivos ****************************

library(rhandsontable)

# Preparar texto svg para gr\xE1fica de consumo 12 meses en popup  -----------------
texto.popup <- function(l) {
  l[is.na(l)] <- 0  # reemplazar NA por 0
  x0 <- 2
  espacio.vertical = 48
  y0 <- ceiling(max(l))
  escala.vertical = 48 / y0
  colwidth <- 5
  xwidth <- 8
  texto.svg <- ""
  for (i in 1:length(l)) 
  {
    colheight = ceiling(l[i]*escala.vertical)
    texto.svg <- paste0(texto.svg,"<rect y='", espacio.vertical-colheight
                        ,"' x='",x0 + xwidth*(i-1),"' height='",colheight ,"' width='5'"
                        ," style='opacity:1;fill:#008b8a;stroke:#008b8a;' />")
  }
  texto.svg
}


# Funci\xf3n para actualizar controles -----------------------------------------

actualizar.filtros <-
  function (session,
            input,
            atributoCambiado,
            ValoresAtributo,
            valores.atributos, idx) {
    # print(paste0(
    #   'actualizar.filtros: ',
    #   atributoCambiado,
    #   '/',
    #   paste(ValoresAtributo, collapse = ',')
    # ))

    f1 <-
      valores.atributos %>% filter(Atributo == atributoCambiado) %>% filter(Nombre %in% ValoresAtributo)
    
    if (atributoCambiado == "Estrato") {
      idx.filtrado <- idx %>% filter(idx$LlaveEstrato %in% f1$Llave)
    } else     if (atributoCambiado== "Actividad") {
      idx.filtrado <-
        idx %>% filter(idx$LlaveActividadEconomica %in% f1$Llave)
    } else if (atributoCambiado == "Ciclo") {
      idx.filtrado <- idx %>% filter(idx$LlaveCiclo %in% f1$Llave)
    } else if (atributoCambiado == "Circuito") {
      idx.filtrado <- idx %>% filter(idx$LlaveCircuito %in% f1$Llave)
    } else if (atributoCambiado == "Municipio") {
      idx.filtrado <- idx %>% filter(idx$LlaveGeografia %in% f1$Llave)
    }else if (atributoCambiado == "Zona") {
      idx.filtrado <- idx %>% filter(idx$LlaveZona %in% f1$Llave)
    }else if (atributoCambiado == "Transformador") {
      idx.filtrado <- idx %>% filter(idx$LlaveTransformador %in% f1$Llave)
    }
    
    datos.filtrados <- valores.atributos  %>% 
      filter((Atributo=='Zona' & Llave %in% idx.filtrado$LlaveZona) | 
               (Atributo=='Municipio' & Llave %in% idx.filtrado$LlaveGeografia) |
               (Atributo=='Circuito' & Llave %in% idx.filtrado$LlaveCircuito) |
               (Atributo=='Ciclo' & Llave %in% idx.filtrado$LlaveCiclo) |
               (Atributo=='Actividad' & Llave %in% idx.filtrado$LlaveActividad) |
               (Atributo=='Transformador' & Llave %in% idx.filtrado$LlaveTransformador) |
               (Atributo=='Estrato' & Llave %in% idx.filtrado$LlaveEstrato))
    
    # Actualizar controles
    # Actualizar control Estrato
    if (atributoCambiado != "Estrato") {
      valor.seleccionado <- input$estrato
      atr <- valores.atributos %>% filter(Atributo == 'Estrato') %>% filter(Llave %in% idx.filtrado$LlaveEstrato)
      
      updatePickerInput(session,
                        "estrato",
                        choices = c( atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # Actualizar control actividad
    if (atributoCambiado != "Actividad") {
      valor.seleccionado <- input$actividad
      atr <- valores.atributos %>% filter(Atributo == 'Actividad') %>% filter(Llave %in% idx.filtrado$LlaveActividadEconomica)
      
      updatePickerInput(session,
                        "actividad",
                        choices = c( atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # Actualizar control ciclo
    if (atributoCambiado != "Ciclo") {
      valor.seleccionado <- input$ciclo
      atr <- valores.atributos %>% filter(Atributo == 'Ciclo') %>% filter(Llave %in% idx.filtrado$LlaveCiclo)
      
      updatePickerInput(session,
                        "ciclo",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # Actualizar control circuito
    if (atributoCambiado != "Circuito") {
      valor.seleccionado <- input$circuito
      atr <- valores.atributos %>% filter(Atributo == 'Circuito') %>% filter(Llave %in% idx.filtrado$LlaveCircuito)
      
      updatePickerInput(session,
                        "circuito",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # actualizar control municipio
    if (atributoCambiado != "Municipio") {
      valor.seleccionado <- input$municipio
      atr <- valores.atributos %>% filter(Atributo == 'Municipio') %>% filter(Llave %in% idx.filtrado$LlaveGeografia)
      
      #updateSelectInput(session,
      updatePickerInput(session,
                        "municipio",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    # Actualizar control zona
    if (atributoCambiado != "Zona") {
      valor.seleccionado <- input$zona
      atr <- valores.atributos %>% filter(Atributo == 'Zona') %>% filter(Llave %in% idx.filtrado$LlaveZona)
      
      updatePickerInput(session,
                        "zona",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    # Actualizar control transformador
    if (atributoCambiado != "Transformador") {
      valor.seleccionado <- input$transformador
      atr <- valores.atributos %>% filter(Atributo == 'Transformador') %>% filter(Llave %in% idx.filtrado$LlaveTransformador)
      
      updatePickerInput(session,
                        "transformador",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
  

    
  }


# Funci\xf3n para transformar vista de un objeto rhandsontable con primera columna de hiperv\xednculo a
# un data frame

transf.rhand <- function(obj.hand.table){
  ordenes<-hot_to_r(obj.hand.table)                                 # Almacena informaci\xf3n de la tabla en dataframe temporal
  ordenes$CodigoPuntoConsumo <- as.character(ordenes$CodigoPuntoConsumo)
  # quitar comentario cuando se reimplemente link para llamar hoja de vida
  # for(i in 1:nrow(ordenes)){                                      # Extrae el número de cliente del hiperv\xednculo
  #   pos.cliente <- gregexpr(">",ordenes$CodigoPuntoConsumo[i])
  #   pos.cliente <- pos.cliente[[1]][1] + 1
  #   fin.cad <- nchar(ordenes$CodigoPuntoConsumo[i]) - 4
  #   ordenes$CodigoPuntoConsumo[i] <- substr(ordenes$CodigoPuntoConsumo[i],pos.cliente,fin.cad)
  # }
  ordenes
  
}

# Funciones para alternar entre 'true' y 'false' en un objeto rhandsontable

cambia.true.false <-function(obj.rhandsont){
  text.json <-obj.rhandsont$x$data      
  text.json <-gsub( ":true",":false",text.json)  # Cambia 'true' por 'false'
  obj.rhandsont$x$data <- text.json
  return(obj.rhandsont)
}

cambia.false.true <-function(obj.rhandsont){
  text.json <-obj.rhandsont$x$data 
  text.json <-gsub( ":false",":true",text.json) # Cambia 'false' por 'true'
  obj.rhandsont$x$data <- text.json
  return(obj.rhandsont)
}

# Estilo Aubergine mapa JSON ---------------------------------------------------

estilo.map01 <-
  
  '[
    {
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#8ec3b9"
        }
        ]
    },
    {
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1a3646"
        }
        ]
    },
    {
      "featureType": "administrative.country",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#4b6878"
        }
        ]
    },
    {
      "featureType": "administrative.land_parcel",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#64779e"
        }
        ]
    },
    {
      "featureType": "administrative.province",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#4b6878"
        }
        ]
    },
    {
      "featureType": "landscape.man_made",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#334e87"
        }
        ]
    },
    {
      "featureType": "landscape.natural",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#023e58"
        }
        ]
    },
    {
      "featureType": "poi",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#283d6a"
        }
        ]
    },
    {
      "featureType": "poi",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#6f9ba5"
        }
        ]
    },
    {
      "featureType": "poi",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "featureType": "poi.park",
      "elementType": "geometry.fill",
      "stylers": [
        {
          "color": "#023e58"
        }
        ]
    },
    {
      "featureType": "poi.park",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#3C7680"
        }
        ]
    },
    {
      "featureType": "road",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#304a7d"
        }
        ]
    },
    {
      "featureType": "road",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#98a5be"
        }
        ]
    },
    {
      "featureType": "road",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#2c6675"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#255763"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#b0d5ce"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#023e58"
        }
        ]
    },
    {
      "featureType": "transit",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#98a5be"
        }
        ]
    },
    {
      "featureType": "transit",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "featureType": "transit.line",
      "elementType": "geometry.fill",
      "stylers": [
        {
          "color": "#283d6a"
        }
        ]
    },
    {
      "featureType": "transit.station",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#3a4762"
        }
        ]
    },
    {
      "featureType": "water",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#0e1626"
        }
        ]
    },
    {
      "featureType": "water",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#4e6d70"
        }
        ]
    }
    ]'

# Estilo mapa Retro JSON  ------------------------------------------------------------

estilo.map02 <-

'[
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#ebe3cd"
      }
      ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#523735"
      }
      ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#f5f1e6"
      }
      ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#c9b2a6"
      }
      ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#dcd2be"
      }
      ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#ae9e90"
      }
      ]
  },
  {
    "featureType": "landscape.natural",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "poi",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#93817c"
      }
      ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#a5b076"
      }
      ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#447530"
      }
      ]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f5f1e6"
      }
      ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#fdfcf8"
      }
      ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f8c967"
      }
      ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#e9bc62"
      }
      ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#e98d58"
      }
      ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#db8555"
      }
      ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#806b63"
      }
      ]
  },
  {
    "featureType": "transit.line",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "transit.line",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#8f7d77"
      }
      ]
  },
  {
    "featureType": "transit.line",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#ebe3cd"
      }
      ]
  },
  {
    "featureType": "transit.station",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "water",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#b9d3c2"
      }
      ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#92998d"
      }
      ]
  }
  ]'