# =============================================================================
#          Análisis Predictivo Probabilidad de Fraude y Recuperación
# =============================================================================
# 
# =============================================================================

# Carga de librerías ------------------------------------------------------
options(useFancyQuotes = FALSE)
library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
library(rhandsontable)  # Visualización tablas
library(htmlwidgets)
library(scales)
library(lubridate)
library(shinydashboard)
library(DT)
library(ggplot2)
library(plotly)         # Graficas dinámicas plotly
library(RCurl)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
#library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(stringr)
require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
#library(rintrojs)       # Presentación de ayuda en pantalla
library(openxlsx)




source("helpers.R")
source("_shared/_filtros.R")
#reactlog_enable()

# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}



# Configuración de bd y código para api google --------------------------------------------------------------
configuracion.conexion <<- 'externalWM' # Sys.getenv("CONEXIONSHINY") #'windows', 'externalENERG' para energuate
#  'GoogleKey' CodigoParametro api google en [DWSRBI_KRONOS].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "SELECT TOP 1 ValorParametro FROM [DWSRBI_KRONOS].[Aux].[Parametros] where EstadoParametro = 1 AND   CodigoParametro = 'GoogleKey'"
api_key <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)
api_key <<- api_key[1,1]


# Contadores y llamadas --------------------------------------------------------------
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante
#api_key <- "AIzaSyAYoARt3zU_arrmeiZmMCjXhLEyRoE7Z2Q"  # Solicitar clave a WM y cambiar
Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')
locale <- Sys.getlocale(category="LC_COLLATE")
if (grepl("Spanish", locale, fixed=TRUE)) {
  separador.csv <<- ';'
} else {
  separador.csv <<- ','
}

# Captura de parámetro para URL servidor shiny -------------
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql<- "SELECT [ValorParametro]  FROM [DWSRBI_KRONOS].[Aux].[Parametros]  WHERE [CodigoParametro] = 'URLshiny'"
URL.servidor.shiny <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
URL.servidor.shiny <- URL.servidor.shiny [1,1]
str.http <<- paste(URL.servidor.shiny,"hvurl/?Codigo=",sep="") # Cadena de llamada para vinculo a hoja de vida




# Captura de campañas disponibles en BD -----------------------------------
cad.sql<- "[dbo].[Leer_Campanas1]"
nom.camp <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom.camp)<-"Nombre"
nom.camp <- nom.camp  %>% filter(!is.na(Nombre))

# cad.sql <- "SELECT DISTINCT [NombreServicio] FROM [Dimension].[Servicio] where codigoservicio > 0  ORDER BY [NombreServicio]"
# nom_servicios <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
# colnames(nom_servicios) <- "Nombre"
# nom_servicios <- nom_servicios   %>% filter(!is.na(Nombre))
# nom_servicios <- c("G. clientes", "PIMT", "Masivos", "Consumos fijos", "Autoproductores")

# Consultar datos de filtros
consultarDatosFiltros(conexion)

# Carga contenido filtros
cargarFiltrosIniciales()

odbcClose(conexion)

anioInicial <- 2018
anioActual <- as.integer(format(Sys.Date(), "%Y"))
mesesInput <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
           'Ago', 'Sep', 'Oct', 'Nov', 'Dic')

dataMeses <- data.frame(mes = mesesInput, numeroMes= c('01','02','03','04','05','06','07','08','09','10','11','12'),stringsAsFactors=FALSE)
periodosInput <- c(seq(anioInicial, anioActual))

# js <- c(
#   "function(el, x){",
#   "  el.on('plotly_legendclick', function(evtData) {",
#   #"  console.log(evtData)  ",
#   "    Shiny.setInputValue('trace', evtData.data[evtData.curveNumber].name+evtData.data[evtData.curveNumber].visible);",
#   #"    Shiny.setInputValue('visibility', evtData.data[evtData.curveNumber].visible);",
#   "  });",
#   #"  el.on('plotly_restyle', function(evtData) {",
#   #"    Shiny.setInputValue('visibility', evtData[0].visible);",
#   #"  });",
#   "}")


# UI ----------------------------------------------------------------------
# ref https://stackoverflow.com/questions/31440564/adding-a-company-logo-to-shinydashboard-header

# font negro para pickerinput
col_list2 <- c("black")
colorspi <- paste0("color:",rep(c('black'),each=10),";")

dbHeader <- dashboardHeader()
dbHeader <- dashboardHeader(title = "Balance de Perdidas",
                            tags$li(div(
                              img(src = 'Kronos.png',
                                  title = "Balance de Perdidas", height = "30px"),
                              style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                              class = "dropdown"),
                            dropdownMenuOutput("MensajeOrdenes"))  # Presenta mensajes en barra de encabezado)

ui = dashboardPage(

  dbHeader,
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 260,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   #introjsUI(),   # Se habilita presentación de ayuda
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   fluidRow( column(width = 12,offset = 0, style='padding:0px;',
                                    box(id = "Comandos", width = 12, 
                                        status = NULL,  
                                        background = "black",
                                        fluidRow( 
                                          column(width = 2,offset = 1,
                                                 actionButton("ReiniciarControles", label = icon("fas fa-sync"),
                                                              style="color: #fff; background-color: #0070ba; border-color: #0070ba"),
                                                 bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                                          ),
                                          column(width = 2,
                                                 offset = 1,
                                                 actionButton("TraerDatos", label = icon("fas fa-play"),
                                                              style="color: #fff; background-color: #0070ba; border-color: #0070ba"), 
                                                 bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                                          )
                                        )
                                        
                                    ),
                                    obtenerFiltrosZona(),
                                    obtenerFiltrosEmpresa(),
                                    box(id = "FiltroLegalizacion", width = 12, status = NULL,  background = "black",
                                        
                                        pickerInput("periodo_ini","Año:",
                                                    choices = periodosInput,
                                                    selected = NULL,
                                                    multiple=T,
                                                    choicesOpt = list(
                                                      style=rep(paste0("color:black;"),length(periodosInput))),
                                                    options = list(
                                                      `none-selected-text` = "Año"
                                                    ))
                                        # pickerInput("meses_ini","Mes:",
                                        #             choices = dataMeses[,c("numeroMes")],
                                        #             selected = NULL,
                                        #             multiple=T,
                                        #             choicesOpt = list(
                                        #               style=rep(paste0("color:black;"),length(mesesInput)),
                                        #               content = dataMeses[,c("mes")]
                                        #             ),
                                        #             options = list(
                                        #               `none-selected-text` = "Mes"
                                        #             ))
                                    )
                                    # obtenerFiltrosDepartamento()
                   )
                   # column(width = 6, offset = 0, style='padding:0px;',
                   #        
                   # )
                   )
  ),
  
  # Body --------------------------------------------------------------------
  ##00828F;
  dashboardBody(    
    tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }
                              .content-wrapper{
                               margin-left: 270px;
                              }
                              #plotSeriesEntradas{
                               margin-top: 32px;
                              }
                              #plotSeriesSalidas{
                               margin-top: 32px;
                              }
                              .dropdown-menu{
                                max-height: 300px !important;
                              }
                              '
                              
    )
    )
    ), # Fin estilo
    
    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel( type = "tabs",           
                 tabPanel("Datos",
                          icon = icon("fas fa-table"),
                          hr(),
                          
                          fluidRow( 
                            box(#height = 420,
                              width = 12,
                              status = "warning",
                              solidHeader = FALSE,
                              title = "Balance de Perdidas",
                              br(),
                              # hidden(div(id = 'test', withSpinner(rHandsontableOutput("datos", height = "600px"),         # Incluir spinner de espera
                              #                                   color = getOption("spinner.color", default = "#0070ba")))
                              # withSpinner(rHandsontableOutput("datos", height = "600px"),         # Incluir spinner de espera
                              #             color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                              #
                              
                            )),
                          hr(),
                          fluidRow(
                            column(width=6,plotlyOutput("plotSeriesPerdidas", height = "236px"),rHandsontableOutput("TablaPerdidas")),
                            column(width=6,plotlyOutput("plotSeriesPerdidasTAM", height = "236px"),rHandsontableOutput("TablaTAM"))
                          ),
                          fluidRow(
                            column(width=6,plotlyOutput("plotSeriesEntradas", height = "236px"),rHandsontableOutput("TablaEntradas")),
                            column(width=6,plotlyOutput("plotSeriesSalidas", height = "236px"),rHandsontableOutput("TablaSalidas"))
                          ),
                          useShinyjs(),
                          textOutput("GraficaEntradas"),
                          tags$head(tags$style("#GraficaEntradas{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaSalidas"),
                          tags$head(tags$style("#GraficaSalidas{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaPerdidas"),
                          tags$head(tags$style("#GraficaPerdidas{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaPerdidasTAM"),
                          tags$head(tags$style("#GraficaPerdidasTAM{color: white;font-size: 20px;font-style: italic;}"))
                 ),
                 tabPanel("Ayuda",
                          icon = icon("fas fa-table"),
                          includeMarkdown("Ayuda.Rmd")
                          
                 ),
                 id="TabsApp"
    )
  )
  #   ,tags$script(
  #     '
  # setTimeout(
  #   function() {
  #     HTMLWidgets.find("#datos").hot.addHook(
  #       "afterColumnSort",
  #       function(){
  #         console.log("sort",this);
  #         Shiny.onInputChange(
  #           "datos_sort",
  #           {
  #             data: this.getData()
  #           }
  #         )
  #       }
  #     )
  #   },
  #   1000
  # )
  # ' 
  #   
  #   )
  
)

# Server ------------------------------------------------------------------

server <- shinyServer(function(input, output, session) { # Importante iniciar con shinyServer para que funcione la ayuda
  
  consulta.activa <<- FALSE
  datos.consulta <- NA
  tipo.grafica <- 'P'
  tabla.datos.valida <- FALSE
  valores_validos_zona <<- NA
  valores_validos_region <<- NA
  valores_validos_centro <<- NA
  valores_validos_Geografia_departamento  <<- NA
  valores_validos_Geografia_municipio <<- NA
  
  valores_validos_estado <<- NA
  valores_validos_tarifa <<- NA
  valores_validos_mercado <<- NA
  
  # Ocultar Botones auxiliares para sincronizar paneles, paneles
  shinyjs::hide("MostrarTabla")
  shinyjs::hide("MostrarMapa")
  

  
  # Ayuda -------------------------------------------------------------------
  
  
  # Cambio de tab ----------------------------------------------------------------------
  observeEvent(input$TabsApp, {
    
    if (input$TabsApp == "Datos") {
      tabla.datos.valida <<- TRUE
    } else if (input$TabsApp == "Mapa") {
      click("MostrarMapa")
    }
  }, ignoreInit = TRUE)
  
  
  # Seleccion de fila en tabla de datos --------------------------------------------------
  observeEvent(
    input$datos_sort
    ,{
      
      xyz <<- input$datos_sort$data
    }
  )
  
  # output$LlavePC <- renderPrint({
  # 
  # })
  
  # Carga de datos a listas desplegables
  manejarEventosFiltros(input, output, session)
  
  # Reinicial controles
  manejarReinicioFiltros(input, output, session)
  

  
  # Hacer consulta basada en valores de filtros  ---------------------------
  observeEvent(input$TraerDatos, {
    
    noHayValores <- FALSE
    condiciones_consulta = " 1>0 " #paste0(" LlaveFecha >= ", fecha_minimo, " ")
    
    if(!is.null(input$periodo_ini)){
        
        ann = ""
        datf <- data.frame()
        # if(!is.null(input$meses_ini)){
        #   f2 <- t(unique(input$meses_ini))
        #   f2 <- paste0(apply(f2, 1, function(x) paste0("'",x,"'")), collapse=",")
        # }
        # 
        
        for(i in 1:length(input$periodo_ini)){
           annio <- input$periodo_ini[i]
           f1 <- t(unique(annio))
           for(j in 1:12){
             if(j <= 9){
               j <- paste0("0",j)
             }
             
             datf <- rbind(datf,paste0(f1,j),stringsAsFactors=FALSE)
           }
        }
        
        f1 <- paste0(apply(datf, 1, function(x) paste0("'",x,"'")), collapse=",")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND be.IdMes IN (",substr(f1,1,stop =1000000L),") "))
        
    }
    
    if(!is.null(input$zona_comercial) || !is.null(input$region)){
      # Construir condiciones de consulta:
      if (seleccion_operativa != "no") {
        if (nrow(valores_validos) == 0) {
          noHayValores <- TRUE
        } else { 
          
          #f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos[c("LlaveZona")]), collapse=",")),1,stop =1000000L)
          #valores_validos <- consulta_zona(seleccion_operativa, valores_ZonaOperativa,input)
          
          f1 <- t(unique(valores_validos_region[c("LlaveZona")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos[c("LlaveZona")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND l.Llavezona IN ( ",substr(f1,1,stop =1000000L)," ) ") )
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND be.REGION IN (select z.CodigoRegion from Dimension.Zona z WHERE z.LlaveZona IN ( ",substr(f1,1,stop =1000000L),")) "))
        }
      }
    }
    
    
    if(!is.null(input$circuitos)){
      if (seleccion_circuito != "no") {
        if (nrow(valores_validos_circuitos) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_circuitos[c("LlaveCircuito")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_circuitos[c("LlaveCircuito")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND l.LlaveCircuito IN ( ",substr(f1,1,stop =1000000L)," ) ") )
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND be.CODIGO_SMT  IN ( select c.codigocircuito from Dimension.Circuito c where c.LlaveCircuito IN (",substr(f1,1,stop =1000000L),")) "))
        }
      }
    }
    
    
    if(!is.null(input$puntofrontera)){
      if (seleccion_puntofrontera != "no") {
        if (nrow(valores_validos_puntofrontera) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_puntofrontera[c("Codigo_Punto_Frontera")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0("'",x,"'")), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_circuitos[c("LlaveCircuito")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND l.LlaveCircuito IN ( ",substr(f1,1,stop =1000000L)," ) ") )
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND be.Cod_PF IN (",substr(f1,1,stop =1000000L),") "))
        }
      }
    }
    
    
    
    # traer valores de ceros
    
    if (noHayValores) {
      showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        "La consulta no genera resultados",
        footer = list(modalButton("OK", icon = icon("fas fa-check"))
        ),
        easyClose =TRUE
      )
      )
    }  else {

      disable("ReiniciarControles")  
      disable("TraerDatos")
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      
      #entradas
      cad.sql<-paste0(" select 
                          IdMes, 
                          sum(Entradas) as Entradas 
                        from Hecho.BalancePerdEntradas be
                        where ",condiciones_consulta," group by IdMes order by IdMes ASC")
      datos.consulta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      ##Salidas
      cad.sql<-paste0("SELECT
                  	   	IdMes, 
                  	   	sum(cpm) as salidas 
                  	   	from Hecho.BalancePerdSalidaCl be
                  	   	where ",condiciones_consulta,"
                	    group by IdMes order by IdMes ASC")
      datos.consultaSalidasCliente <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT
                  	   	IdMes, 
                  	   	sum(Peajes) as salidas
                  	   	from Hecho.BalancePerdSalidaPeajes be
                  	   	where ",condiciones_consulta,"
                	    group by IdMes order by IdMes ASC")
      datos.consultaSalidasPeajes <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT
                  	   	IdMes, 
                  	   	sum(ConsumoAP) as salidas
                  	   	from Hecho.BalancePerdidasSalidaAP be
                  	   	where ",condiciones_consulta,"
                	    group by IdMes order by IdMes ASC")
      datos.consultaSalidasAP <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      #odbcClose(conexion)
      
      dataEntradas <- data.frame(IdMes = datos.consulta$IdMes, Entradas = round(as.numeric(datos.consulta$Entradas), digits = 3) ,stringsAsFactors=FALSE)
      #dataSumEntradas <- dataEntradas %>% group_by(IdMes) %>% summarise(Entradas = round(sum(as.numeric(Entradas)), digits = 3))
      
      
      rvSalidas <- reactiveValues(data = data.frame())
      rvSalidas$data <- rbind(rvSalidas$data, data.frame(IdMes = datos.consultaSalidasCliente$IdMes, Salidas = datos.consultaSalidasCliente$salidas,stringsAsFactors=FALSE))
      rvSalidas$data <- rbind(rvSalidas$data, data.frame(IdMes = datos.consultaSalidasPeajes$IdMes, Salidas = datos.consultaSalidasPeajes$salidas,stringsAsFactors=FALSE))
      rvSalidas$data <- rbind(rvSalidas$data, data.frame(IdMes = datos.consultaSalidasAP$IdMes, Salidas = datos.consultaSalidasAP$salidas,stringsAsFactors=FALSE))
      dataSumSalidas <- rvSalidas$data %>% group_by(IdMes) %>% summarise(Salidas = round(sum(as.numeric(Salidas)), digits = 3))
      
      
      odbcClose(conexion)
      
      datos.consultaEnt <- dataEntradas
      datos.consultaSal <- dataSumSalidas
      
 
      ############# Entradas ######################
      
      if (nrow(datos.consultaEnt ) > 0) {
        
        #shinyjs::show('test')
        
        #output$GraficaEntradas <- renderPrint({
          
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          df_e <- data.frame(month, stringsAsFactors=FALSE)
          
          contador = 0
          contadorDos = 0
          totalRegistros <- nrow(datos.consultaEnt)
          for(k in 1:totalRegistros){
            contador <- contador + 12
            if(k == 1){
              contadorDos <- contadorDos + 1
            }else{
              contadorDos <- contadorDos + 12
            }
            if(contadorDos <= totalRegistros){
              assign(paste0("entradas_",k),datos.consultaEnt$Entradas[contadorDos:contador])
            }
          }
          
          df_e <- cbind(df_e,mget(ls(pattern = "entradas_")))
          
          df_e$month <- factor(df_e$month, levels = df_e[["month"]])
          
          fig_e <- plot_ly(data = df_e)

          # Si filtra año recorre los años seleccionados sino recorre todos
          contCol = 1
          if(!is.null(input$periodo_ini)){
            for(i in 1:length(input$periodo_ini)){
              contCol <- contCol + 1
              tryCatch({  
              dkf <- data.frame(month = df_e[,1], y = df_e[,contCol],stringsAsFactors=FALSE)
              fig_e <- add_trace(fig_e, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = input$periodo_ini[i])
              colnames(df_e)[contCol] <- input$periodo_ini[i]
              }, error = function(e) {
              })
            }
          }else{
            for(i in anioInicial:anioActual){
              contCol <- contCol + 1
              tryCatch({
              dkf <- data.frame(month = df_e[,1], y = df_e[,contCol],stringsAsFactors=FALSE)
              fig_e <- add_trace(fig_e, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = i)
              colnames(df_e)[contCol] <- i
              }, error = function(e) {
              })
            }
          }
          

          fig_e <- fig_e %>% layout(title = "Entradas",
                                xaxis = list(title = "",dtick = "M1",tickangle = 270),
                                yaxis = list (title = "kWh"),
                                font = list(color = "#0070ba"))
          
          fig_e <- fig_e %>% layout(showlegend = TRUE)


          js <- c(
            "function(el, x){",
            "  el.on('plotly_legendclick', function(evtData) {",
            "    Shiny.setInputValue('trace', evtData.data[evtData.curveNumber].name);",
            "  });",
            "  el.on('plotly_restyle', function(evtData) {",
            "    Shiny.setInputValue('visibility', evtData[0].visible);",
            "  });",
            "}")
                    
          fig_e <- fig_e %>% onRender(js)
          output$plotSeriesEntradas <- renderPlotly({fig_e})
          
          #Datos para tabla inferior
          output$TablaEntradas <- renderRHandsontable({
            # print(paste0("Clicked: ", input$trace, 
            #              " --- Visibility: ", input$visibility))
            # #data_frame_mod  <- df_e[df_e$]
            # tab_e <- df_e[,c('month','2018')]
            # print(tab_e)
            colnames(df_e)[1] <- "Año"
            rhandsontable(t(df_e), height = 160, readOnly = TRUE)
          })
    
        
      } else{
        disable("Guardar")                                  # Deshabilita el botón para guardar
        disable("Descargar")
        showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        "La consulta no encuentra datos que cumplan",
        footer = list(modalButton("OK", icon = icon("fas fa-check"))
        ),
        easyClose =TRUE
        ))
      }
      
      
      ############# Salidas ######################
      
      if (nrow(datos.consultaSal) > 0) {
        
        #shinyjs::show('test')
        
        #output$GraficaSalidas <- renderPrint({
          
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          df_s <- data.frame(month,stringsAsFactors=FALSE)
          
          contador = 0
          contadorDos = 0
          totalRegistros <- nrow(datos.consultaSal)
          for(k in 1:totalRegistros){
            contador <- contador + 12
            if(k == 1){
              contadorDos <- contadorDos + 1
            }else{
              contadorDos <- contadorDos + 12
            }
            if(contadorDos <= totalRegistros){
              assign(paste0("salidas_",k),datos.consultaSal$Salidas[contadorDos:contador])
            }
          }
          
          df_s <- cbind(df_s,mget(ls(pattern = "salidas_")))
          
          df_s$month <- factor(df_s$month, levels = df_s[["month"]])
          
          fig_s <- plot_ly(data = df_s)
          
          # Si filtra año recorre los años seleccionados sino recorre todos
          contCol = 1
          if(!is.null(input$periodo_ini)){
            for(i in 1:length(input$periodo_ini)){
              contCol <- contCol + 1
              tryCatch({
              dkf <- data.frame(month = df_s[,1], y = df_s[,contCol],stringsAsFactors=FALSE)
              fig_s <- add_trace(fig_s, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = input$periodo_ini[i])
              colnames(df_s)[contCol] <- input$periodo_ini[i]
              }, error = function(e) {
              })
            }
          }else{
            for(i in anioInicial:anioActual){
              contCol <- contCol + 1
              tryCatch({
              dkf <- data.frame(month = df_s[,1], y = df_s[,contCol],stringsAsFactors=FALSE)
              fig_s <- add_trace(fig_s, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = i)
              colnames(df_s)[contCol] <- i
              }, error = function(e) {
              })
            }
          }
          
          
          fig_s <- fig_s %>% layout(title = "Salidas",
                                xaxis = list(title = "",dtick = "M1",tickangle = 270),
                                yaxis = list (title = "kWh"),
                                font = list(color = "#0070ba"))
          
          fig_s <- fig_s %>% layout(showlegend = TRUE)
          output$plotSeriesSalidas <- renderPlotly({fig_s})
          
          
          #Datos para tabla inferior
          colnames(df_s)[1] <- "Año"
          output$TablaSalidas<- renderRHandsontable({
            rhandsontable(t(df_s), height = 160, readOnly = TRUE)
          })
          
        #})
        
      } else{
        disable("Guardar")                                  # Deshabilita el botón para guardar
        disable("Descargar")
        showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        "La consulta no encuentra datos que cumplan",
        footer = list(modalButton("OK", icon = icon("fas fa-check"))
        ),
        easyClose =TRUE
        ))
      }
      
      ############# Perdidas ######################
      
      if (nrow(datos.consultaSal) > 0 && nrow(datos.consultaEnt ) > 0) {
        
        #shinyjs::show('test')
        
        #output$GraficaPerdidas <- renderPrint({
          
          #Se calculan perdidas
          entradas <- datos.consultaEnt[2]
          salidas <- datos.consultaSal[2]
          Perdidas <- entradas - salidas
          PorcentPerdidas <- round((Perdidas / entradas) * 100, digits = 2)
          dataPerdidas <- data.frame(PorcentPerdidas,stringsAsFactors=FALSE)
          
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          df_p <- data.frame(month,stringsAsFactors=FALSE)
          
          contador = 0
          contadorDos = 0
          totalRegistros <- nrow(dataPerdidas)
          for(k in 1:totalRegistros){
            contador <- contador + 12
            if(k == 1){
              contadorDos <- contadorDos + 1
            }else{
              contadorDos <- contadorDos + 12
            }
            if(contadorDos <= totalRegistros){
              assign(paste0("perdidas_",k),dataPerdidas$Entradas[contadorDos:contador])
            }
          }
          
          df_p <- cbind(df_p,mget(ls(pattern = "perdidas_")))
          
          df_p$month <- factor(df_p$month, levels = df_p[["month"]])

          fig_p <- plot_ly(data = df_p)
          
          # Si filtra año recorre los años seleccionados sino recorre todos
          contCol = 1
          if(!is.null(input$periodo_ini)){
            for(i in 1:length(input$periodo_ini)){
              contCol <- contCol + 1
              tryCatch({
              dkf <- data.frame(month = df_p[,1], y = df_p[,contCol],stringsAsFactors=FALSE)
              fig_p <- add_trace(fig_p, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = input$periodo_ini[i])
              colnames(df_p)[contCol] <- input$periodo_ini[i]
              }, error = function(e) {
              })
            }
          }else{
            for(i in anioInicial:anioActual){
              contCol <- contCol + 1
              tryCatch({
              dkf <- data.frame(month = df_p[,1], y = df_p[,contCol],stringsAsFactors=FALSE)
              fig_p <- add_trace(fig_p, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = i)
              colnames(df_p)[contCol] <- i
              }, error = function(e) {
              })
            }
          }
          
          fig_p <- fig_p %>% layout(title = "Perdidas Mensuales",
                                xaxis = list(title = "",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
          fig_p <- fig_p %>% layout(yaxis = list(ticksuffix = "%"))
          
          fig_p <- fig_p %>% layout(showlegend = TRUE)
          output$plotSeriesPerdidas <- renderPlotly({fig_p})
          
          #Datos para tabla inferior
          colnames(df_p)[1] <- "Año"
          output$TablaPerdidas <- renderRHandsontable({
            rhandsontable(t(df_p), height = 160, readOnly = TRUE) # %>%
              #hot_cols(renderer = "
             #function (instance, td, row, col, prop, value, cellProperties) {
            #   Handsontable.renderers.TextRenderer.apply(this, arguments);
            #      if(row > 0){
            #        td.innerHTML = `${value} %` 
            #      }
            #
            #  }")
          })
          
        #})
        
      } else{
        disable("Guardar")                                  # Deshabilita el botón para guardar
        disable("Descargar")
        showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        "La consulta no encuentra datos que cumplan",
        footer = list(modalButton("OK", icon = icon("fas fa-check"))
        ),
        easyClose =TRUE
        ))
      }
      
      
      ############# Perdidas TAM ######################
      
      if (nrow(datos.consultaSal) > 0 && nrow(datos.consultaEnt ) > 0) {
        
        #shinyjs::show('test')
        
        #output$GraficaPerdidasTAM <- renderPrint({
          #Se calculan perdidas ultimos 12 meses
          ordData <- data.frame(IdMes = datos.consultaEnt$IdMes,entradas = as.numeric(datos.consultaEnt$Entradas),salidas = as.numeric(datos.consultaSal$Salidas),stringsAsFactors=FALSE)
          dataPerdidasTAM <- arrange(ordData,desc(IdMes))
           
          dataframeMeses <- data.frame(IdMes = datos.consultaEnt$IdMes, totalEntrada = 0, totalSalida = 0, porcentajePerdTam = 0,stringsAsFactors=FALSE)
          
          #se ordena el data frame por el ultimo año y mes
          dataframeMesesOrden <- arrange(dataframeMeses, desc(IdMes))
          
          #se suma las entradas y salidas de los ultimos 12 meses a partir del ultimo año y mes
          contador = 11
          totalRegistros <- nrow(dataframeMesesOrden)
          for(k in 1:totalRegistros){
            contador <- contador + 1
            if(contador <= totalRegistros){
              dataframeMesesOrden$totalEntrada[k:contador] <- sum(dataPerdidasTAM$entradas[k:contador])
              dataframeMesesOrden$totalSalida[k:contador] <- sum(dataPerdidasTAM$salidas[k:contador])
            }else{
              dataframeMesesOrden$totalEntrada[k:totalRegistros] <- sum(dataPerdidasTAM$entradas[k:totalRegistros])
              dataframeMesesOrden$totalSalida[k:totalRegistros] <- sum(dataPerdidasTAM$salidas[k:totalRegistros])
            }
          }

          dataframeMesesOrden$porcentajePerdTam <- round((1 - (dataframeMesesOrden$totalSalida / dataframeMesesOrden$totalEntrada)) * 100, digits = 2)
          TablaPerdidasTAM <- arrange(dataframeMesesOrden, IdMes)


          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')

          
          df_ptam <- data.frame(month,stringsAsFactors=FALSE)
          
          contador = 0
          contadorDos = 0
          totalRegistros <- nrow(TablaPerdidasTAM)
          for(k in 1:totalRegistros){
            contador <- contador + 12
            if(k == 1){
              contadorDos <- contadorDos + 1
            }else{
              contadorDos <- contadorDos + 12
            }
            if(contadorDos <= totalRegistros){
              assign(paste0("perdidasT_",k),TablaPerdidasTAM$porcentajePerdTam[contadorDos:contador])
            }
          }
          
          df_ptam <- cbind(df_ptam,mget(ls(pattern = "perdidasT_")))
          
          df_ptam$month <- factor(df_ptam$month, levels = df_ptam[["month"]])

          fig_ptm <- plot_ly(data = df_ptam)
          
          # Si filtra año recorre los años seleccionados sino recorre todos
          contCol = 1
          if(!is.null(input$periodo_ini)){
            for(i in 1:length(input$periodo_ini)){
              contCol <- contCol + 1
              tryCatch({
              dkf <- data.frame(month = df_ptam[,1], y = df_ptam[,contCol],stringsAsFactors=FALSE)
              fig_ptm <- add_trace(fig_ptm, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = input$periodo_ini[i])
              colnames(df_ptam)[contCol] <- input$periodo_ini[i]
              }, error = function(e) {
              })
            }
          }else{
            for(i in anioInicial:anioActual){
              contCol <- contCol + 1
              tryCatch({
              dkf <- data.frame(month = df_ptam[,1], y = df_ptam[,contCol],stringsAsFactors=FALSE)
              fig_ptm <- add_trace(fig_ptm, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = i)
              colnames(df_ptam)[contCol] <- i
              }, error = function(e) {
              })
            }
          }

          fig_ptm <- fig_ptm %>% layout(title = "Pérdidas TAM",
                                xaxis = list(title = "",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))

          fig_ptm <- fig_ptm %>% layout(yaxis = list(ticksuffix = "%"))

          fig_ptm <- fig_ptm %>% layout(showlegend = TRUE)
          output$plotSeriesPerdidasTAM <- renderPlotly({fig_ptm})
          # 
          colnames(df_ptam)[1] <- "Año"
          #newTable <- t(df_ptam)
          output$TablaTAM <- renderRHandsontable({
            rhandsontable(t(df_ptam), height = 160, readOnly = TRUE) # %>%
              #hot_cols(renderer = "
             #function (instance, td, row, col, prop, value, cellProperties) {
              # Handsontable.renderers.TextRenderer.apply(this, arguments);
               #   if(row > 0){
              #      td.innerHTML = `${value} %` 
              #    }

              #}")
          })
        #})
        
      } else{
        disable("Guardar")                                  # Deshabilita el botón para guardar
        disable("Descargar")
        showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        "La consulta no encuentra datos que cumplan",
        footer = list(modalButton("OK", icon = icon("fas fa-check"))
        ),
        easyClose =TRUE
        ))
      }
      
      
      
      shinyjs::enable("ReiniciarControles")
      shinyjs::enable("TraerDatos")
    }
    
  }, ignoreInit = TRUE)
  
  # Presentación del mapa --------------------------------------------------- 
  # output$map <- renderGoogle_map({
  #   if (exists("tabla.datos")) {
  #     mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta, FALSE, tabla.datos.valida, input) #, datos.imagen, input)
  #   }
  # })
  
  # Cambiar tipo de gráfica  ----------------------------------------
  observeEvent(input$selec.graf,{
    
    valorSwitch <- input$selec.graf
    if (valorSwitch == TRUE) {
      tipo.grafica <<- 'B'
      output$plot <- renderPlotly({
        p <- ggplot(tabla.datos, mapping = aes(x = AcumuladoConsumoCero)) +
          geom_bar(color ="#0070ba",fill= "#0070ba",size =1) + theme_bw()+
          ylab("Conteo") +
          xlab("Períodos consecutivos en cero")
        # Manejo de selección en gráfica
        obj <- data.grafica()$sel
        if(nrow(obj)!=0) {
          p <- p + geom_bar(data=obj,color="orange",fill="orange")
        }
        ggplotly(p,source="master")
      })
    } else {
      tipo.grafica <<- 'P'
      output$plot <- renderPlotly({
        p <-
          ggplot(tabla.datos,
                 mapping = aes(x = AcumuladoConsumoCero, y = PromedioActiva6CN, text = texto)) +
          geom_point(color = "#0070ba", size = 1) + theme_bw() +
          ylab("Consumo promedio 6 meses anteriores [kWh]") +
          xlab("Períodos consecutivos en cero")
        
        # Manejo de selección en gráfica
        obj <- data.grafica()$sel
        if(nrow(obj)!=0) {
          p <- p + geom_point(data=obj,color="orange")
        }
        ggplotly(p, source = "master")
      })
    }
  }, ignoreInit = TRUE)
  
  
})



# Ejecutar aplicación -----------------------------------------------------


shinyApp(ui = ui, server = server)