# *****************************************************************************
#                            Explorador de datos
# *****************************************************************************
# 
# Autor:                Nelson Beltrán Celis
# Fecha de creación:    24.06.2020
# Versión:              0.1

# Carga de librerías ------------------------------------------------------

library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos

# Creación tabla de referencia --------------------------------------------

Explorador <- c("Inspecciones",
 #               "Anomalías",
 #               "Aumento de facturación",
 #               "Corte y reconexión",
                "Facturación"
 #               "PQR",
 #               "Macromedidores"
                )

Desc <- c(  "Permite analizar los volúmenes de inspecciones disponibles en la base de datos. No cambiar el valor de *Cant. Insp.",
#            "Permite analizar los volúmenes de irregularidades identificadas en inspecciones y laboratorio de medidores.",
#            "Permite analizar los resultados de aumento de facturación.",
#            "Permite analizar los volúmenes de operaciones de corte y reconexión.",
            "Permite analizar cifras consolidadas de la facturación. No cambiar el valor de *Energía activa [kWh]."
 #           "Permite analizar los volúmenes de actividades de peticiones, quejas y reclamos.",
 #           "Permite analizar cifras consolidadas de macromedición."
            )

Tabla <- c("Aux.ExploradorInspecciones",
#           "Trabajo.ExploradorAnomalias",
#           "Trabajo.ExploradorAumento",
#           "Trabajo.ExploradorCorteRcx",
           "Aux.ExploradorFacturacion"
#           "Trabajo.ExploradorPQR",
#           "Trabajo.ExploradorMacromedidores"
            )

#Nombres <- c('c("*Cant. Insp.","Año","Periodo","Representa fraude","Representa pérdida","Campaña","Estrato","Ciclo","Circuito","NT","Subestación","Contratista","Zona","Municipio","Ubic. medidor","Mont. medidor","Servicio")',
Nombres <- c('c("*Cant. Insp.","Resultado","Periodo","Zona","Región","Departamento","Municipio","Circuito")',
#             'c("*Cant. anom.","Nombre","Tipo","Proceso","Municipio","Representa fraude","Representa pérdida","Ubic. medidor","Mont. medidor","Servicio","Año","Periodo")',
#             'c("*Aumento [kWh]","Periodo de ejecución","Año de ejecución","Periodo de aumento","Año de aumento","Estrato","Municipio","Circuito", "Campaña")',
#             'c("*Cant. de cortes","*Días de corte","Zona","Estrato","Año de corte","Periodo de corte","Tipo de corte","Municipio","Ubic. medidor","Mont. medidor", "Fases","Año de reconex.","Periodo de reconex.", "Sin reconexión")',
             'c("*Consumo [kWh]","Periodo",  "Zona", "Region","Departamento", "Municipio", "Circuito")'
#             'c("*Cant. de solicitudes","Tipo de PQR", "Canal","Ciclo", "Estrato","Municipio","Servicio", "NT","Zona", "Año", "Periodo")',
 #            'c("*Cant. de macromed.","*Energía activa[kWh]", "*Energía reactiva[kVARh]", "*Cant. Usuarios", "Año", "Periodo", "Estado", "Subestación", "Circuito", "Municipio", "Ciclo",  "Zona", "Factor", "Pot.Trafo [kVA]")'
)

Medidas <- c('*Cant. Insp.',
#             '*Cant. anom.',
#             '*Aumento [kWh]',
#             '*Cant. de cortes,*Días de corte',
             '*Consumo [kWh]'
#             '*Cant. de solicitudes',
 #            '*Cant. de macromed., *Energía activa[kWh], *Energía reactiva[kVARh], *Cant. Usuarios'
             )

rows <- c('c("Zona")',
#          'c("Representa pérdida")',
#          'c("Año de ejecución","Periodo de ejecución")',
#          'c("Sin reconexión","Estrato")',
          'c("Zona")'
#          'c("Estrato", "Canal")',
#          'c("Subestación")'
          )

cols <- c('c("Periodo","Resultado")',
#          'c("Año","Periodo")',
#          'c("Periodo de aumento","Año de aumento")',
#          'c("Año de corte","Periodo de corte")',
          'c("Periodo")'
#          'c("Año","Periodo")',
#          'c("Año","Periodo")'
)

renderName <- c('c("Tabla con barras")',
#                'c("Line Chart")',
#                'c("Heatmap por columnas")',
#                'c("Heatmap por columnas")',
                'c("Tabla con barras")'
#                'c("Heatmap por filas")',
#                'c("Line Chart")'
                )

aggregatorName <-c('c("Suma de enteros")',
#                   'c("Suma de enteros")',
#                   'c("Suma de enteros")',
#                   'c("Suma de enteros")',
                   'c("Suma")'
#                   'c("Suma de enteros")',
#                   'c("Suma de enteros")'
                   )

vals <- c('c("*Cant. Insp.")',
#         'c("*Cant. anom.")',
#          'c("*Aumento [kWh]")',
#          'c("*Cant. de cortes")',
          'c("*Consumo [kWh]")'
#          'c("*Cant. de solicitudes")',
#          'c("*Cant. de macromed.")'
          )

urlinfo <- c("www/Explorador_Inspecciones.html",
#             "www/Explorador_Anomalias.html",
#             "www/Explorador_Aumento.html",
#             "www/Explorador_CorteRcx.html",
             "www/Explorador_Facturacion.html"
#             "www/Explorador_PQR.html",
#             "www/Explorador_Macro.html"
             )


referencia <- data.frame("Explorador" = Explorador,
                         "Desc" = Desc,
                         "Tabla"	= Tabla,
                         "Nombres" = Nombres,
                         "Medidas" = Medidas,
                         "rows" = rows,
                         "cols" = cols,
                         "renderName" = renderName,
                         "aggregatorName" = aggregatorName,
                         "vals" = vals,
                         "urlinfo" = urlinfo)

