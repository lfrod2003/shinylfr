# *****************************************************************************
#                            Explorador de datos
# *****************************************************************************
# 
# Autor:                Nelson Beltrán Celis
# Fecha de creación:    24.06.2020
# Versión:              0.1
# Descripción:
# Reporte para explorar dinámicamente las tablas de hechos de la base de datos
# empleando tablas pivote
#
# Tablas de consulta directa: 
# Tablas en las que escribe: 
# Procedimientos almacenados relacionados:
#
# *****************************************************************************

# Carga de librerías ------------------------------------------------------

library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(rpivotTable)
library(shiny)
library(shinydashboard)
library(rhandsontable)  # Visualización tablas
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(openxlsx)       # Exportar archivos excel

library(shinyBS)        # Utilizada para mostrar tooltip
# library(plotly)

source("helpers.R")

Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')

# Variables inciales y llamadas--------------------------------------------------------------
# Conexión Base de datos
configuracion.conexion <<- configuracion.conexion <<- 'externalWM'  ## Sys.getenv("CONEXIONSHINY") 


# Inicio UI ----------------------------------------------------------------------
# font negro para pickerinput
col_list2 <- c("black")
colorspi <- paste0("color:",rep(c('black'),each=10),";")

dbHeader <- dashboardHeader()
dbHeader <- dashboardHeader(title = "Explorador de datos",
                            tags$li(div(
                              img(src = 'Kronos.png',
                                  title = "Ceros consecutivos", height = "30px"),
                              style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                              class = "dropdown"),
                            dropdownMenuOutput("MensajeOrdenes"))  # Presenta mensajes en barra de encabezado)

ui = dashboardPage( 
  
  # dashboardHeader(
  #   # title = div(tags$a(img(src="Logo cortados.png", height=60)),
  #   #             style = "position: relative; top: -5px;"), # Navigation bar
  #   title = "Explorador de datos",
  #   
  #   titleWidth = 300,
  #   
  #   tags$li(class = "dropdown",            # Presenta vínculo para 'Tour'
  #           tags$li(class = "dropdown", actionLink("ayuda", textOutput("Tour")))),
  #   
  #   dropdownMenuOutput("MensajePivot")  # Presenta mensajes en barra de encabezado
  # ),
  dbHeader,
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 300,
                   
                   useShinyjs(),
                   
                   #introjsUI(),   # Se habilita presentación de ayuda
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   br(),

                   box(id = "filtros", width = 12, status = NULL,  background = "black",
                        
                        selectInput("fuente","Modelo seleccionado:",
                                    choices = referencia$Explorador,
                                    selected = "Inspeccion",
                                    multiple = FALSE)
                       ),
                   box(id = "cajainfo",
                       title = tags$h4(tags$img(src="info_blanco.svg" ,alt="" ,width="16", height="16"),"Información",style="color: #FFFFFF"),  
                       solidHeader = TRUE,
                       background ="blue",
                       collapsible = TRUE,
                       width = 12,
                       height = "220px",
                       helpText(tags$h5(uiOutput("textoinfo01"),style ="color: #FFFFFF"),
                                tags$em(uiOutput("textoinfo02"),style ="color: #FFFFFF")
                                )
                       # helpText(uiOutput("textoprueba"))
                       )
                   ),
  
  # Body --------------------------------------------------------------------
  
  dashboardBody(    
    tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }
                              .dataTables_wrapper .dataTables_scroll div.dataTables_scrollBody>table>tbody>tr>td {
                                white-space: nowrap;
                              }'
                              
    )
    )
    ), # Fin estilo
    
    fluidRow(tags$strong("__",style="color: #FFF"),
             actionButton(inputId = "mostrarinfo",
                          label = "Dimensiones y medidas",
                          width = "180px",
                          icon = icon("info"),
                          class = "mb3 btn-primary f4 f5-ns small-caps",
                          style="color: #fff; background-color: #0070ba; border-color: #0070ba"
                          ),
             bsTooltip("mostrarinfo", "Definición de dimensiones y medidas que pueden ser exploradas", placement = "right", trigger = "hover", options = list(container = "body")),

             # downloadButton('Descargar','Descargar csv', 
             #                style="width:180px;color: #fff; background-color: #0070ba; border-color: #0070ba"),
             # bsTooltip("Descargar", "Permite descargar información fuente en archivo plano", placement = "right", trigger = "hover", options = list(container = "body")),
             hr()
             ),
    
    # tags$style(type="text/css",".pvtRows, .pvtCols { background: #00828F none repeat scroll 0 0; }" ),
    tags$head(tags$style(type = 'text/css', '#pivot{ overflow-x: scroll;background-color: #F0F2F2;}')),   # Necesario para poder mostrar barras en pivottable
    
    withSpinner(                                                     # Incluir spinner de espera
      rpivotTableOutput("pivot", width = "100%", height = "700px"),
      color = getOption("spinner.color", default = "#0070ba")        # Se definen colores del spinner
      )
    )
)
                

# Inicio server ------------------------------------------------------------------

server <- shinyServer(function(input, output, session) { # Importante iniciar con shinyServer para que funcione la ayuda
  
# Ayuda -------------------------------------------------------------------
  
  output$Tour <- renderText({"Tour" })  # Presenta acceso de ayuda en la cabecera
  
  steps <- reactive(                    # Crea data frame para incluir los temas de ayuda
    data.frame(
      element = c(NA, "#filtros", "#cajainfo", "#mostrarinfo", "#Descargar" , "#pivot"),  # Se incluyen nombres de los objetos
      intro = c(
        "Con la ayuda de este reporte podrá explorar información de diferentes modelos asociados a las fuentes de 
         datos de Smart Recovery.",

        "Utilice la lista desplegable para seleccionar y explorar los modelos disponibles.",
        
        "Identique el modelo seleccionado y las medidas disponibles.",
        
        "Observe las descripción detallada de las medidas y dimensiones disponibles en cada modelo.",
        
        "Descargue los datos fuentes de cada modelo en formato de archivo plano para análisis posteriores.",
        
        "Efectue sus análisis disponiendo en filas y columnas las dimensiones disponibles y consolide
        información para las diferentes medidas, empleando las opciones gráficas y tabulares disponibles."
      )
    )
  )
  
  # observeEvent(input$ayuda, {
  #   introjs(session, options = list("nextLabel"="Siguiente",
  #                                   "prevLabel"="Anterior",
  #                                   "skipLabel"="Salir",
  #                                   "doneLabel"="Terminado",
  #                                   steps=steps())
  #   )
  # })

# Actualiza información panel lateral -------------------------------------------------

  output$textoinfo01 <- renderUI({as.character(subset(referencia, 
                                                      Explorador == input$fuente)$Desc)
    })
  
  output$textoinfo02 <- renderUI({paste("Medidas:",
                                        as.character(subset(referencia, 
                                                            Explorador == input$fuente)$Medidas)
                                        )
  })

# Botón información dimensiones -------------------------------------------

  observeEvent(input$mostrarinfo, {  
    
    showModal(modalDialog(
      includeHTML(path = as.character(subset(referencia, Explorador == input$fuente)$urlinfo)),
      title = tags$p(tags$span(tags$h3(tags$img(src = "info_blanco.svg" ,
                                                alt ="", 
                                                width = "20",
                                                height = "20",
                                                style ="background-color: #0070ba;"),
                                       "Dimensiones y medidas",
                                       style="color: white;background-color: #0070ba;")
                               ),
                     style="text-align: left;"),
      size = "m",
      easyClose = TRUE,
      fade = FALSE,
      footer = modalButton("Cerrar")

    )
    )
  })

# Cargar datos (reactive) -------------------------------------------------

  datos <- reactive({
    
    cad.sql <- paste("SELECT * FROM",
                     as.character(subset(referencia, 
                                         Explorador == input$fuente)$Tabla)
    )
    config <- config::get(config=configuracion.conexion)
    config.conexion <- config$conexion
    conexion <- odbcDriverConnect (config.conexion)
    datos<-sqlExecute(channel = conexion, query = cad.sql,fetch= TRUE,as.is=TRUE)
    odbcClose(conexion)


    nombres <- eval(parse(text =as.character(subset(referencia,Explorador == input$fuente)$Nombres)))
    names(datos) <- nombres
    datos <- datos[,order(nombres)] # Ordenar columnas alfabéticamente
    
    datos
  })

# Mensajes encabezado---------------------------------------------------------------

  output$MensajePivot<- renderMenu({       # Actualiza mensaje en la barra de menú para Ã³rdenes generadas
    
    filasmodelo <- nrow(datos())          # Cuenta filas del modelo con base en la selección
    medidas <- strsplit(as.character(subset(referencia,Explorador == input$fuente)$Medidas), ",")
    medidas <- nrow(as.data.frame(medidas))  # Cuenta medidas del modelo
    dimensiones <- subset(referencia,Explorador == input$fuente)$Nombres
    dimensiones <- length(eval(parse(text =  as.character(dimensiones))))
    dimensiones <- (dimensiones - medidas)
    
    dim.filtradas <- reactive({           # Almacena la lista dimensiones filtradas a partir de función JS de rPivotTable
      input$myPivotData$exclusions
    })
    
    
    dropdownMenu(type = "notifications",   # Si hay puntos sin cooordenadas,indica cuantos son
                 headerText = tags$b("Notificaciones", style ="color: #0070ba;"),
                 icon = icon("info"),
                 notificationItem(
                   text = paste("Medidas sugeridas:",medidas),
                   icon("fas fa-ruler-vertical")
                 ),
                 
                 notificationItem(
                   text = paste("Dimensiones:",dimensiones),
                   icon("fas fa-arrows-alt")
                 ),
                 
                 notificationItem(
                   text = paste("Dim. filtradas:",as.character(length(dim.filtradas()))),
                   icon("fas fa-filter") 
                 ),
                 
                 notificationItem(
                   text = paste("Filas del modelo:",filasmodelo),
                   icon("fas fa-arrows-alt-h")
                 )
    )
  })
  
# Pivot Table -------------------------------------------------------------
  
  output$pivot <- renderRpivotTable({

    rpivotTable(data = datos(),
                width="75%", 
                height="500px",
                rows = eval(parse(text =as.character(subset(referencia,Explorador == input$fuente)$rows))),
                cols = eval(parse(text =as.character(subset(referencia,Explorador == input$fuente)$cols))),
                rendererName = eval(parse(text =as.character(subset(referencia,Explorador == input$fuente)$renderName))),
                aggregatorName = eval(parse(text =as.character(subset(referencia,Explorador == input$fuente)$aggregatorName))),
                vals = eval(parse(text =as.character(subset(referencia,Explorador == input$fuente)$vals))),
                subtotals = FALSE,
                locale = "es",
                
                onRefresh = htmlwidgets::JS("function(config) { Shiny.onInputChange('myPivotData', config); }"),
                
                rendererOptions = list(
                  heatmap = list(
                    colorScaleGenerator = htmlwidgets::JS('function(values) {
                                                          return d3.scale.linear()
                                                          .domain([-35, 0, 35])
                                                          .range(["#77F", "#FFF", "#F77"])}')
                    )
                  )
                )
    })

# Descargar excel -----------------------------------------------------------
  
  output$Descargar <- downloadHandler(
    
    filename = function() { 
      #paste0("Explorador", Sys.Date(), ".csv")
      paste0("Explorador", Sys.Date(), ".xlsx")
    },
    content = function(file) {
     
      wbk <- createWorkbook()
      addWorksheet( wb = wbk,  sheetName = "Datos" )
      addStyle(wbk,sheet = 1, style = createStyle( fontSize = 12, textDecoration = "bold" ), rows = 1:1, cols = 1:ncol(data) )
      writeData(wbk,sheet = 1,data,startRow = 1,startCol = 1 )
      saveWorkbook(wbk, file)
      #write.csv(datos(),file, row.names = FALSE, fileEncoding = "UTF-8")
    },
   # contentType = "csv"
  )
})

# Ejecutar aplicación -----------------------------------------------------

shinyApp(ui = ui, server = server)

