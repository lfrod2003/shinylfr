# =============================================================================
#                    Editor de parámetros Smart Recovery
# =============================================================================
# 
# Autor:                Fernando Rodriguez
# Fecha de creación:    13.04.2020
# Versión:              dffwdssd&&dcs
# Descripción:
#
# Permite editar los valores de parámetros en Smart Recovery BI. Los nuevos valores se 
# validan para el correcto tipo de datos y rango de valores válido (valores numéricos).
#
# Tablas de consulta directa: [DWSRBI_Kronos].[Aux].[Parametros]
# Tablas en las que escribe: [DWSRBI_Kronos].[Aux].[Parametros]
# Procedimientos almacenados relacionados: EXEC [dbo].[DatosParametros]
#
# La tabla [DWSRBI_Kronos].[Aux].[Parametros] contiene los valores de parámetros para el sistema.
# Cuando se cambia el valor de un parámetro, el programa marca el último valor existente como inválido 
# y crea un nuevo registro para el parámetro con el nuevo valor. El editor usa el procedimiento
# [dbo].[DatosParametros] para acceder al último valor (valor válido) para cada parámetro.
#
# Pendientes:  
#  - Depurar el código y eliminar sentencias de control y zonas con comentarios que 
#    ya no se requieren.
#  - Incluir comentarios con la relación de tablas de entrada, de salida y procedimientos
#    relacionados en el encabezado.
#  - Habilitar el botón para guardar cambios solo cuando se hayan efectuado modificaciones 
#    en la tabla de detalle.
#  - Revisar la pertinencia y uso del sombreado en colores, ya que este varía cuando 
#    se reordena la tabla.
#  - Incluir 'Tour' y mensajes en la barra de estado.
#
# =============================================================================


# Parámetros --------------------------------------------------------------

# Ninguno

# Librerias utilizadas ----------------------------------------------------

library(RODBC)
library(RODBCext)
library(config)
#library(formattable)
library(shiny)
library(shinydashboard)
library(rhandsontable)
library(dplyr)
library(jsonlite)
library(dqshiny)
library(shinyBS)
library(gridExtra)
library(htmlTable)
library(magrittr)

library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
    # Presentación de ayuda en pantalla

Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')

# Contadores y llamadas  --------------------------------------------------
configuracion.conexion <<-'externalWM'  # <<- Sys.getenv("CONEXIONSHINY") #'windows'

#Cadena de conexión pc dell:
#cadena.conexion <- "driver={SQL Server};server=192.168.56.1\\SQL2017;database=DWSRBI_Kronos;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" 
config <- config::get(config=configuracion.conexion)
cadena.conexion <- config$conexion

# Otras dependencias ------------------------------------------------------

# Definir funciones javascript

change_hook <- "function(el,x) {
                  var hot = this.hot;  
                  var cellChanges = [];
                  
                  var changefn = function(changes,source) { 
                  if (source === 'edit' || source === 'undo' || source === 'autofill' || source === 'paste') {
                  row = changes[0][0];
                  col = changes[0][1];
                  oldval = changes[0][2];
                  newval = changes[0][3];
                  
                  if (oldval !== newval) {
                  var cell = hot.getCell(row, col);
                  cell.style.background = 'white';  //'pink';
                  cellChanges.push({'rowid':row, 'colid':col});
                  }
                  
                  }
                  }
                  
                  var renderfn = function(isForced) {
                  
                  for(i = 0; i < cellChanges.length; i++)
                  {
                    
                    var rowIndex = cellChanges[i]['rowid'];
                    var columnIndex = cellChanges[i]['colid'];
                    
                    var cell = hot.getCell(rowIndex, columnIndex);
                    cell.style.background = 'white';  //'yellow';
                    
                  }                  
                  
                  }
                  
                  var loadfn = function(initialLoad) {
                  
                  for(i = 0; i < cellChanges.length; i++)
                  {
                    var rowIndex = cellChanges[i]['rowid'];
                    var columnIndex = cellChanges[i]['colid'];
                    
                    var cell = hot.getCell(rowIndex, columnIndex);
                    
                    cell.style.background = 'white';
                    
                  }
                  // retornar cellChanges a input$data
                  Shiny.onInputChange('data', cellChanges);
                  cellChanges = []
                  
                  }
                  
                  hot.addHook('afterChange', changefn);
                  hot.addHook('afterRender', renderfn);
                  hot.addHook('afterLoadData', loadfn);
                  
                  }  "

# Definir rutina trigger de conversión
convertTodataframe <- function(x, session, inputname) {
  as.data.frame(x)
}

#registerInputHandler("change_to_dataframe", convertTodataframe)

# Conexion a bd
conexion <- odbcDriverConnect (cadena.conexion)
tipos.sql <- " [dbo].[UnidadesParametros]"
DataTipos <- sqlExecute(channel = conexion, query = tipos.sql,fetch= T,as.is=T)
familias.sql <- "[dbo].[FamiliasParametros]"
DataFamilias <- sqlExecute(channel = conexion, query = familias.sql,fetch= T,as.is=T)
odbcClose(conexion)

# leer datos y preparar dataframe para despliegue
conexion <- odbcDriverConnect (cadena.conexion)

# Datos de tabla de parámetros
cad.sql<-"EXEC [dbo].[DatosParametros]"
DatosLectTmp <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)
DatosLectTmp$FamiliaParametro[is.na(DatosLectTmp$FamiliaParametro)] <- 'General'
DatosLectTmp$row_uid <- 1:nrow(DatosLectTmp)
#

# Matriz para mensajes de error
MAT_errores <<- matrix(ncol = 1, nrow = nrow(DatosLectTmp))

# Inicio UI ---------------------------------------------------------------

ui <- dashboardPage(skin = "blue", 
                    dashboardHeader(
                      title = "Editor de parámetros",
                      tags$li(div(
                        img(src = 'Kronos.png',
                            title = "Ceros consecutivos", height = "30px"),
                        style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                        class = "dropdown")
                      #titleWidth = 300  #,
                      
                      # Dropmenu ----------------------------------------------------------------
                      # tags$li(class = "dropdown",            # Presenta vínculo para 'Tour'
                      #         tags$li(class = "dropdown", actionLink("ayuda", textOutput("Tour")))),
                      
                      #dropdownMenuOutput("MensajeOrdenes"),  # Presenta mensajes en barra de encabezado para órdenes generadas
                      #dropdownMenuOutput("MensajeMapa"),     # Presenta mensajes en barra de encabezado para novedades en el mapa
                      #dropdownMenuOutput("MensajeInsp")      # Presenta mensajes en barra de encabezado para novedades en operaciones
                    ),
                    
                    # Sidebar -----------------------------------------------------------------
                    
                    dashboardSidebar(width = 300,
                                     
                                   #  introjsUI(),   # * Se habilita presentación de ayuda
                                     
                                     # Codigo para no mostrar errores en interfaz Shiny
                                     tags$style(type="text/css",
                                                ".shiny-output-error { visibility: hidden; }",
                                                ".shiny-output-error:before { visibility: hidden; }"
                                     ),
                                     br(),
                                     box(#title = "Tipo", title="abc"
                                       #title = tags$h4(tags$img(src="listado_blanco.svg" ,alt="" ,width="16", height="16"),"Tipo",style="color: #FFFFFF"),  # Título e ícono
                                       solidHeader = TRUE,
                                       background ="black",
                                       collapsible = TRUE,
                                       width=12,
                                       checkboxGroupInput(inputId	="icons", 
                                                          label = NULL,
                                                          selected = DataFamilias$familia,
                                                          as.list(DataFamilias$familia )
                                       )
                                     ),
                                     textOutput("txt"),
                                     box(#title = "abc", #tags$h4(tags$img(src="info_blanco.svg" ,alt="" ,width="16", height="16"),"Información",style="color: #FFFFFF"),  # Título e ícono
                                         solidHeader = TRUE,
                                         background ="black",
                                         collapsible = TRUE,
                                         width = 12,
                                         height = "180px",
                                         helpText("El editor permite cambiar el valor de 
                                                  los parámetros que se utilizan para efectuar diferentes
                                                  cálculos dentro de Smart Recovery BI.")
                                     ),
                                     
                                     valueBoxOutput(outputId ="cant.parametros",  # Cuadro para presentar el total de parámetros
                                                    width = 12)
                    ),
                    
                    
                    # Body --------------------------------------------------------------------
                    
                    dashboardBody(
                      
                      tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }'
                      )
                      )
                      ),
                      
                      #verbatimTextOutput("DatosModificados", placeholder = TRUE),
                      #tags$h5(tags$img(src="tabla.svg" ,alt="" ,width="16", height="16"),"Detalle",style="color: #00828F"),  # Título e ícono
                      hr(),
                      rHandsontableOutput(outputId ="TablaLect",
                                          height = "420px"),
                      hr(),
                      
                      column(width = 3,
                             offset = 9,
                             actionButton(inputId = "Accion",
                                          label = "Guardar modificaciones",
                                          icon = icon("fas fa-save"),
                                          style="color: #fff; background-color: #0070ba; border-color: #0070ba"
                             )
                      ),
                      
                    )
)

# Inicio Server -----------------------------------------------------------

server <- function(input, output, session) {
  
  # Ayuda -------------------------------------------------------------------
  
  #output$Tour <- renderText({"Tour" })    # Presenta acceso de ayuda en la cabecera
  
  # steps <- reactive(                      # Crea data frame para incluir los temas de ayuda
  #   data.frame(
  #     element = c(NA, "#icons", "#cant.parametros", "#TablaLect", "#Accion", NA, NA, "#ayuda"
  #     ),
  #     intro = c(
  #       "El editor de parámetros permite cambiar los valores usados por defecto en varios análisis y reportes de Smart Recovery.",
  #       "Escoger el tipo de parámetros de interés para editar.",
  #       "Número de parámetros de Smart Recovery editables por usuario.",
  #       "Tabla de parámetros. Solamente la columna 'Valor' es editable. Las otras muestran información de referencia.",
  #       "Botón que permite guardar las modificaciones realizadas. Al hacer click en el botón se muestra un diálogo que describe los cambios rechazados y los pendientes. En este punto puede escogerse entre cancelar los cambios, o guardar los cambios válidos.",
  #       "Al mover el cursor sobre la columna 'Parámetro' de la tabla aparece un cuadro descriptivo del parámetro bajo el cursor.",
  #       "Los parámetros numéricos pueden tener límites de valor mínimos y máximos aceptables. Los valores fuera de ese rango no son aceptados por el editor.",
  #       "Encuentre acá mensajes relativos a la ejecución de cada sesión."
  #     )
  #   )
  # )
  
  # observeEvent(input$ayuda, {
  #   
  #   introjs(session, options = list("nextLabel"="Siguiente",
  #                                   "prevLabel"="Anterior",
  #                                   "skipLabel"="Salir",
  #                                   "doneLabel"="Terminado",
  #                                   steps=steps())
  #   )
  #   
  # })
  
# Variable globales de servidor --------------------------------------------- 
  
  data_f <- ""
  banderaErrores <<- FALSE
  tablaErrores <<- "data.frame"
  valor.icons <<- ""
  
  reset <- reactiveVal(0)
  
  
  # Función para guardar cambios --------------------------------------------
  
  dataModal <- function(failed = FALSE,  dataCambios, dataErrores) {
    
    colnames(dataCambios) <- c("Parámetro", "Valor Anterior", "Nuevo valor")  # * Revisar si no genera error más adelante
    colnames(dataErrores) <- c("Parámetro", "Nuevo valor", "Error")           # * Revisar si no genera error más adelante
    
    modalDialog(
      #title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("Guardar modificaciones"),style="color: #00828F"),style="text-align: center;"),
      easyClose = TRUE,
      "Se guardarán únicamente los cambios efectuados a los parámetros cuyos valores son válidos.",
      hr(),
      
      if (nrow(dataCambios) > 0){     # Valores válidos
        fixedRow(column(width = 12,
                        #tags$h5(tags$img(src="cambio_ok.svg" ,alt="" ,width="16", height="16"),"Valores válidos:",style="color: #00828F"),  # Título e ícono
                        renderTable(dataCambios,
                                    spacing ="xs",
                                    hover = TRUE,
                                    width = '570px',
                                    striped = TRUE)
        )
        )
      },
      
      if (nrow(dataErrores) > 0){     # Valores con error
        fixedRow(column(width = 12,
                        #tags$h5(tags$img(src="error.svg" ,alt="" ,width="16", height="16"),"Valores con error:",style="color: #00828F"),  # Título e ícono
                        renderTable(dataErrores,
                                    spacing = "xs",
                                    hover = TRUE,
                                    width = '570px',
                                    striped = TRUE)
        )
        )
      },
      
      # footer = fluidRow(
      #   column(width=2,footer = tags$div(id="modal1",modalButton("Cancelar", icon = icon("far fa-window-close")))),
      #   column(width=2,actionButton("ok", "Guardar valores válidos", icon = icon("fas fa-save"),
      #                style="color: #fff; background-color: #0070ba; border-color: #0070ba"))
      #   
      # )
      footer = fluidRow(column(width=2, offset=5,tags$div(id="modal1", 
                                                          modalButton("Cancelar", icon = icon("fas fa-table")))),
                        column(width=2,actionButton("ok", "Guardar valores válidos",icon = icon("fas fa-table"),
                                                    style="color: #fff; background-color: #0070ba; border-color: #0070ba"))
      )
    )               # Fin modalDialog
  }                 # Fin función
  
  # Presentación cantidad de parámetros -------------------------------------
  
  output$cant.parametros<- renderValueBox({
    valueBox(
      "Parámetros configurables",
      value =  nrow(DatosLectTmp),
      icon = icon("fas fa-sort-amount-down"),
      color = "blue"
    )
  })
  
  # Actualización tabla de detalle de parámetros ---------------------------------------
  
  output$TablaLect <- renderRHandsontable({

    r = reset()
    
    if (banderaErrores) { #  MAT_errores[1] != 'Sin errores') {
      for (j in 1:nrow(MAT_errores)) {
        if (!is.na(MAT_errores[j]) && nchar(MAT_errores[j])){
          #print(paste0("en render: ",j,": ",MAT_errores[j]))
        }
      }
    }
    txtVal <- input$txt
    iconsAnterior <- valor.icons
    valor.icons <- paste(input$icons, collapse = ", ")
    
    DatosLectdf <- as.data.frame(DatosLectTmp,stringsAsFactors = FALSE)
    
    
    DatosLectdf$FamiliaParametro[is.na(DatosLectdf$FamiliaParametro)] <- 'General'
    v <- strsplit(valor.icons, ', ')
    DatosLect <- DatosLectdf %>% filter(FamiliaParametro %in% unlist(v))
    MAT_comments = matrix(ncol = ncol(DatosLect), nrow = nrow(DatosLect))
    for (i in 1:nrow(DatosLect)) {
      texto <- as.character( DatosLect$DescripcionParametro[[i]]) #DatosDescripcion[i,1]) #paste0("hola\n","Adios")
      MAT_comments[i, 2] = DatosLect$DescripcionParametro[[i]]
    }
    DatosLectDisp <- data.frame(
      'Codigo' = DatosLect$CodigoParametro,
      'Nombre' = DatosLect$NombreParametro,
      'Valor' = DatosLect$ValorParametro,
      'ValorMinimo' = DatosLect$ValorMinimo,
      'ValorMaximo' =DatosLect$ValorMaximo,
      'Unidades' = DatosLect$UnidadesParametro,
      'Impacto' = DatosLect$ReporteImpacto,
      stringsAsFactors = FALSE
    )
    
    rh <<- rhandsontable(DatosLectDisp[,1:6], 
                         comments = MAT_comments,
                         colHeaders = c(
                           'Codigo',
                           'Parámetro',
                           'Valor',
                           'Mínimo',
                           'Máximo',
                           'Unidades'#,
                      #     'Reportes'
                         ),
                         readOnly = F,
                         height= 420)
    
    # restricciones de edición según el tipo
    
    for (i in 1:nrow(DatosLect)) {
      if (DatosLect[i,8] == "String") {
        rh <<- dq_hot_cell(rh,i,4:5,readOnly=TRUE)
      }
      else {
        rh <<- dq_hot_cell(rh,i,3, type='numeric',strict=TRUE)
        
      }
    }
    
    rh <<- hot_col(rh,"Codigo", colWidths = c(0.1)) # readOnly = TRUE)
    rh <<- hot_col(rh,"Parámetro", colWidths =350) 
    #rh <<- hot_col(rh,"Reportes", colWidths =350) 
    rh <<- hot_col(rh, col = c(1,2,4,5,6),  readOnly = TRUE)
    rh <<- hot_cols(rh, fixedcolumnsleft = 2) 
    rh <<- hot_col(rh, col = c(4,5), halign = "htRight", readOnly = TRUE)
    rh <<- hot_col(rh, col = 6, halign = "htCenter", readOnly = TRUE)
    rh <<- hot_col(rh, col = c(3), renderer = "
            function (instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.NumericRenderer.apply(this, arguments);
            td.style.background = 'white';
            }")
    rh <<- hot_context_menu(rh, allowRowEdit = FALSE, allowColEdit = FALSE) # Bloquea opciones de menú contextual
    
    # Incluír mensajes de error
    if (banderaErrores) {
      for (j in 1:nrow(MAT_errores)) {
        if (!is.na(MAT_errores[j]) && nchar(MAT_errores[j]) > 0 ){
          rh <<- hot_cell(rh,j,3, MAT_errores[j])
        }
      }
      
    }
    
    reset(0)
    htmlwidgets::onRender(rh,change_hook)

  })

  
  
  # Guardar cambios en parámetros -------------------------------------------
  
  # salvar contenido de parámetros a tabla tmp.params
  # cuando se oprime boton de salvar
  observeEvent(input$Accion, {
    
    #recuperar contenido de tabla
    banderaErrores <<- FALSE
    data_f <- hot_to_r(input$TablaLect)
    data_f <- data_f %>% filter(!is.na(Codigo))
    
    tablaErrores  <<- data.frame(data_f$Codigo, stringsAsFactors = FALSE)
    tablaErrores <<- mutate(tablaErrores, msgError = "")
    colnames(tablaErrores) <<- c('Codigo', 'msgError')
    for (j in 1:nrow(MAT_errores)) {
      MAT_errores[j] <<- ''
    }
    errCnt <- 0
    
    Cambios <<- DatosLectTmp %>% select(CodigoParametro, NombreParametro, ValorParametro, row_uid)
    Cambios <<- Cambios %>% filter(CodigoParametro %in% data_f$Codigo) #data_f$CodigoParametro)
    Cambios <<- mutate(Cambios, nuevoValor = "", msgError = "", dispRow = 0)
    
    for (i in 1:nrow(data_f)) {
      val <- data_f[i,3]
      minval <- data_f[i,4]
      maxval <- data_f[i,5]
      valoresIniciales <- DatosLectTmp %>% filter(CodigoParametro == data_f[i,1])
      
      Cambios[Cambios$CodigoParametro == valoresIniciales$CodigoParametro,'nuevoValor']= val
      
      errMsg <- ''
      if (val !=valoresIniciales$ValorParametro) {
        if (valoresIniciales$FormatoParametro != 'String') {
          #Validación de valores numéricos
          if (valoresIniciales$FormatoParametro == 'Int') {
            
            intVal <- strtoi(val)
            intMinVal <- strtoi(minval)
            intMaxVal <- strtoi(maxval)
            if (is.na(intVal)) {
              errMsg <- "Valor de parámetro entero es inválido."
              errCnt = errCnt + 1
          #    print(errMsg)
            } else {
              if (!is.na(intMinVal)){
                if(intVal < intMinVal) {
                  errMsg <- "Valor menor a límite inferior."
                  errCnt = errCnt + 1
                  #print(errMsg)
                }
              }
              if (!is.na(intMaxVal)) {
                if (intVal > intMaxVal) {
                  errMsg <- "Valor mayor a límite superior."
                  errCnt = errCnt + 1
                  # print(errMsg)
                }
              }
            }
          }
          if (valoresIniciales$FormatoParametro == 'Numeric') {
            numVal <- as.numeric(val)
            numMinVal <- as.numeric(minval)
            numMaxVal <- as.numeric(maxval)
            if (is.na(numVal)) {
              errMsg <- "Valor de parámetro es inválido."
              errCnt = errCnt + 1
            } else {
              if (!is.na(numMinVal)){
                if(numVal < numMinVal) {
                  errMsg <- "Valor menor a límite inferior."
                  errCnt = errCnt + 1
                }
              }
              if (!is.na(numMaxVal)) {
                if (numVal > numMaxVal) {
                  errMsg <- "Valor mayor a límite superior."
                  errCnt = errCnt + 1
                }
              } 
            }
          }
          
          if (nchar(errMsg) > 0) {
            Cambios[Cambios$CodigoParametro == valoresIniciales$CodigoParametro,'msgError']= errMsg
            tablaErrores[tablaErrores$Codigo == valoresIniciales$CodigoParametro,2 ] <<- errMsg
          #  print(tablaErrores[tablaErrores$Codigo == valoresIniciales$CodigoParametro,] )
            MAT_errores[i] <<- errMsg
            errMsg <- ""
            banderaErrores <<- TRUE
          }
        }
      }
    }
    

    
    dataCambios <<- Cambios %>% filter(msgError == '') %>%
      filter(ValorParametro != nuevoValor) %>%
      subset( ValorParametro != nuevoValor, select = c(NombreParametro, ValorParametro, nuevoValor))
    
    dataErrores <<- Cambios %>% filter(msgError != '') %>%
      filter(ValorParametro != nuevoValor) %>%
      subset( ValorParametro != nuevoValor, select = c(NombreParametro,  nuevoValor, msgError))
    
    # Mostrar diálogo de confirmación
    if(nrow(dataCambios)> 0 || nrow(dataErrores) > 0 ) {
      showModal(dataModal(dataCambios=dataCambios
                          , dataErrores=dataErrores))
    }

  })
  
  # salvar cambios si el usuario oprime botón de salvar en
  # ventana modal
  observeEvent(input$ok, {

    if (nrow(dataCambios) > 0) {
      # Conexion a bd
      conexion <- odbcDriverConnect (cadena.conexion)
      odbcSetAutoCommit(conexion, autoCommit = TRUE)
      
      for (j in 1:nrow(dataCambios)) {

        valoresIniciales <- DatosLectTmp %>% filter(NombreParametro  == dataCambios$NombreParametro[j])
        update.sql <- paste0("update [DWSRBI_Kronos].[Aux].[Parametros] set EstadoParametro = 0 where CodigoParametro = '"
                             ,valoresIniciales$CodigoParametro,"'")        
        
        DataTipos <- sqlExecute(channel = conexion, query = update.sql,fetch= T,as.is=T)
        insert.sql <- paste0("Insert INTO  [DWSRBI_Kronos].[Aux].[Parametros]  SELECT  TOP 1 CodigoParametro, NombreParametro, '"
                             ,dataCambios$nuevoValor
                             ,"', ValorUltimo, ValorMinimo, ValorMaximo, ValorDefecto ,DescripcionParametro"
                             ,", UnidadesParametro, getdate() FechaActualizacionParametro, UsuarioActualiza"
                             ,", FormatoParametro, 1 EstadoParametro, FamiliaParametro, reporteImpacto "
                             ,"FROM [DWSRBI_Kronos].[Aux].[Parametros]  where CodigoParametro = '", valoresIniciales$CodigoParametro,"'" )
        DataTipos <- sqlExecute(channel = conexion, query = insert.sql,fetch= T,as.is=T)
      }
      cad.sql<-"EXEC [dbo].[DatosParametros]"
      DatosLectTmp<<-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      DatosLectTmp$FamiliaParametro[is.na(DatosLectTmp$FamiliaParametro)] <<- 'General'
      DatosLectTmp$row_uid <<- 1:nrow(DatosLectTmp)
      odbcClose(conexion)
    }
    
    removeModal()

    updateTextInput(session = session, inputId 	= "txt", value = dataCambios$nuevoValor)
  })
  
}

shinyApp(ui = ui, server = server)