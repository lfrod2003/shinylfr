# =============================================================================
#                     Gestor de campañas (Lineas)
# =============================================================================

# Carga de librerías ------------------------------------------------------
options(useFancyQuotes = FALSE)
library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
library(rhandsontable)  # Visualización tablas
library(htmlwidgets)
library(scales)
library(lubridate)
library(shinydashboard)
library(DT)
library(ggplot2)
library(plotly)         # Graficas dinámicas plotly
library(RCurl)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
#library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(stringr)
require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
#library(rintrojs)       # Presentación de ayuda en pantalla
library(openxlsx)




source("helpers.R")
source("../_shared/_filtros.R")
#reactlog_enable()

# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}


# Configuración de bd y código para api google --------------------------------------------------------------
configuracion.conexion <<- 'externalWM' # Sys.getenv("CONEXIONSHINY") #'windows', 'externalENERG' para energuate
#  'GoogleKey' CodigoParametro api google en [DWSRBI_KRONOS].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect(config.conexion)


# Contadores y llamadas --------------------------------------------------------------
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante
Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')
locale <- Sys.getlocale(category="LC_COLLATE")
if (grepl("Spanish", locale, fixed=TRUE)) {
  separador.csv <<- ';'
} else {
  separador.csv <<- ','
}




# Captura de campañas disponibles en BD -----------------------------------
cad.sql<- "[dbo].[Leer_Campanas1]"
nom.camp <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom.camp)<-"Nombre"
nom.camp <- nom.camp  %>% filter(!is.na(Nombre))

# Consultar datos de filtros
consultarDatosFiltros(conexion)

# Carga contenido filtros
cargarFiltrosIniciales()

odbcClose(conexion)

periodosInput = c('',format(seq(as.Date("2022-01-01"), today(), by = "months"),"%Y%m"))

# font negro para pickerinput
col_list2 <- c("black")
colorspi <- paste0("color:",rep(c('black'),each=10),";")

ui = dashboardPage(
  dashboardHeader(title = "Gestor de campañas (Lineas)",
                  tags$li(div(
                    img(src = 'Kronos.png',
                        title = "Gestor de campañas (Lineas)", height = "30px"),
                    style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                    class = "dropdown"),
                  dropdownMenuOutput("MensajeOrdenes")),
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 500,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   fluidRow( column(width = 6,offset = 0, style='padding:0px;',
                                    box(id = "Comandos", width = 12, 
                                        status = NULL,  
                                        background = "black",
                                        fluidRow( 
                                              column(width = 2,offset = 1,
                                                         actionButton("ReiniciarControles", label = icon("fas fa-sync"),
                                                                      style="color: #fff; background-color: #0070ba; border-color: #0070ba"),
                                                         bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                                              ),
                                              column(width = 2,
                                                     offset = 1,
                                                     actionButton("TraerDatos", label = icon("fas fa-play"),
                                                                  style="color: #fff; background-color: #0070ba; border-color: #0070ba"), 
                                                     bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                                              )
                                        )
                                        
                                    ),
                                    
                                    box(id = "FiltroLegalizacion", width = 12, status = NULL,  background = "black",
                                        
                                        pickerInput("periodo_ini","Periodo inicial:",
                                                    choices = periodosInput,
                                                    selected = NULL,
                                                    multiple=F,
                                                    choicesOpt = list(
                                                      style=rep(paste0("color:black;"),length(periodosInput))),
                                                    options = list(
                                                      `none-selected-text` = "Periodo inicial"
                                                    )),
                                        
                                        pickerInput("periodo_fin","Periodo final:",
                                                    choices = c(''),
                                                    selected = NULL,
                                                    multiple=F,
                                                    choicesOpt = list(
                                                      style=rep(paste0("color:black;"),length(periodosInput))),
                                                    options = list(
                                                      `none-selected-text` = "Periodo final"
                                                    ))
                                    ),
                                    
                                    obtenerFiltrosZona(),
                                    obtenerFiltrosDepartamento()
                              ),
                             column(width = 6, offset = 0, style='padding:0px;',
                                    obtenerFiltrosEmpresa()
                             ))
  ),
  
  # Body --------------------------------------------------------------------
  ##00828F;
  dashboardBody(    
    tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }'
                              
    )
    )
    ), # Fin estilo

    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel( type = "tabs", 
                              
                 tabPanel("Datos",
                          icon = icon("fas fa-table"),
                          hr(),
                          useShinyjs(),
                          fluidRow( 
                            box(#height = 420,
                              width = 12,
                              status = "warning",
                              solidHeader = FALSE,
                              title = "Gestor de campañas (Lineas)"
                            )),
                          fluidRow(column(width=12,plotlyOutput("grafico1", height = "300px"))),
                          fluidRow(hr()),
                          fluidRow(column(width=12,plotlyOutput("grafico2", height = "300px"))),
                          fluidRow(hr()),
                          fluidRow(column(width=12,plotlyOutput("grafico3", height = "300px"))),
                          fluidRow(hr()),
                          fluidRow(column(width=12,plotlyOutput("grafico4", height = "300px"))),
                          fluidRow(hr()),
                          fluidRow(column(width=12,plotlyOutput("grafico9", height = "300px"))),
                          
                          fluidRow(hr()),
                          fluidRow(hr()),
                          fluidRow(column(width=12,plotlyOutput("grafico5", height = "300px"))),
                          fluidRow(hr()),
                          fluidRow(column(width=12,plotlyOutput("grafico6", height = "300px"))),
                          fluidRow(hr()),
                          fluidRow(column(width=12,plotlyOutput("grafico7", height = "300px"))),
                          fluidRow(hr()),
                          fluidRow(column(width=12,plotlyOutput("grafico8", height = "300px"))),
                          fluidRow(hr()),
                          fluidRow(column(width=12,plotlyOutput("grafico10", height = "300px"))),
                          fluidRow(hr()),
                          textOutput("LlavePC"),
                          tags$head(tags$style("#LlavePC{color: white;
                                 font-size: 20px;
                                 font-style: italic;
                                 }"
                          )
                          )                         
                 ),
                 tabPanel("Ayuda",
                          icon = icon("fas fa-table"),
                          includeMarkdown("Ayuda.md")
                          
                 ),
                 
                 id="TabsApp"
    )
  )
)

# Server ------------------------------------------------------------------
server <- shinyServer(function(input, output, session) {
  
  #click("TraerDatos")
  updatePickerInput(session,"estado",selected = '')
  updatePickerInput(session,"tarifa",selected = '')
  updatePickerInput(session,"mercado",selected = '')
  
  consulta.activa <<- FALSE
  datos.consulta <- NA
  tipo.grafica <- 'P'
  tabla.datos.valida <- FALSE
  valores_validos_zona <<- NA
  valores_validos_region <<- NA
  valores_validos_centro <<- NA
  valores_validos_Geografia_departamento  <<- NA
  valores_validos_Geografia_municipio <<- NA

  valores_validos_estado <<- NA
  valores_validos_tarifa <<- NA
  valores_validos_mercado <<- NA
  
  # Ocultar Botones auxiliares para sincronizar paneles, paneles
  shinyjs::hide("MostrarTabla")
  shinyjs::hide("MostrarMapa")
  
  # Ayuda -------------------------------------------------------------------
  
  # Carga de datos a listas desplegables
  manejarEventosFiltros(input, output, session)
  
  # Reinicial controles
  manejarReinicioFiltros(input, output, session)
  
  observeEvent(input$ReiniciarControles, {
    updatePickerInput(session,"estado",selected = '')
    updatePickerInput(session,"tarifa",selected = '')
    updatePickerInput(session,"mercado",selected = '')
    updatePickerInput(session,"periodo_ini",selected = '')
    updatePickerInput(session,"periodo_fin",selected = '')
  }, ignoreInit = TRUE)
  
  observeEvent(input$periodo_ini, {
    if(input$periodo_ini == ''){
      periodosInputFin <- c('')
    }else{
      periodosInputFin <- periodosInput[periodosInput>=input$periodo_ini]
    }
    updatePickerInput(session,
                      "periodo_fin",
                      choices = periodosInputFin,
                      choicesOpt = list(
                         style=rep("color:black;",length(periodosInputFin)))
                      )
  }, ignoreInit = TRUE, ignoreNULL = F)
  
  observeEvent(input$ReiniciarControles, {
    isolate(
      updatePickerInput(session,
                        "periodo_legal",
                        selected = ''))
    
  }, ignoreInit = TRUE)
  
  
  # Hacer consulta basada en valores de filtros  ---------------------------
  observeEvent(input$TraerDatos, {
    noHayValores <- FALSE
    condiciones_consulta = ' 1>0 '
    
    if(input$periodo_fin!=''){
      condiciones_consulta <- paste0(condiciones_consulta, " AND f.Periodo >= ",input$periodo_ini, " AND f.Periodo <= ",input$periodo_fin)
    }
    
    if(!is.null(input$zona_comercial)){
      # Construir condiciones de consulta:
      if (seleccion_operativa != "no") {
        if (nrow(valores_validos) == 0) {
          noHayValores <- TRUE
        } else { 
      
          #f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos[c("LlaveZona")]), collapse=",")),1,stop =1000000L)
          valores_validos <- consulta_zona(seleccion_operativa, valores_ZonaOperativa,input)
          
          f1 <- t(unique(valores_validos[c("LlaveZona")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos[c("LlaveZona")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.Llavezona IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$region)){
      if (seleccion_geografia != "no") {
        if (nrow(valores_validos_Geografia) == 0) {
          noHayValores <- TRUE
        } else {
          #f1 <- substr(gsub("[\r751:\n]", "",paste0(unique(valores_validos_Geografia[c("LlaveGeografia")]), collapse=",")),1,stop =1000000L)
          valores_validos_Geografia <- consulta_geografia(seleccion_geografia, valores_Geografia,input)
          f1 <- t(unique(valores_validos_Geografia[c("LlaveGeografia")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_Geografia[c("LlaveGeografia")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveGeografia IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$circuitos)){
      if (seleccion_circuito != "no") {
        if (nrow(valores_validos_circuitos) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_circuitos[c("LlaveCircuito")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_circuitos[c("LlaveCircuito")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveCircuito IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$iniciativa)){
      if (seleccion_iniciativa != "no") {
          f1 <- t(unique(valores_validos_iniciativa[c("LlaveCampana")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND c.LlaveCampaña IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    c1 <- ''
    c2 <- ''
    
    if(!is.null(input$cnae)){
      if (seleccion_CNAE != 'no') {
        if (nrow(valores_validos_cnae_division) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_cnae_division[c("LlaveActividadEconomica")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_cnae_division[c("LlaveActividadEconomica")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          c1 <- str_replace(f1, "[)]", "")
          
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND l.LlaveActividadEconomica IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$cnaegrupo)){
      if (seleccion_grupo != 'no') {
        
        if (nrow(valores_validos_CNAEgrupo) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_CNAEgrupo[c("LlaveActividadEconomica")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          f1 <- paste0(gsub(":",",",unique(valores_validos_CNAEgrupo[c("LlaveActividadEconomica")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          c2 <- str_replace(f1, "[)]", "")
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND LlaveActividadEconomica IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$cnaegrupo)){
      # Unificar seleccion_CNAE y seleccion_grupo
      if (seleccion_CNAE != 'no' && seleccion_grupo != 'no') {
        condiciones_CNAE <- gsub("[\r\n]", "",substr(c1,1,stop =1000000L),  
                                                         ",",substr(c2,1,stop =1000000L) )
        condiciones_consulta <- paste0(condiciones_consulta,
                                       " AND l.LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
      } else if (seleccion_CNAE != 'no' ) {
        condiciones_CNAE <- gsub("[\r\n]", "",substr(c1,1,stop =1000000L) )
        condiciones_consulta <- paste0(condiciones_consulta,
                                       " AND l.LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
                                                         
        
      } else if (seleccion_grupo != 'no') {
        condiciones_CNAE<- gsub("[\r\n]", "",substr(c2,1,stop =1000000L) )
        condiciones_consulta <- paste0(condiciones_consulta,
                                       " AND l.LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
      }
    }

    if(!is.null(input$estado)){
      if (seleccion_estado != 'no') {
        ifelse (is.na(valores_validos_estado),
                {
                  lista_seleccion <- input$estado
                  valores_validos_estado <<- valores_Estados %>%
                    filter(valores_Estados$NombreEstado %in% lista_seleccion)
                },NA)  
        if (nrow(valores_validos_estado) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_estado[c("LlaveEstado")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tension[c("Llavetension")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND LlaveEstrato IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$tension)){
      if (seleccion_tension != 'no') {
        if (nrow(valores_validos_tension) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_tension[c("Llavetension")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tension[c("Llavetension")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveTension IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$tarifa)){
      if (seleccion_tarifa != 'no') {
        ifelse (is.na(valores_validos_tarifa),
                {
                  lista_seleccion <- input$tarifa
                  valores_validos_tarifa <<- valores_Tarifa %>%
                    filter(valores_Tarifa$NombreTarifa %in% lista_seleccion)
                } , NA) 
        if (nrow(valores_validos_tarifa) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_tarifa[c("LlaveTarifa")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tarifa[c("LlaveTarifa")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveTarifa IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$mercado)){
      if (seleccion_mercado != 'no') {
        ifelse (is.na(valores_validos_mercado),
                {
                  lista_seleccion <- input$mercado
                  valores_validos_mercado <<- valores_Mercado  %>%
                    filter(valores_Mercado$NombreMercado %in% lista_seleccion)
                } , NA) 
        if (nrow(valores_validos_mercado) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_mercado[c("LlaveMercado")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_mercado[c("LlaveMercado")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveTipoObjeto IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$pimt)){
      if (seleccion_PIMT != 'no') {
  
        if (nrow(valores_validos_PIMT) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_PIMT[c("LlavePIMT")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_PIMT[c("LlavePIMT")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlavePIMT IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$ynormalizacion)){
      if (seleccion_ynormalizacion != 'no') {
        if (nrow(valores_validos_ynormalizacion) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_ynormalizacion[c("Llaveynormalizacion")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          f1 <- paste0(gsub(":",",",unique(valores_validos_ynormalizacion[c("Llaveynormalizacion")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND Llaveynormalizacion IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$habitacion)){
      if(input$habitacion == 'Habitado'){
        condiciones_consulta <- paste0(condiciones_consulta," AND l.Habitado = 1 ")
      }
      if(input$habitacion == 'No habitado'){      
        condiciones_consulta <- paste0(condiciones_consulta," AND l.Habitado = 0 ")
      }
      if(input$habitacion == 'Sin definir'){
        condiciones_consulta <- paste0(condiciones_consulta," AND l.Habitado is NULL ")
      }
    }

    # traer valores de Auditoria de lecturas

      disable("ReiniciarControles")  
      disable("TraerDatos")
      
      
      
      
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      
      cad.sql <- paste0(
        "select c.CodigoCampaña, c.NombreCampaña, c.NombreTipoCampaña, 
            rc.CodigoresultadoCNR, rc.NombreResultadoCNR, Total
        from 
        (select c.LlaveCampaña, rc.LlaveResultadoCNR, count(*) Total
                  	from hecho.Inspeccion i
                  		inner join Dimension.Campaña c on c.LlaveCampaña = i.LlaveCampaña
                  		inner join Dimension.ResultadoCNR rc on rc.LlaveResultadoCNR = i.LlaveResultadoCNR
                  		inner join hecho.Llaves l on i.LlavePuntoConsumo = l.llavePuntoConsumo
                  		inner join Dimension.Fecha f on i.LlaveFechaEjecucion = f.LlaveFecha 
                  	where c.Tipo_generacion in ('Centralizada', 'Control de Calidad', 'Kronos', 'Regional') 
                  		and c.Iniciativa in ('Masivos', 'Mantenimiento AP Masivos')
                        and i.TaskTypeId in (15072, 10212, 15039, 10046, 10033)
                        and (i.UnidadOperativa like 'NM%' OR i.UnidadOperativa is NULL)
                        and ", condiciones_consulta, 
                    "group by c.LlaveCampaña, rc.LlaveResultadoCNR) i
        inner join Dimension.Campaña c on c.LlaveCampaña = i.LlaveCampaña
        inner join Dimension.ResultadoCNR rc on rc.LlaveResultadoCNR = i.LlaveResultadoCNR"
      )
      
      datos.consulta <-sqlExecute(channel = conexion, query = cad.sql, fetch= T, as.is=T)
      
      cad.sql <- paste0(
        "select c.CodigoCampaña, c.NombreCampaña, c.NombreTipoCampaña, cast(sum(ConsumoNormalizadoActivaAumento) as int) Total
        	from hecho.AumentoFacturacion af
        		inner join Dimension.Fecha f on af.llavefecha = f.LlaveFecha 
        		inner join Dimension.Campaña c on af.LlaveCampaña = c.LlaveCampaña 
        		left join Hecho.Llaves l on af.LlavePuntoConsumo = l.llavePuntoConsumo 
          WHERE ", condiciones_consulta, 
          "group by c.CodigoCampaña, c.NombreCampaña, c.NombreTipoCampaña"
      )
      
      datos.consulta2 <-sqlExecute(channel = conexion, query = cad.sql, fetch= T, as.is=T)
      
      odbcClose(conexion)
      
      
      if (nrow(datos.consulta) > 0 && nrow(datos.consulta2) > 0) {
        datos.consulta$Categoria <- paste0(datos.consulta$CodigoCampaña,' - ',datos.consulta$NombreCampaña)
        
        
        CNR1 <- datos.consulta[datos.consulta$CodigoresultadoCNR == "4", ]
        CategoriaCNR1 <- head(CNR1[order(-CNR1$Total),], n=10)$Categoria
        datosCNR1 <- datos.consulta[datos.consulta$Categoria %in% CategoriaCNR1, ] 
        datosCNR1$Label  <- with(datosCNR1, factor(Categoria, levels=rev(CategoriaCNR1)))
        datosCNR1$Estado  <- with(datosCNR1, factor(NombreResultadoCNR, levels=c("NORMALIZADA","FALLIDA","CERRADA","CNR")))
        
        output$grafico1 <- renderPlotly({
          p <- ggplot(datosCNR1, aes(x = Label, y = Total))+
            geom_col(aes(fill = Estado), width = 0.7)+
            coord_flip()+ 
            labs(title = "Top 10 más - CNR", x = "", y = "Total inspecciones", fill = "Estado", subtitle = "s", caption = "a")
        })
        
        
        CNR2 <- datos.consulta[datos.consulta$CodigoresultadoCNR == "3", ]
        CategoriaCNR2 <- head(CNR2[order(-CNR2$Total),], n=10)$Categoria
        datosCNR2 <- datos.consulta[datos.consulta$Categoria %in% CategoriaCNR2, ] 
        datosCNR2$Label  <- with(datosCNR2, factor(Categoria, levels=rev(CategoriaCNR2)))
        datosCNR2$Estado  <- with(datosCNR2, factor(NombreResultadoCNR, levels=c("NORMALIZADA","CERRADA","CNR","FALLIDA")))
        
        output$grafico2 <- renderPlotly({
          p <- ggplot(datosCNR2, aes(x = Label, y = Total))+
            geom_col(aes(fill = Estado), width = 0.7)+
            coord_flip()+ 
            labs(title = "Top 10 más - Fallidas", x = "", y = "Total inspecciones", fill = "Estado")
        })
        
        
        CNR3 <- datos.consulta[datos.consulta$CodigoresultadoCNR == "2", ]
        CategoriaCNR3 <- head(CNR3[order(-CNR3$Total),], n=10)$Categoria
        datosCNR3 <- datos.consulta[datos.consulta$Categoria %in% CategoriaCNR3, ] 
        datosCNR3$Label  <- with(datosCNR3, factor(Categoria, levels=rev(CategoriaCNR3)))
        datosCNR3$Estado  <- with(datosCNR3, factor(NombreResultadoCNR, levels=c("NORMALIZADA","CNR","FALLIDA","CERRADA")))
        
        output$grafico3 <- renderPlotly({
          p <- ggplot(datosCNR3, aes(x = Label, y = Total))+
            geom_col(aes(fill = Estado), width = 0.7)+
            coord_flip()+ 
            labs(title = "Top 10 más - Cerradas", x = "", y = "Total inspecciones", fill = "Estado")
        })
        
        
        CNR4 <- datos.consulta[datos.consulta$CodigoresultadoCNR == "1", ]
        CategoriaCNR4 <- head(CNR4[order(-CNR4$Total),], n=10)$Categoria
        datosCNR4 <- datos.consulta[datos.consulta$Categoria %in% CategoriaCNR4, ] 
        datosCNR4$Label  <- with(datosCNR4, factor(Categoria, levels=rev(CategoriaCNR4)))
        datosCNR4$Estado  <- with(datosCNR4, factor(NombreResultadoCNR, levels=c("CNR","FALLIDA","CERRADA","NORMALIZADA")))
        
        output$grafico4 <- renderPlotly({
          p <- ggplot(datosCNR4, aes(x = Label, y = Total))+
            geom_col(aes(fill = Estado), width = 0.7)+
            coord_flip()+ 
            labs(title = "Top 10 más - Normalizadas", x = "", y = "Total inspecciones", fill = "Estado")
        })
        
        
        CNR5 <- datos.consulta[datos.consulta$CodigoresultadoCNR == "4", ]
        CategoriaCNR5 <- head(CNR5[order(CNR5$Total),], n=10)$Categoria
        datosCNR5 <- datos.consulta[datos.consulta$Categoria %in% CategoriaCNR5, ] 
        datosCNR5$Label  <- with(datosCNR5, factor(Categoria, levels=rev(CategoriaCNR5)))
        datosCNR5$Estado  <- with(datosCNR5, factor(NombreResultadoCNR, levels=c("NORMALIZADA","FALLIDA","CERRADA","CNR")))
        
        output$grafico5 <- renderPlotly({
          p <- ggplot(datosCNR5, aes(x = Label, y = Total))+
            geom_col(aes(fill = Estado), width = 0.7)+
            coord_flip()+ 
            labs(title = "Top 10 menos - CNR", x = "", y = "Total inspecciones", fill = "Estado")
        })
        
        
        CNR6 <- datos.consulta[datos.consulta$CodigoresultadoCNR == "3", ]
        CategoriaCNR6 <- head(CNR6[order(CNR6$Total),], n=10)$Categoria
        datosCNR6 <- datos.consulta[datos.consulta$Categoria %in% CategoriaCNR6, ] 
        datosCNR6$Label  <- with(datosCNR6, factor(Categoria, levels=rev(CategoriaCNR6)))
        datosCNR6$Estado  <- with(datosCNR6, factor(NombreResultadoCNR, levels=c("NORMALIZADA","CERRADA","CNR","FALLIDA")))
        
        output$grafico6 <- renderPlotly({
          p <- ggplot(datosCNR6, aes(x = Label, y = Total))+
            geom_col(aes(fill = Estado), width = 0.7)+
            coord_flip()+ 
            labs(title = "Top 10 menos - Fallidas", x = "", y = "Total inspecciones", fill = "Estado")
        })
        
        
        CNR7 <- datos.consulta[datos.consulta$CodigoresultadoCNR == "2", ]
        CategoriaCNR7 <- head(CNR7[order(CNR7$Total),], n=10)$Categoria
        datosCNR7 <- datos.consulta[datos.consulta$Categoria %in% CategoriaCNR7, ] 
        datosCNR7$Label  <- with(datosCNR7, factor(Categoria, levels=rev(CategoriaCNR7)))
        datosCNR7$Estado  <- with(datosCNR7, factor(NombreResultadoCNR, levels=c("NORMALIZADA","CNR","FALLIDA","CERRADA")))
        
        output$grafico7 <- renderPlotly({
          p <- ggplot(datosCNR7, aes(x = Label, y = Total))+
            geom_col(aes(fill = Estado), width = 0.7)+
            coord_flip()+ 
            labs(title = "Top 10 menos - Cerradas", x = "", y = "Total inspecciones", fill = "Estado")
        })
        
        
        CNR8 <- datos.consulta[datos.consulta$CodigoresultadoCNR == "1", ]
        CategoriaCNR8 <- head(CNR8[order(CNR8$Total),], n=10)$Categoria
        datosCNR8 <- datos.consulta[datos.consulta$Categoria %in% CategoriaCNR8, ] 
        datosCNR8$Label  <- with(datosCNR8, factor(Categoria, levels=rev(CategoriaCNR8)))
        datosCNR8$Estado  <- with(datosCNR8, factor(NombreResultadoCNR, levels=c("CNR","FALLIDA","CERRADA","NORMALIZADA")))
        
        output$grafico8 <- renderPlotly({
          p <- ggplot(datosCNR8, aes(x = Label, y = Total))+
            geom_col(aes(fill = Estado), width = 0.7)+
            coord_flip()+ 
            labs(title = "Top 10 menos - Normalizadas", x = "", y = "Total inspecciones", fill = "Estado")
        })
        
        
        
        datos.consulta2$Categoria <- paste0(datos.consulta2$CodigoCampaña,' - ',datos.consulta2$NombreCampaña)
        
        Recupero <- head(datos.consulta2[order(-datos.consulta2$Total),], n=10)
        Recupero$Label  <- with(Recupero, reorder(Categoria, Total))
        
        output$grafico9 <- renderPlotly({
          p <- ggplot(Recupero, aes(x = Label, y = Total, fill=Categoria))+
            geom_bar(stat='identity')+
            theme(legend.position="none")+
            coord_flip()+ 
            labs(title = "Top 10 más - Recuperación", x = "", y = "Total Kwh")
        })
        
        Recupero2 <- head(datos.consulta2[order(datos.consulta2$Total),], n=10)
        Recupero2$Label  <- with(Recupero2, reorder(Categoria, -Total))
        
        output$grafico10 <- renderPlotly({
          p <- ggplot(Recupero2, aes(x = Label, y = Total, fill=Categoria))+
            geom_bar(stat='identity')+
            theme(legend.position="none")+
            coord_flip()+ 
            labs(title = "Top 10 menos - Recuperación", x = "", y = "Total Kwh")
        })
      }else{
        showModal(modalDialog(
          title = "La consulta no encuentra datos que cumplan.",
          footer = tags$div(id="modal1",modalButton("Cerrar")),
          easyClose = TRUE
        ))
      }
      
      shinyjs::enable("ReiniciarControles")
      shinyjs::enable("TraerDatos")

  }, ignoreInit = TRUE)
})



# Ejecutar aplicación -----------------------------------------------------
shinyApp(ui = ui, server = server)