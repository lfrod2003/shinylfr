# =============================================================================
#                              Hoja de vida
# =============================================================================
# 
# Autores:              Fernando Rodriguez, Nelson Beltrán Celis
# Fecha de creacion:    11.04.2021
# Versión:              2.1
# Descripción:
# install.packages("strucchange")
#
# Permite visualizar datos de detalle para cada punto de consumo que son tomados
# de la base de datos mediante la ejecución de diferentes procedimientos almacenados.
#
# Tablas de consulta directa: [Aux].[Parametros], [Dimension].[Campaña]
# Tablas en las que escribe: [Hecho].[OrdenInspeccion]
# Procedimientos almacenados relacionados: [dbo].[DatosComercialesHDV], [dbo].[DatosTecnicosHDV],
# [dbo].[ConsumosHDV], [dbo].[LecturasHDV], [dbo].[DatosMedidorHDV], [dbo].[InspeccionesHDV],
# [dbo].[CorteReconexionHDV], [dbo].[PQRHDV]
#
# Versión construida para piloto en Electrohuila.  Se omiten visualizaciones no disponibles
# por ausencia de datos.
# Pendientes:  
#  - Cálculo de energía promedio a recuperar al generar la orden.
#  - Rutina para bloquear error cuando el punto de consumo no existe.
#
# Ajustes: Usar procedimientos almacenados para independencia de bd;
#          Colores de botones y títulos según guía WM
#          - Fernando Rodríguez Abril 18 2021
# =============================================================================

# Parámetros --------------------------------------------------------------

# Ninguno

# Carga de librerías ------------------------------------------------------

library(shiny)
library(shinydashboard)
library(plotly)         # Gráficas dinámicas plotly
library(TSstudio)       # Presentacion de gráfica de series de tiempo
library(googleway)      # Presentacion de ubicacion del punto de consumo en el mapa
library(rhandsontable)
library(data.table)
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualizacion
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(rintrojs)       # Presentación de ayuda en pantalla

# Otras dependencias ------------------------------------------------------

source("helpers.R")

Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')

# Contadores y llamadas--------------------------------------------------------------

# configuracion.conexion <<- 'windows'
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante

# Configuración de bd y código para api google
#configuracion.conexion <<- Sys.getenv("CONEXIONSHINY") #'windows'
configuracion.conexion <<- 'externalWM'

#  'GoogleKey' CodigoParametro api google en [DWSRBI_KRONOS].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)

cad.sql<-"EXEC [dbo].[Leer_Parametro]"
cad.sql<-paste (cad.sql," @CODIGOPARAMETRO = ?")
parametros<- data.frame(c('GoogleKey'))
api_key <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
odbcClose(conexion)
api_key <<- api_key[1,1]

codigoClienteXURL <<- -1
carga.datos(0)

# Captura de campañas disponibles en BD -----------------------------------
config <- config::get(config = configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "EXEC	[dbo].[Leer_Campanas1]"
nom.camp<-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom.camp)<-"Nombre"
odbcClose(conexion)

# Captura de parámetro para URL servidor shiny -------------
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql<-"EXEC [dbo].[Leer_Parametro]"
cad.sql<-paste (cad.sql," @CODIGOPARAMETRO = ?")
parametros<- data.frame(c('URLshiny'))
URL.servidor.shiny <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
URL.servidor.shiny <- URL.servidor.shiny [1,1]
str.http <<- paste(URL.servidor.shiny,"hoja-de-vida/?Codigo=",sep="")
odbcClose(conexion)



# Inicio UI ---------------------------------------------------------------

dbHeader <- dashboardHeader(title = "Hoja de vida",
                            tags$li(div(
                              img(src = 'Kronos.png',
                                  title = "Hoja de vida", height = "30px"),
                              style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                              class = "dropdown"),
                            dropdownMenuOutput("MensajeOrdenes"),  # Presenta mensajes en barra de encabezado para órdenes generadas
                            dropdownMenuOutput("MensajeMapa"),     # Presenta mensajes en barra de encabezado para novedades en el mapa
                            dropdownMenuOutput("MensajeInsp")      # Presenta mensajes en barra de encabezado para novedades en operaciones
                            )  # Presenta mensajes en barra de encabezado)


ui<-dashboardPage(skin = "blue", 
                  dbHeader,

# Sidebar -----------------------------------------------------------------

                  dashboardSidebar(width = 300,
                                   
                                   #introjsUI(),   # * Se habilita presentación de ayuda
                                   
                                   # Codigo para no mostrar errores en interfaz Shiny
                                   tags$style(type="text/css",
                                              ".shiny-output-error { visibility: hidden; }",
                                              ".shiny-output-error:before { visibility: hidden; }"
                                   ),
                                   
                                   fixedRow(column(width=8,
                                                   offset = 1,
                                                   h5(strong("Punto de consumo:"))
                                                   )
                                            ),
                                   
                                   fluidRow(column(width=8,
                                                   textInput("NumCliente",
                                                             label= "",
                                                             width='200px',
                                                             placeholder ="Referencia")),
                                            column(width=4,
                                                   br(),
                                                   actionButton("actualiza",
                                                                label="",
                                                                icon = icon("play"),
                                                                style="color: #fff; background-color: #0070ba; border-color: #0070ba"
                                                                )
                                                   )
                                   ),
                                   
                                   verbatimTextOutput("queryText"),

                                   box(title =h5(strong("Información comercial:")),
                                       solidHeader=T,
                                       background ="black",
                                       collapsible = T,
                                       width=12,
                                       tableOutput("TablaCom")
                                       ),
                                   box(title =h5(strong("Información técnica:")),
                                       solidHeader=T,
                                       background ="blue",
                                       collapsible = T,
                                       width=12,
                                       tableOutput("TablaTec")
                                       )
                                   ),

# Body --------------------------------------------------------------------

                  dashboardBody(
                    
                      tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }'
                                                )
                                           )
                                ),
                      useShinyjs(),

# Paneles -----------------------------------------------------------------

                      tabsetPanel(type = "tabs",
                                  tabPanel("Consumos", icon = icon("bar-chart-o"),
                                           fluidRow(column(width = 9, hr(),
                                                           withSpinner(
                                                             plotlyOutput("plotCons", height = "770px"),
                                                             color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                                                           )
                                                           ),
                                                    column(width = 3, 
                                                           # hr(),
                                                           tags$h5(tags$img(src="estadisticas.svg" ,alt="" ,width="16", height="16"),"Estadísticas cons. facturado:",style="color: #0070ba"),  # Título e ícono
                                                           tableOutput("TablaEstadistica"),
                                                           # tags$i(class="fa fa-cog", title="Texto tooltip"),
                                                           tags$h5(tags$img(src="histograma.svg" ,alt="" ,width="16", height="16"),"Histograma:",style="color: #0070ba"),  # Título e ícono
                                                           plotOutput("histograma",width= '230px',height = "200px")
                                                           ),
                                                    column(width = 2,
                                                           offset = 10,
                                                           actionButton("Guardar", "Generar orden",
                                                                        icon = icon("fas fa-save"),
                                                                        style="color: #fff; background-color: #0070ba; border-color: #0070ba"
                                                                        )
                                                           )
                                                    )
                                           ),
                                  tabPanel("Medidores y lecturas", icon = icon("fas fa-table"),
                                           box(
                                             title = tags$h5(tags$img(src="medidor.svg" ,alt="" ,width="16", height="16"),"Medidores:",style="color: #0070ba"),
                                             collapsible = T,
                                             solidHeader=T,
                                             width=12,
                                             rHandsontableOutput("TablaMed", height = "80px")
                                             )
                                           , box(
                                             title = tags$h5(tags$img(src="tabla.svg" ,alt="" ,width="16", height="16"),"Lecturas:",style="color: #0070ba"),
                                             collapsible = T,
                                             solidHeader=T,
                                             width=12,
                                             # sliderInput('CantFilas',
                                             #             label = "Filas a mostrar",
                                             #             min = 1,
                                             #             max = nrow(DatosLect),
                                             #             value = 5
                                             #             ),
                                             rHandsontableOutput("TablaLect", height = "386px")
                                             )
                                           ),
                                  tabPanel("Operaciones", icon = icon("fas fa-wrench"),
                                           box(
                                             title = tags$h5(tags$img(src="inspeccion.svg" ,alt="" ,width="16", height="16"),"Inspecciones:",style="color: #0070ba"),
                                             # title =h5(strong("Inspecciones:")),
                                               collapsible = T,
                                               solidHeader=T,
                                               width=12,
                                               fixedRow(
                                                 withSpinner(
                                                   rHandsontableOutput("TablaInsp", height = "150px"),
                                                   color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                                                 )
                                               )
                                             # , fixedRow(
                                             #     h5("Anomalias encontradas:"),
                                             #            rHandsontableOutput("TablaAnom",width = '400px')
                                             #            )
                                               ),
                                           box(
                                             title = tags$h5(tags$img(src="anomalias.svg" ,alt="" ,width="16", height="16"),"Anomalias:",style="color: #0070ba"),
                                             collapsible = T,
                                             solidHeader=T,
                                             width=12,
                                             fixedRow(
                                               withSpinner(
                                                 rHandsontableOutput("TablaAnomalias", height = "150px"),
                                                 color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                                               )
                                             )
                                           )
                                           # , box(
                                           #   title = tags$h5(tags$img(src="corte.svg" ,alt="" ,width="16", height="16"),"Corte y reconexión:",style="color: #0070ba"),
                                           #   # title =h5(strong("Corte y reconexión:")),
                                           #     collapsible = T,
                                           #     collapsed = T,
                                           #     solidHeader=T,
                                           #     width=12,
                                           #   withSpinner(
                                           #     rHandsontableOutput("TablaCxRx", height = "150px"),
                                           #     color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                                           #   )
                                           #   )
                                           # ,box(
                                           #   title = tags$h5(tags$img(src="contactos.svg" ,alt="" ,width="16", height="16"),"Contactos:",style="color: #0070ba"),
                                           #   # title = h5(strong("Contactos:")),
                                           #     collapsible = T,
                                           #     collapsed = T,
                                           #     solidHeader=T,
                                           #     width=12,
                                           #   withSpinner(
                                           #     rHandsontableOutput("TablaContact", height = "150px"),
                                           #     color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                                           #   )
                                           #   )
                                  )
                                  # ,tabPanel("Ubicación", icon = icon("fas fa-map-marker-alt"),
                                  #          hr(),
                                  #          box(title = tags$h5(tags$img(src="corte.svg" ,alt="" ,width="16", height="16"),"Mapa:",style="color: #0070ba"),
                                  #              status = "warning",
                                  #              solidHeader = FALSE,
                                  #              collapsible = TRUE,
                                  #              width = 12, 
                                  #              withSpinner(
                                  #                google_mapOutput(outputId = "map",height="770px"),
                                  #                color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                                  #              )
                                  #              )
                                  #          )
                                  )
)
)

# Inicio Server -----------------------------------------------------------

server <- function(input, output, session) {
 
  usarCodigoURL <<- FALSE  
  
  # Ayuda -------------------------------------------------------------------
  
  output$Tour <- renderText({"Tour" })    # Presenta acceso de ayuda en la cabecera

  steps <- reactive(                      # Crea data frame para incluir los temas de ayuda
    data.frame(
      element = c(NA,"#NumCliente","#TablaCom","#TablaTec","#plotCons",       # Se incluyen nombres de los objetos
                  "#TablaEstadistica","#histograma","#Guardar",NA,NA,NA, "#ayuda"
                  ),  
      intro = c(
        
        "Con la ayuda de este reporte podrá observar diferentes características relevantes para un suministro 
         de interés y si lo requiere, podrá programar una inspección en terreno.",

        "Ingrese el número de identificación del suministro y seleccione actualizar.",
        
        "Acá podrá observar las características de identificación comercial del suministro.",
        
        "Podrá observar las características de identificación técnica y de conexión del suministro",
        
        "La gráfica presenta la evolución histórica de consumos facturados, el consumo normalizado a 30 días 
         y las ventanas o intervalos que presentan homogeneidad. En caso de contar con inspecciones, estas 
         se resaltan  y se presentan los datos de interés.  El gráfico cuenta con herramientas que le 
         facilitarán la visualización, la navegación y la exportación de imágenes.",
        
        "Se resumen estadísticas básicas que permiten tener una visión amplia del desempeño de
        los consumos para el suministro de interés en el intervalo de historia disponible.  
        Se presentan, entre otros, el promedio, la mediana, la desviación estándar y el coeficiente 
        de variación de los consumos.",
        
        "El histograma presenta la distribuciones de frecuencias o cantidad de periodos comprendidos 
        para los intervalos de consumo que se señalan en el eje horizontal. Se incluye una curva de densidad.",
        
        "Desde acá podrá programar una orden de inspección para el suministro que está 
        siendo visualizado.",
        
        "Desde el panel de 'Medidores y lecturas' podra ver toda la historia de medidores y 
        lecturas asociadas al suministro.",
        
        "Desde el panel de 'Operaciones' podrá  conocer la historia de órdenes de inspección, 
        el detalle de las irregularidades y observaciones registradas en estas, las órdenes 
        de suspensión y reconexión y el histórico de atenciones comerciales realizadas a través 
        de los diferentes canales.",
        
        "El panel de 'Ubicación' le permitirá visualizar geográficamente la posición 
        del suministro a la vez de que podrá observar una vista  de  © Google Street View, 
        si esta está disponible.",
        
        "Encuentre acá mensajes relativos a la ejecución de cada sesión."

      )
    )
  )
  
  observeEvent(input$ayuda, {

    introjs(session, options = list("nextLabel"="Siguiente",
                                    "prevLabel"="Anterior",
                                    "skipLabel"="Salir",
                                    "doneLabel"="Terminado",
                                    steps=steps())
    )
    
  })

# Actualización del número de punto de consumo ----------------------------
  
  observeEvent(input$actualiza,{
    disable("actualiza")
    PuntoCons <- 0
    query <- parseQueryString(session$clientData$url_search)
    if (length(query) > 0 ) {
      codigoCliente <- as.numeric(query[["Codigo"]])
      #print(paste("codigo en actualiza: ", codigoCliente))
    }

    if (usarCodigoURL) {
      #carga.datos(as.numeric(codigoClienteXURL))
      PuntoCons <- as.numeric(codigoClienteXURL)
      usarCodigoURL <<- FALSE
    } else {
      #carga.datos(as.numeric(input$NumCliente))
      PuntoCons <- as.numeric(input$NumCliente)
    }

    #conexion <- odbcDriverConnect (cadena.conexion)
    config <- config::get(config=configuracion.conexion)
    config.conexion <- config$conexion
    conexion <- odbcDriverConnect (config.conexion)
    # Verificar validez de código punto consumo
    cad.sql<- "SELECT COUNT(*) c  FROM [Dimension].[PuntoConsumo] where CodigoPuntoConsumo = ?"
    cnt.punto <- sqlExecute(channel = conexion, query = cad.sql,  data = paste0(PuntoCons), 
                            fetch = T, as.is = T)
    odbcClose(conexion)
    if (cnt.punto$c[1] == 0) {
      PuntoCons = -1
      showModal(modalDialog(
        title = "Punto de consumo inválido.",
        footer = tags$div(id="modal1",modalButton("Cerrar")),
        easyClose = TRUE
      ))
    }
    if (PuntoCons > 0){
      carga.datos(PuntoCons)
      session$reload()}
    
    #updateTextInput(session = session, inputId 	= "PConsumo", value = as.character(DatosCom[1,2]))
    
  })

# Datos comerciales -------------------------------------------------------

  # Solo se utilizan de DatosCom los registros del 4 al 12
  output$TablaCom <- renderTable( DatosCom[4:12,],colnames = F,spacing='xs',na='',align = 'lr')


# Datos técnicos ----------------------------------------------------------

  # Solo se utilizan de DatosCom los registros del 2 al 8
  output$TablaTec <- renderTable(DatosTec[2:7,],colnames = F,spacing='xs',na='',align = 'lr')

# Gráfica de consumos -----------------------------------------------------

  output$plotCons<-renderPlotly({     
    
    pmin <- min(DatosCons$Periodo)
    pmin <- c(as.numeric(substr(pmin,1,4)),as.numeric(substr(pmin,5,6)))
    pmax <- max(DatosCons$Periodo)
    pmax <- c(as.numeric(substr(pmax,1,4)),as.numeric(substr(pmax,5,6)))
    cons.fact <- ts(DatosCons$EnergiaActivakWhFacturacion,start = pmin, end = pmax,frequency = 12)
    
    # La serie de consumos normalizados por definición excluye el primer y último registro
    pmin.norm <- DatosCons[1,]$Periodo
    pmin.norm <- c(as.numeric(substr(pmin.norm,1,4)),as.numeric(substr(pmin.norm,5,6)))
    pmax.norm <- DatosCons[max(as.numeric(DatosCons$Cons))-1,]$Periodo
    pmax.norm <- c(as.numeric(substr(pmax.norm,1,4)),as.numeric(substr(pmax.norm,5,6)))
    cons.norm <- ts(DatosCons$ConsumoNormalizadoActivaCN,start = pmin.norm, end = pmax.norm,frequency = 12)
 
    break_point <- breakpoints(cons.norm~ 1)  # Cálculo de ventanas
    fitted.ts <- round(fitted(break_point),0)
    
    DatosCons$Vent<-NA                        # Asignación inicial
    DatosCons$Vent[2:(nrow(DatosCons)-1)]<-fitted.ts
    
    DatosInsp.unic<-unique(DatosInsp[,1:12])   # Selección de datos únicos de inspecciones

    ### LLaveFechaejecucion no existe en DatosInsp.unic ; cambiado por LlaveFechaCreacion
     DatosInsp.unic$Periodo <- substr(DatosInsp.unic$LlaveFechaCreacion,1,6)
     DatosInsp.unic$FechaEjecDec <- substr(DatosInsp.unic$LlaveFechaCreacion,1,6)
    
    #DatosInsp.unic$Periodo <- substr(DatosInsp.unic$LlaveFechaCreacion,1,6)
    #DatosInsp.unic$FechaEjecDec <- substr(DatosInsp.unic$LlaveFechaCreacion,1,6)
    
    DatosInsp.unic <- left_join(DatosCons,DatosInsp.unic,by = "Periodo")

    DatosInsp.unic$Texto <- paste0(" Num.insp.:",
                                  DatosInsp.unic$CodigoInspeccion,
                                  " # ",  # Caracter temporal para incluir luego salto de linea
                                  "Fecha  :",
                                  #conv.fecha(DatosInsp.unic$LlaveFechaEjecucion),
                                  conv.fecha(DatosInsp.unic$LlaveFechaCreacion),
                                  " # ",  # Caracter temporal para incluir luego salto de linea
                                  "Resultado:",
                                  DatosInsp.unic$NombreResultadoCNR,
                                  " # ",  # Caracter temporal para incluir luego salto de linea
                                  "Tipo  insp.:",
                                  DatosInsp.unic$TipoInspeccion,
                                  " # ",  # Caracter temporal para incluir luego salto de linea
                                  "Observac.:",
                                  DatosInsp.unic$ObservacionInspeccion)

    DatosInsp.unic$Texto<-gsub(" # "," \n ",DatosInsp.unic$Texto)  # Se incluye salto de linea

    if(nrow(DatosInsp)>0){        # Si existen inspecciones se incluyen iconos
      plot_ly(data =DatosInsp.unic,x = ~Periodo,
              y = ~EnergiaActivakWhFacturacion,
              type = 'scatter',
              mode = 'lines',
              name = 'Cons. facturado'
              ) %>% 
        add_trace( data =DatosInsp.unic,
                   x = ~Periodo,
                   y = ~ConsumoNormalizadoActivaCN,
                   type = 'scatter',
                   mode = 'lines',
                   name = 'Cons. normalizado'
                   ) %>%
        add_trace( data =DatosCons,
                         x = ~Periodo,
                         y = ~Vent,
                         type = 'scatter',
                         mode = 'lines',
                         marker =list(size=1),
                         name = 'Vent. consumo',
                         line = list(color = 'rgb(128, 128, 128)', width = 2, dash = 'dash')
                   )%>%
        add_trace(data= DatosInsp.unic,
                  x = ~FechaEjecDec,
                  y = ~ConsumoNormalizadoActivaCN,
                  type = "scatter",
                  mode = "markers",
                  name ="Inspecciones",
                  text = ~Texto,
                  hoverinfo = "text",
                  marker = list(color='#0070ba',symbol ="hexagram-dot", size= 12, opacity =0.5),
                  showlegend = T
                  ) %>% 
        layout(legend =list( x = 0.05 , y =0.95 ,bgcolor = "#CFE7EA" ), 
               title=list(text = paste("Punto de consumo:", as.character(DatosCom[1,2])),
                          x = 0.05,
                          font = list(size = 14, color = '#0070ba')
                          ),
               yaxis = list(title = '[kWh]'),  #layout(title="plot title")
               xaxis = list(tickangle = 270)
               )
    }
    
    else  {   # Si no existen inspecciones se omiten iconos
      plot_ly(data =DatosInsp.unic,x = ~Periodo,
              y = ~EnergiaActivakWhFacturacion,
              type = 'scatter',
              mode = 'lines',
              name = 'Cons. facturado'
              ) %>%
        add_trace( data =DatosInsp.unic,
                   x = ~Periodo,
                   y = ~ConsumoNormalizadoActivaCN,
                   type = 'scatter',
                   mode = 'lines',
                   name = 'Cons. normalizado'
                   ) %>% 
      add_trace( data =DatosCons,
                 x = ~Periodo,
                 y = ~Vent,
                 type = 'scatter',
                 mode = 'lines',
                 marker =list(size=1),
                 name = 'Vent. consumo',
                 line = list(color = 'rgb(128, 128, 128)', width = 2, dash = 'dash')
                 ) %>%
        layout(legend =list( x = 0.05 , y =0.95 ,bgcolor = "#CFE7EA" ), 
               title=list(text = paste("Punto de consumo:", as.character(DatosCom[1,2])),
                          x = 0.05,
                          font = list(size = 14, color = '#0070ba')
                          ),
               yaxis = list(title = '[kWh]'),
               xaxis = list(tickangle = 270)
               )
      }
    })

# Tabla de estadísticas ---------------------------------------------------

  output$TablaEstadistica <- renderTable(DatosEst,
                                         colnames = FALSE,
                                         striped = TRUE,
                                         spacing='xs',
                                         align = 'lr',
                                         na='',
                                         digits = 0)

# Histograma --------------------------------------------------------------

  output$histograma <-renderPlot({
  hist(DatosCons$EnergiaActivakWhFacturacion, main = "",xlab = "Cons. Fact. [kWh]", ylab="Dens.",freq=FALSE)
  lines(density(na.omit(DatosCons$EnergiaActivakWhFacturacion)), lwd=2,col="#1F77B4")
  })
  
# Medidores y lecturas ----------------------------------------------------

  output$TablaMed <- renderRHandsontable({
    rhandsontable(DatosMed,
                  #rowHeaders = TRUE,
                  height = "80px",
                  #search = TRUE,
                  readOnly = TRUE
                  # ,maxRows = input$CantFilas
                  )
                  #%>% hot_cols(columnSorting = TRUE) %>% hot_rows(fixedRowsTop = 1)
    })
  
  output$TablaLect <- renderRHandsontable({
    rhandsontable(DatosLect[,4:ncol(DatosLect)],
                  rowHeaders = TRUE,
                  search = TRUE,
                  readOnly = TRUE,
                  height = "150px"
                  #,maxRows = input$CantFilas
                  ) %>% 
      hot_cols(columnSorting = TRUE) %>%
      #hot_rows(fixedRowsTop = 1) %>% 
      hot_table(highlightCol = TRUE, highlightRow = TRUE)
  })
  
# Operaciones ------------------------------------------------------------

  
  output$TablaAnomalias <- renderRHandsontable({
    rhandsontable(DatosAnomalias[,2:ncol(DatosAnomalias)],
                  rowHeaders = TRUE,
                  search = TRUE,
                  readOnly = TRUE,
                  height = "150px"
    ) %>% 
      hot_cols(columnSorting = TRUE) %>%
      #hot_rows(fixedRowsTop = 1) %>% 
      hot_table(highlightCol = TRUE, highlightRow = TRUE)
  })
  
  output$TablaInsp <- renderRHandsontable({
    DatosInspEncab<-unique(DatosInsp[,1:11])
    
    if(nrow(DatosInsp)==0){                     # Valida si no hay inspecciones previas

        output$MensajeInsp <- renderMenu({      # Actualiza mensaje en la barra de menú para operaciones
          
          dropdownMenu(type = "notifications",
                       headerText = "Tiene una notificación",
                       icon = icon("fas fa-gavel"), 
                       notificationItem(
                         text = "El suministro no tiene inspecciones previas",
                         icon("fas fa-exclamation-triangle") 
                       )
          )
        })
    }
    
    # if(nrow(DatosInsp)>0){    # Excepcion para casos en los que no hay inspecciones
    #   DatosInspEncab$LlaveFechaEjecucion<-conv.fecha(DatosInspEncab$LlaveFechaEjecucion)
    #   }
    
    rhandsontable(DatosInspEncab[,2:ncol(DatosInspEncab)],
                  rowHeaders = TRUE,
                  colHeaders = c(
                    'Cod.',
                    'Fecha',
                    'Fecha Legalización',
                    'Origen',
                    'Solicitante',
                    'Estado',
                    'Representa perdida',
                    'Observación inspección',
                    'Observación orden',
                    'Resultado CNR'
                  ),
                  search = T,
                  readOnly = T,
                  height = "150px",
                  selectCallback = T
    ) %>% hot_cols(columnSorting = TRUE) %>%  hot_cols(fixedColumnsLeft = 1) 
  })
  
  output$TablaAnom <- renderRHandsontable({
    DatosInspEncab<-unique(DatosInsp[,1:9])
    
    fila.selec<-input$TablaInsp_select$select$r # Define fila seleccionada

    if (is.null(fila.selec)){
      datosAnom = data.frame("c"= '')
    } else
    {
      if(nrow(DatosInsp)==0){                   # Excepción para casos en los que no hay inspecciones
        datosAnom = data.frame("c"= '')
      }
      else{
        insp.selec<-DatosInspEncab[fila.selec,]$CodigoInspeccion
        datosAnom<-subset(DatosInsp,CodigoInspeccion==insp.selec)
        datosAnom<-as.matrix(datosAnom[,10]) 
      }
    }

    rhandsontable(datosAnom,
                  colHeaders = FALSE,
                  rowHeaders = FALSE,
                  readOnly = TRUE)
  })
  
  output$TablaCxRx <- renderRHandsontable({
    
    rhandsontable(DatosCorteReconexion,
                  rowHeaders = TRUE,
                  # colHeaders = c(
                  #   'Accion',
                  #   'Fecha',
                  #   'Motivo',
                  #   'Resultado',
                  #   'Tipo',
                  #   'Medidor',
                  #   'Marca med',
                  #   'Lect.act',
                  #   'Lect.react',
                  #   'Anom',
                  #   'Observacion',
                  #   'Resultado',
                  #   'Tecnico'
                  #   ),
                  search = T,
                  readOnly = T,
                  height = "150px",
                  selectCallback = T
    )    
  })
  
  output$TablaContact <- renderRHandsontable({
    
    rhandsontable(DatosPQR,
                  rowHeaders = TRUE,
                  colHeaders = c(
                    'Fecha',
                    'Canal',
                    'Motivo'
                    ),
                  search = T,
                  readOnly = T,
                  height = "150px",
                  selectCallback = T
    )    
  })

  # Generar órdenes de inspección en BD ---------------------------------------------------
  
  observeEvent(input$Guardar, {
    
    showModal(modalDialog(
      
      title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("Generar orden de trabajo"),style="color: #0070ba"),style="text-align: center;"),
      
      "El Cliente seleccionado será incluido en la lista de órdenes de inspección",
      hr(),
      selectInput("variable", 
                  "Seleccione campaña:",
                  nom.camp),
      textAreaInput("observ.orden", label = "Observaciones:",
                    height = "100px", rows = 4, 
                    placeholder = "Comentarios para acompañar la órden", 
                    resize = "vertical"),
      footer = list(tags$div(id="modal1",modalButton("Cancelar", icon = icon("far fa-window-close")),
                             actionButton("Guardar2", "Guardar",icon = icon("fas fa-save"),
                                          style="color: #fff; background-color: #0070ba; border-color: #0070ba"))
      ),
      easyClose =TRUE
    )
    )
  })
  
  observeEvent(input$Guardar2, {                    # Código para botón de diálogo modal
    
    #  Grabar orden en BD
    ordenes<-cbind(input$NumCliente,                # Punto de consumo: 'CodigoPuntoConsumo'
                   as.character(input$variable),    # Línea para tipo de campaña seleccionada: 'NombreCampana'
                   "Hoja de vida",                  # Reporte origen de las órdenes: 'ReporteOrigen'
                   as.character(Sys.time()),        # Fecha y hora de generación de las órdenes: 'FechaGeneracion'
                   analista,                        # Usuario que genera las órdenes: 'AnalistaSolicitante'
                   0.5,                             # 'Probabilidad' de detección. ** Se debe incluir probabilidad de la campaña, por ahora es 0.5
                   100,                             # 'RecuperacionMedia': Se asume promedio anterior
                   as.character(input$observ.orden) #  Observación que acompaña la orden 'ObservacionOrden'
    )
    
    ordenes<-data.frame(ordenes)
    config <- config::get(config=configuracion.conexion)
    config.conexion <- config$conexion
    conexion <- odbcDriverConnect (config.conexion)
    cad.sql<-"EXEC [dbo].[Leer_Parametro]"
    cad.sql<-paste (cad.sql," @CODIGOPARAMETRO = ?")
    parametros<- data.frame(c('InsertarInspeccion1'))
    sentencia.sql <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
    sentencia.sql <- sentencia.sql[1,1]
    parametros<- data.frame(c('InsertarInspeccion2'))
    sentencia.sql2 <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
    sentencia.sql <- paste0(sentencia.sql, sentencia.sql2[1,1])
    cad.sql <- sentencia.sql
    cad.sql<-paste (cad.sql,"VALUES (?,?,?,?,?,?,?,?)")
    
    sqlExecute(channel = conexion,
               cad.sql,
               data = ordenes)              # En 'ordenes' se incluye las orden a ser incluida en la tabla 'OrdenInspeccion'
    odbcClose(conexion)
    
    ord.gen <<- ord.gen + nrow(ordenes)     # Se actualiza el contador de órdenes generadas en la sesión. Variable global
    
    output$MensajeOrdenes <- renderMenu({   # Actualiza mensaje en la barra de menú para órdenes generadas

      dropdownMenu(type = "notifications",  # Mensaje en barra de encabezado para indicar generación de órdenes
                   headerText = "Tiene una notificación",
                   icon =icon("fas fa-comments"),
                   notificationItem(
                     text = paste(ord.gen, "órdenes generadas en esta sesión"),
                     icon("fas fa-gavel")
                   )
      )
    })
    
    removeModal()

  })
  
  # Presentación del mapa  --------------------------------------------------

  output$map <- renderGoogle_map({

    if(is.na(datos.map$lat) == TRUE) {        # Valida si el dato de latitud es nulo
      output$MensajeMapa <- renderMenu({      # Actualiza mensaje en la barra de menú para órdenes generadas

        dropdownMenu(type = "notifications",  # Si el puntos no tiene cooordenadas lo indica
                     headerText = "Tiene una notificación",
                     icon = icon("fas fa-map-marker-alt"),
                     notificationItem(
                       text = "Punto sin coordenadas",
                       icon("fas fa-gavel")
                     )
        )
      })
      mapa.vacio()
    } else {
      # generar texto popup
      # Fecha última inspección
      fecha.ultima.inspeccion <- max(DatosInsp$LlaveFechaEjecucion[1])

      fecha.ultima.inspeccion  <- paste0(substr(fecha.ultima.inspeccion,1,4),'/',
                                         substr(fecha.ultima.inspeccion,5,6),'/',
                                         substr(fecha.ultima.inspeccion,7,8))

      if (fecha.ultima.inspeccion == "NA/NA/NA") {
        fecha.ultima.inspeccion <- "-"
      }

      
      # Cargar consumos últimos 12 meses
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      cad.sql <- "SELECT Consumo12 FROM Trabajo.Consumo12meses WHERE LlavePuntoConsumo = ?"
      data.consumo<-sqlExecute(channel = conexion, query = cad.sql,DatosCons$LlavePuntoConsumo[1],fetch= T,as.is=T)
      odbcClose(conexion)
      
      consumos.numericos <- as.numeric(unlist(strsplit(data.consumo$Consumo12[1], ',')))
      texto.consumos.numericos <- texto.popup(consumos.numericos[1:12])
      
      # crear texto de popup
      dtCom <- data.table(DatosCom, stringsAsFactors = FALSE)
      dtTec <- data.table(DatosTec, stringsAsFactors = FALSE)
      datos.map$popup <- paste0(
        "<p></p>",
        "<table border= '0' style= 'height: 120px; width: 100%; border-collapse: collapse;'>",
        "<tbody>",
        "<tr style='height: 20px;'>",
        "<td style='width: 35%; height: 20px; background-color: #f0f2f2;'><strong><span style='color: #0070ba;'>Cliente:&nbsp;</span></strong></td>",
        "<td style='width: 65%; height: 20px; background-color: #f0f2f2; text-align: right;'><strong><span style='color: #0070ba;'>",
        "<a href='",paste(str.http,dtCom[1,2]$Origen, sep=""),
        "' target='_blank' rel='noopener'>",paste(dtCom[1,2]$Origen),"</a>",
        "</span></strong></td>",
        "</tr>",
        "<tr style='height: 20px;'>",
        "<td style='width: 35%; height: 20px; background-color: #f0f2f2;'><strong><span style='color: #0070ba;'>Nombre:&nbsp;</span></strong></td>",
        "<td style='width: 65%; height: 20px;'>",paste(dtCom[4,2]$Origen),"</td>",
        "</tr>",
        "<tr style='height: 20px;'>",
        "<td style='width: 35%; height: 20px; background-color: #f0f2f2;'><strong><span style='color: #0070ba;'>Cons. Prom.:&nbsp;</span></strong></td>",
        "<td style='width: 65%; height: 20px; text-align: right;'>",mean(consumos.numericos[1:6])," [kWh]</td>",
        "</tr>",
        "<tr style='height: 20px;'>",
        "<td style='width: 35%; height: 20px; background-color: #f0f2f2;'><strong><span style='color: #0070ba;'>Transformador:&nbsp;</span></strong></td>",
        "<td style='width: 65%; height: 20px; text-align: right;'>",paste(dtTec[5,2]$Origen),"</td>",
        "</tr>",
        "<tr style='height: 20px;'>",
        "<td style='width: 35%; height: 20px; background-color: #f0f2f2;'><strong><span style='color: #0070ba;'>Ultima inspección:&nbsp;</span></strong></td>",
        "<td style='width: 65%; height: 20px; text-align: right;'>",fecha.ultima.inspeccion,"<br><br></td>",
        "</tr>",
        "<tr style='height: 20px;'>",
        "<td style='width: 35%; height: 20px; background-color: #f0f2f2;'><strong><span style='color: #0070ba;'>Perfil de consumo:&nbsp;</span></strong></td>",
        "<td style='width: 65%; text-align: right; height: 20px;'>",
        "<svg xmlns='http://www.w3.org/2000/svg'",
        "xmlns:xlink='http://www.w3.org/1999/xlink' width='100' height='50' viewBox='0 0 100 50'>",
        texto.consumos.numericos,
        "</svg>",
        "</td>",
        "</tr>",
        "</tbody>",
        "</table>"             
      )
      
      
      # retornar mapa
      google_map(key = api_key, 
                 #location = c(as.numeric(paste(datos.map$lat)),as.numeric(paste(datos.map$lon))),
                 data = datos.map,
                 style=estilo.map01 ) %>%
        # street_view_control=FALSE,split_view = "pano") %>%
        googleway::add_markers(lat = "lat", lon = "lon", info_window = "popup")
    }
    
  })
  
  # Parse the GET query string
  output$queryText  <- renderText({
    #print("Parsing:")    
      # 
      # query <- parseQueryString(session$clientData$url_search)
      # #print(paste0("query2: ", query, " CodigoClienteXURL: ",codigoClienteXURL , " usarCodigoURL: ", usarCodigoURL ))
      # if (length(query) > 0 ) {
      #   codigoCliente <- as.numeric(query[["Codigo"]])
      #   if (!is.na(codigoCliente && nchar(codigoCliente) > 0)) {
      #     #print(paste0("codigoCliente: ", codigoCliente, " CodigoClienteXURL: ",codigoClienteXURL , " usarCodigoURL: ", usarCodigoURL ))
      #     if (codigoCliente != codigoClienteXURL ) {
      #       #print("Actualizando")
      #       codigoClienteXURL <<- codigoCliente
      #       usarCodigoURL <<- TRUE
      #      # print(paste0("antes de click: ", codigoCliente, " CodigoClienteXURL: ",codigoClienteXURL , " usarCodigoURL: ", usarCodigoURL ))
      #       #updateTextInput(session, "NumCliente", value = as.character(codigoCliente ))
      #       click("actualiza")
      #     }
      #   }
      #   else {
      #     #print('Else:')
      #     updateTextInput(session = session, inputId 	= "NumCliente", value = as.character(DatosCom[1,2]))
      #   }
      #   #print(paste("codigo: ", codigoCliente))
      # } 
    
    parse.URL(session)
    
    # Return a string with key-value pairs
    #paste(names(query), query, sep = "=", collapse=", ")
    #codigoCliente
    ""
  })    
}

# Ensamble de la aplicacion -----------------------------------------------------

shinyApp(ui = ui, server = server)