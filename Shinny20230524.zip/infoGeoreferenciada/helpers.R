# Source helpers:
# ********************** Ceros consecutivos ****************************

library(rhandsontable)

# Preparar texto svg para gr\xE1fica de consumo 12 meses en popup  -----------------
texto.popup <- function(l) {
  l[is.na(l)] <- 0  # reemplazar NA por 0
  x0 <- 2
  espacio.vertical = 48
  y0 <- ceiling(max(l))
  escala.vertical = 48 / y0
  colwidth <- 5
  xwidth <- 8
  texto.svg <- ""
  for (i in 1:length(l)) 
  {
    colheight = ceiling(l[i]*escala.vertical)
    texto.svg <- paste0(texto.svg,"<rect y='", espacio.vertical-colheight
                        ,"' x='",x0 + xwidth*(i-1),"' height='",colheight ,"' width='5'"
                        ," style='opacity:1;fill:#008b8a;stroke:#008b8a;' />")
  }
  texto.svg
}


# Funci\xf3n para actualizar controles -----------------------------------------

actualizar.filtros <-
  function (session,
            input,
            atributoCambiado,
            ValoresAtributo,
            valores.atributos, idx) {
    # print(paste0(
    #   'actualizar.filtros: ',
    #   atributoCambiado,
    #   '/',
    #   paste(ValoresAtributo, collapse = ',')
    # ))

    f1 <-
      valores.atributos %>% filter(Atributo == atributoCambiado) %>% filter(Nombre %in% ValoresAtributo)
    
    if (atributoCambiado == "Estrato") {
      idx.filtrado <- idx %>% filter(idx$LlaveEstrato %in% f1$Llave)
    } else     if (atributoCambiado== "Actividad") {
      idx.filtrado <-
        idx %>% filter(idx$LlaveActividadEconomica %in% f1$Llave)
    } else if (atributoCambiado == "Ciclo") {
      idx.filtrado <- idx %>% filter(idx$LlaveCiclo %in% f1$Llave)
    } else if (atributoCambiado == "Circuito") {
      idx.filtrado <- idx %>% filter(idx$LlaveCircuito %in% f1$Llave)
    } else if (atributoCambiado == "Municipio") {
      idx.filtrado <- idx %>% filter(idx$LlaveGeografia %in% f1$Llave)
    }else if (atributoCambiado == "Zona") {
      idx.filtrado <- idx %>% filter(idx$LlaveZona %in% f1$Llave)
    }else if (atributoCambiado == "Transformador") {
      idx.filtrado <- idx %>% filter(idx$LlaveTransformador %in% f1$Llave)
    }
    
    datos.filtrados <- valores.atributos  %>% 
      filter((Atributo=='Zona' & Llave %in% idx.filtrado$LlaveZona) | 
               (Atributo=='Municipio' & Llave %in% idx.filtrado$LlaveGeografia) |
               (Atributo=='Circuito' & Llave %in% idx.filtrado$LlaveCircuito) |
               (Atributo=='Ciclo' & Llave %in% idx.filtrado$LlaveCiclo) |
               (Atributo=='Actividad' & Llave %in% idx.filtrado$LlaveActividad) |
               (Atributo=='Transformador' & Llave %in% idx.filtrado$LlaveTransformador) |
               (Atributo=='Estrato' & Llave %in% idx.filtrado$LlaveEstrato))
    
    # Actualizar controles
    # Actualizar control Estrato
    if (atributoCambiado != "Estrato") {
      valor.seleccionado <- input$estrato
      atr <- valores.atributos %>% filter(Atributo == 'Estrato') %>% filter(Llave %in% idx.filtrado$LlaveEstrato)
      
      updatePickerInput(session,
                        "estrato",
                        choices = c( atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # Actualizar control actividad
    if (atributoCambiado != "Actividad") {
      valor.seleccionado <- input$actividad
      atr <- valores.atributos %>% filter(Atributo == 'Actividad') %>% filter(Llave %in% idx.filtrado$LlaveActividadEconomica)
      
      updatePickerInput(session,
                        "actividad",
                        choices = c( atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # Actualizar control ciclo
    if (atributoCambiado != "Ciclo") {
      valor.seleccionado <- input$ciclo
      atr <- valores.atributos %>% filter(Atributo == 'Ciclo') %>% filter(Llave %in% idx.filtrado$LlaveCiclo)
      
      updatePickerInput(session,
                        "ciclo",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # Actualizar control circuito
    if (atributoCambiado != "Circuito") {
      valor.seleccionado <- input$circuito
      atr <- valores.atributos %>% filter(Atributo == 'Circuito') %>% filter(Llave %in% idx.filtrado$LlaveCircuito)
      
      updatePickerInput(session,
                        "circuito",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # actualizar control municipio
    if (atributoCambiado != "Municipio") {
      valor.seleccionado <- input$municipio
      atr <- valores.atributos %>% filter(Atributo == 'Municipio') %>% filter(Llave %in% idx.filtrado$LlaveGeografia)
      
      #updateSelectInput(session,
      updatePickerInput(session,
                        "municipio",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    # Actualizar control zona
    if (atributoCambiado != "Zona") {
      valor.seleccionado <- input$zona
      atr <- valores.atributos %>% filter(Atributo == 'Zona') %>% filter(Llave %in% idx.filtrado$LlaveZona)
      
      updatePickerInput(session,
                        "zona",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    # Actualizar control transformador
    if (atributoCambiado != "Transformador") {
      valor.seleccionado <- input$transformador
      atr <- valores.atributos %>% filter(Atributo == 'Transformador') %>% filter(Llave %in% idx.filtrado$LlaveTransformador)
      
      updatePickerInput(session,
                        "transformador",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
  

    
  }


# Funci\xf3n para transformar vista de un objeto rhandsontable con primera columna de hiperv\xednculo a
# un data frame

transf.rhand <- function(obj.hand.table){
  ordenes<-hot_to_r(obj.hand.table)                                 # Almacena informaci\xf3n de la tabla en dataframe temporal
  ordenes$CodigoPuntoConsumo <- as.character(ordenes$CodigoPuntoConsumo)
  # quitar comentario cuando se reimplemente link para llamar hoja de vida
  # for(i in 1:nrow(ordenes)){                                      # Extrae el número de cliente del hiperv\xednculo
  #   pos.cliente <- gregexpr(">",ordenes$CodigoPuntoConsumo[i])
  #   pos.cliente <- pos.cliente[[1]][1] + 1
  #   fin.cad <- nchar(ordenes$CodigoPuntoConsumo[i]) - 4
  #   ordenes$CodigoPuntoConsumo[i] <- substr(ordenes$CodigoPuntoConsumo[i],pos.cliente,fin.cad)
  # }
  ordenes
  
}

# Funciones para alternar entre 'true' y 'false' en un objeto rhandsontable

cambia.true.false <-function(obj.rhandsont){
  text.json <-obj.rhandsont$x$data      
  text.json <-gsub( ":true",":false",text.json)  # Cambia 'true' por 'false'
  obj.rhandsont$x$data <- text.json
  return(obj.rhandsont)
}

cambia.false.true <-function(obj.rhandsont){
  text.json <-obj.rhandsont$x$data 
  text.json <-gsub( ":false",":true",text.json) # Cambia 'false' por 'true'
  obj.rhandsont$x$data <- text.json
  return(obj.rhandsont)
}

# función para convertir columna de datos jpg a cod64 ------------------------------------
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}

# Función para formatear fecha a partir de llavefecha -------------------------------------
fLlaveFecha <- function(lFecha) {
  if (is.na(lFecha)){
    paste0("-/-/-") }
  else {
    paste0(as.integer(lFecha %% 100), "/",(lFecha %/% 100) %% 100, "/",lFecha %/% 10000,sep="")
  }
}

# Función para formatear fecha a partir de llavefecha -------------------------------------
fLlaveFecha <- function(lFecha) {
  if (is.na(lFecha)){
    paste0("-/-/-") }
  else {
    paste0(as.integer(lFecha %% 100), "/",(lFecha %/% 100) %% 100, "/",lFecha %/% 10000,sep="")
  }
}


# Traer datos de bd  ----------------------------------------------------
obtener.datos.entrada <- function(output, parametros,str.http) {
  
  #conexion <- odbcDriverConnect ("driver={SQL Server};server=192.168.56.1\\SQL2017;database=DWSRBI_2;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" )
  config <- config::get(config=configuracion.conexion)
  conexion <- odbcDriverConnect(config$conexion)
  #cad.sql<- "[dbo].[Lista_DatosMapas_Prueba]"
  cad.sql<- "[dbo].[Lista_DatosMapas]"
  cad.sql<-paste (cad.sql," @FILAS = ?, @GEOGRAFIA = ?, @CIRCUITO = ?, @CICLO = ?, @ESTRATO = ?, @ZONA = ?, @ACTIVIDADECONOMICA = ? ")
  datos.entrada<-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
  odbcClose(conexion)
  
  
  output$MensajeCarga <- renderMenu({   # Actualiza mensaje en la barra de menú para registros cargados
    
    dropdownMenu(type = "notifications",  # Mensaje en barra de encabezado para indicar carga de datos
                 headerText = "Tiene una notificación",
                 icon =icon("fas fa-comments"), 
                 notificationItem(
                   text = paste(parametros[1,1], "líneas traídas de ", datos.entrada[1,20]),
                   icon("fas fa-gavel") 
                 )
    )
  })
  
  return(procesar.datos.entrada(output, parametros, datos.entrada, str.http))
}


# Procesar datos para mapa  ----------------------------------------------------
procesar.datos.entrada <- function(output, parametros, datos.entrada, str.http) {
  
  datos.entrada <- data.frame(datos.entrada, stringsAsFactors = FALSE)
  
  # Verificar datos de latitud y longitud
  datos.recibidos <- nrow(datos.entrada)
  datos.sin.geografia <- 
    nrow(datos.entrada[is.na(datos.entrada$LatitudPuntoConsumo)  | is.na(datos.entrada$LongitudPuntoConsumo),])
  
  output$MensajeCarga <- renderMenu({   # Actualiza mensaje en la barra de menú para registros cargados
    
    dropdownMenu(type = "notifications",  # Mensaje en barra de encabezado para indicar registros sin geografia
                 headerText = "Tiene una notificación",
                 icon =icon("fas fa-comments"), 
                 notificationItem(
                   text = paste(datos.recibidos, "líneas traídas. ", 
                                datos.sin.geografia, "sin información geográfica."),
                   icon("fas fa-gavel") 
                 )
    )
  })
  
  datos.entrada <- datos.entrada[!is.na(datos.entrada$LatitudPuntoConsumo) & !is.na(datos.entrada$LongitudPuntoConsumo),]
  datos.entrada$LatitudPuntoConsumo <- as.numeric(as.character(datos.entrada$LatitudPuntoConsumo))
  datos.entrada$LongitudPuntoConsumo <- as.numeric(as.character(datos.entrada$LongitudPuntoConsumo))
  #datos.entrada$image <- lapply(datos.entrada$image, aCode64)
  datos.entrada$fechaUltimaInspeccion <- lapply(datos.entrada$fechaUltimaInspeccion, fLlaveFecha)
  #datos.entrada
  
  if (nrow(datos.entrada) == 0){
    
    return(
      data.frame(
        CodigoPuntoConsumo= as.character(),
        NombreCliente = as.character(),
        Actividad = as.character(),
        PromedioActiva6CN = as.character(),
        DevStdActiva6CN = as.character(),
        CodigoTransformador = as.character(),
        fechaUltimaInspeccion = as.Date(character()),
        LatitudPuntoConsumo = as.numeric(),
        LongitudPuntoConsumo  = as.numeric(),
        #     image = as.character(),
        fechaUltimaInspeccion = as.Date(character()),
        Texto = as.character()
      ))
  }
  
  # convertir formato a dos decimales y porcentaje
  
  datos.entrada$PromedioActiva6CN2d <- lapply(datos.entrada$PromedioActiva6CN,
                                              function(x) {trunc(as.numeric(x)*10)/10})
  datos.entrada$DevStdActiva6CN2d <- lapply(datos.entrada$DevStdActiva6CN,
                                            function(x) {trunc(as.numeric(x))/100})
  
  
  consumos.numericos <-sapply(datos.entrada$Consumo12,function(x) sapply(strsplit(x,','), as.numeric))
  for (i in 1:nrow(datos.entrada)) {
    datos.entrada$Consumo12[i] <- texto.popup(unlist(consumos.numericos[i]))  #[1:12,i])
  }
  
  
  datos.entrada$Texto <- paste0(
    "<p></p>",
    "<table border= '0' style= 'height: 120px; width: 100%; border-collapse: collapse;'>",
    "<tbody>",
    "<tr style='height: 20px;'>",
    
    "<td style='width: 35%; height: 20px; background-color: #f0f2f2;'><strong><span style='color: #00828F;'>Cliente:&nbsp;",
    "<td style='width: 65%; height: 20px; background-color: #f0f2f2; text-align: right;'><strong><span style='color: #00828F;'>",
    "<a href='",paste(str.http,datos.entrada$CodigoPuntoConsumo, sep=""),
    "' target='_blank' rel='noopener'>",datos.entrada$CodigoPuntoConsumo,"</a>",
    "</span></strong></td>",
    
    "</tr>",
    "<tr style='height: 20px;'>",
    "<td style='width: 35%; height: 20px; vertical-align: top;'>Nombre:</td>",
    "<td style='width: 65%; height: 20px;'>",datos.entrada$NombreCliente,"</td>",
    "</tr>",
    "<tr style='height: 20px;'>",
    "<td style='width: 35%; height: 20px; vertical-align: top;'>Actividad:</td>",
    "<td style='width: 65%; height: 20px;'>",datos.entrada$Actividad,"</td>",
    "</tr>",
    "<tr style='height: 20px;'>",
    "<td style='width: 35%; height: 20px;'>Cons. Prom.:</td>",
    "<td style='width: 65%; height: 20px; text-align: right;'>",datos.entrada$PromedioActiva6CN2d," [kWh]</td>",
    "</tr>",
    "<tr style='height: 20px;'>",
    "<td style='width: 35%; height: 20px;'>Var. de cons.:</td>",
    "<td style='width: 65%; height: 20px; text-align: right;'>",datos.entrada$DevStdActiva6ACN2d," [%]</td>",
    "</tr>",
    "<tr style='height: 20px;'>",
    "<td style='width: 35%; height: 20px;'>Transformador:</td>",
    "<td style='width: 65%; height: 20px; text-align: right;'>",datos.entrada$CodigoTransformador,"</td>",
    "</tr>",
    "<tr style='height: 20px;'>",
    "<td style='width: 35%; height: 20px;'>Ultima inspección:</td>",
    "<td style='width: 65%; height: 20px; text-align: right;'>",datos.entrada$fechaUltimaInspeccion,"</td>",
    "</tr>",
    "<tr style='height: 20px;'>",
    "<td style='width: 35%; height: 20px;'>Perfil de consumo:</td>",
    "<td style='width: 65%; text-align: right; height: 20px;'>",
    # "<img src='data:image/gif;base64,",
    # datos.entrada$image,
    # "' width='100;' height='50' />",
    "<svg xmlns='http://www.w3.org/2000/svg'",
    "xmlns:xlink='http://www.w3.org/1999/xlink' width='100' height='50' viewBox='0 0 100 50'>",
    datos.entrada$Consumo12,
    "</svg>",
    "</td>",
    "</tr>",
    "</tbody>",
    "</table>"             # Ajuste valores cero
  )
  
  datos.entrada$COD_CLIE2 <- paste0(as.character(datos.entrada$CodigoPuntoConsumo),"_selectedLayer")
  datos.entrada <- datos.entrada %>% replace_na(list(Nombrecliente = '-', DireccionPuntoConsumo = '-',
                                                     NombreCircuito = '-', NombreEstrato = '-',
                                                     Actividad = '-',PromedioActiva6CN = '0',DevStdActiva6CN = '0',
                                                     CodigoTransformador = '-',fechaUltimaInspeccion = '-'))
  for (i in 1:nrow(datos.entrada)){      # Crea los tags para el hipervínculo de num. de cliente
    urlLink <-  paste('<a href="',str.http,datos.entrada$CodigoPuntoConsumo[i],
                      '" target="_blank" rel="noopener noreferrer">',
                      datos.entrada$CodigoPuntoConsumo[i],
                      "</a>",sep="")
    datos.entrada$CodigoPuntoConsumo[i] <- urlLink
    
  }
  
  
  return(datos.entrada)
}


# Generar tabla de puntos dentro de geocerca  -----------------------------------
puntos.en.geocerca <- function(puntos.seleccionados) {
  # puntos.seleccionados$ID <- seq.int(nrow(puntos.seleccionados))
  rhandsontable(
    puntos.seleccionados,
    colHeaders = c("ID",
                   "°",
                   "Cliente",
                   "Nombre",
                   "Estrato",
                   "Circuito",
                   "Transformador",
                   "Cons. prom [kWh]",
                   "Variación [%]",
                   "Ultima inspección"
    ),
    height = 400,
    search = FALSE,
    readOnly = TRUE,
    selectCallback = TRUE,
    rowHeaders = FALSE
  ) %>%
    hot_col(2, halign = "htCenter", readOnly = FALSE) %>%
    hot_col(3, renderer = "html",halign = "htRight") %>%                # Mostrar como hipervínculo
    hot_col(3, renderer = htmlwidgets::JS("safeHtmlRenderer"))  %>% 
    hot_cols(columnSorting = TRUE) %>%          						          # Habilitar ordenamiento
    hot_table(highlightCol = TRUE, highlightRow = TRUE) %>%           # Resalta fila y columna seleccionada
    hot_context_menu(allowRowEdit = FALSE, allowColEdit = FALSE) %>%    # Bloquea opciones de menú contextual
    hot_heatmap(8, color_scale = c("#17F556", "#ED6D47")) %>%
    hot_heatmap(9, color_scale = c("#17F556", "#ED6D47")) %>%
    hot_col(c(8, 9), halign = "htRight")                              # Alinear a la derecha
  
}


# Generar tabla de códigos a cargar -----------------------------------
salida.tabla <- function(input, ouput, lista.valida) {    
  
  if (!error.lectura) {
    # Verificar validez de códigos, y mostrar códigos válidos
    
    names(lista.valida) <- c('listacodigos','CodigoPuntoConsumo',
                             'LongitudPuntoConsumo','LatitudPuntoConsumo')
    
    conteo.invalidos <- nrow(filter(lista.valida,is.na(CodigoPuntoConsumo)))
    conteo.nogeodata <- nrow(filter(lista.valida, is.na(LongitudPuntoConsumo) | is.na(LatitudPuntoConsumo))) - conteo.invalidos
    lista.valida <- lista.valida %>% filter(!(is.na(CodigoPuntoConsumo)| 
                                                is.na(LongitudPuntoConsumo) | is.na(LatitudPuntoConsumo)))
    
    
    msg.num.entradas <- paste0("El archivo contiene ",nrow(lista.valida), " filas. Códigos inválidos: ",
                               conteo.invalidos, ", sin localización: ", conteo.nogeodata)
    title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("Cargar clientes"),style="color: #00828F"),style="text-align: center;")
    
    return(
      fixedRow(column(width = 12,
                      
                      tags$h5(tags$img(src="cambio_ok.svg" ,alt="" ,width="16", height="16"),msg.num.entradas ,style="color: #00828F"),  # Título e ícono 
                      renderRHandsontable( {
                        rhandsontable(data.frame(lista.valida[[1]], stringsAsFactors = FALSE),
                                      colHeaders = c("Código"),
                                      search = FALSE,
                                      readOnly = TRUE,
                                      #selectCallback = TRUE,
                                      height =150
                        )
                      })
      )
      ))
  } else{
    return(
      fixedRow(column(width = 12,
                      renderText({ paste0("Error en la lectura del archivo") })
      )))
  }
  
}


# Retornar mapa vacío ----------------------------------------------------------
mapa.vacio<- function(){
  
  #conexion <- odbcDriverConnect ("driver={SQL Server};server=192.168.56.1\\SQL2017;database=DWSRBI_2;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" )
  config <- config::get(config=configuracion.conexion)
  conexion <- odbcDriverConnect(config$conexion)
  cad.sql<- "[dbo].[Lista_extremos_geografia]"
  datos.geo <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  odbcClose(conexion)
  
  leaflet() %>%
    addTiles() %>%
    
    addMarkers(as.numeric(datos.geo$avgLong), lat= as.numeric(datos.geo$avgLat), popup="Geocentro de área empresa") %>%
    addMiniMap()
}


# findlocations para hallar puntos dentro de geocercas  ------------------------
findLocations <- function(shape, location_coordinates, location_id_colname){
  
  # derive polygon coordinates and feature_type from shape input
  polygon_coordinates <- shape$geometry$coordinates
  feature_type <- shape$properties$feature_type
  
  if(feature_type %in% c("rectangle","polygon")) {
    
    # transform into a spatial polygon
    drawn_polygon <- Polygon(do.call(rbind,lapply(polygon_coordinates[[1]],function(x){c(x[[1]][1],x[[2]][1])})))
    
    # use 'over' from the sp package to identify selected locations
    selected_locs <- sp::over(location_coordinates
                              , sp::SpatialPolygons(list(sp::Polygons(list(drawn_polygon),"drawn_polygon"))))
    
    # get location ids
    x = (location_coordinates[which(!is.na(selected_locs)), location_id_colname])
    
    selected_loc_id = as.character(x[[location_id_colname]])
    
    return(selected_loc_id)
    
  } else if (feature_type == "circle") {
    
    center_coords <- matrix(c(polygon_coordinates[[1]], polygon_coordinates[[2]])
                            , ncol = 2)
    
    # get distances to center of drawn circle for all locations in location_coordinates
    # distance is in kilometers
    dist_to_center <- spDistsN1(location_coordinates, center_coords, longlat=TRUE)
    
    # get location ids
    # radius is in meters
    x <- location_coordinates[dist_to_center < shape$properties$radius/1000, location_id_colname]
    
    selected_loc_id = as.character(x[[location_id_colname]])
    
    return(selected_loc_id)
  }
}



# Validar códigos contra bd, y retornar tabla de códigos válidos -------------------------
validar.archivo <- function(input, ouput,lista.nombres) {
  
  error.lectura <<- FALSE
  
  tryCatch({
    cad.sql<- " [dbo].[Lista_Confirmacion_puntos] @LISTACODIGOS = ? "
    #conexion <- odbcDriverConnect ("driver={SQL Server};server=192.168.56.1\\SQL2017;database=DWSRBI_2;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" )
    config <- config::get(config=configuracion.conexion)
    conexion <- odbcDriverConnect(config$conexion)
    datos.entrada<-sqlExecute(channel = conexion, query = cad.sql, data = lista.nombres,fetch= T,as.is=T)
    odbcClose(conexion)
  }, error = function(e){
    error.lectura <<- TRUE
    
  }
  )
  
  if (!error.lectura) {
    lista.valida <<- datos.entrada
    return(lista.valida)
  } else
    return(NULL)
  
}


# Obtener datos por lista externa  --------------------------------------------------
obtener.datos.porLista <- function(input, output, lista.nombres, str.http){
  
  #[dbo].[Lista_DatosPuntos]
  #conexion <- odbcDriverConnect ("driver={SQL Server};server=192.168.56.1\\SQL2017;database=DWSRBI_2;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" )
  config <- config::get(config=configuracion.conexion)
  conexion <- odbcDriverConnect(config$conexion)
  cad.sql<-paste ('[dbo].[Lista_DatosPuntos] '," @LISTACODIGOS = ? ")
  parametros<- data.frame(c(lista.nombres))
  datos.entrada<-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
  odbcClose(conexion)
  names(datos.entrada) <- c("LlavePuntoConsumo", "CodigoPuntoConsumo", 
                            "NombreCliente", "DireccionPuntoConsumo", "NombreEstrato", "Actividad", "CodigoTransformador",
                            "NombreCircuito", "NombreMunicipioGeografia", "NombreCiclo", "NombreZona",
                            "PromedioActiva6CN", "DevStdActiva6CN", "PromedioReactiva6CN",
                            "DevStdReactiva6CN", "LatitudPuntoConsumo", "LongitudPuntoConsumo",
                            "fechaUltimaInspeccion", "Consumo12", "totalPCsConsulta" )
  return(procesar.datos.entrada(output, parametros, datos.entrada, str.http))
}

# Estilo Aubergine mapa JSON ---------------------------------------------------

estilo.map01 <-
  
  '[
    {
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#8ec3b9"
        }
        ]
    },
    {
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1a3646"
        }
        ]
    },
    {
      "featureType": "administrative.country",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#4b6878"
        }
        ]
    },
    {
      "featureType": "administrative.land_parcel",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#64779e"
        }
        ]
    },
    {
      "featureType": "administrative.province",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#4b6878"
        }
        ]
    },
    {
      "featureType": "landscape.man_made",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#334e87"
        }
        ]
    },
    {
      "featureType": "landscape.natural",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#023e58"
        }
        ]
    },
    {
      "featureType": "poi",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#283d6a"
        }
        ]
    },
    {
      "featureType": "poi",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#6f9ba5"
        }
        ]
    },
    {
      "featureType": "poi",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "featureType": "poi.park",
      "elementType": "geometry.fill",
      "stylers": [
        {
          "color": "#023e58"
        }
        ]
    },
    {
      "featureType": "poi.park",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#3C7680"
        }
        ]
    },
    {
      "featureType": "road",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#304a7d"
        }
        ]
    },
    {
      "featureType": "road",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#98a5be"
        }
        ]
    },
    {
      "featureType": "road",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#2c6675"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#255763"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#b0d5ce"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#023e58"
        }
        ]
    },
    {
      "featureType": "transit",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#98a5be"
        }
        ]
    },
    {
      "featureType": "transit",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "featureType": "transit.line",
      "elementType": "geometry.fill",
      "stylers": [
        {
          "color": "#283d6a"
        }
        ]
    },
    {
      "featureType": "transit.station",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#3a4762"
        }
        ]
    },
    {
      "featureType": "water",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#0e1626"
        }
        ]
    },
    {
      "featureType": "water",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#4e6d70"
        }
        ]
    }
    ]'

# Estilo mapa Retro JSON  ------------------------------------------------------------

estilo.map02 <-

'[
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#ebe3cd"
      }
      ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#523735"
      }
      ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#f5f1e6"
      }
      ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#c9b2a6"
      }
      ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#dcd2be"
      }
      ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#ae9e90"
      }
      ]
  },
  {
    "featureType": "landscape.natural",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "poi",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#93817c"
      }
      ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#a5b076"
      }
      ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#447530"
      }
      ]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f5f1e6"
      }
      ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#fdfcf8"
      }
      ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f8c967"
      }
      ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#e9bc62"
      }
      ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#e98d58"
      }
      ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#db8555"
      }
      ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#806b63"
      }
      ]
  },
  {
    "featureType": "transit.line",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "transit.line",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#8f7d77"
      }
      ]
  },
  {
    "featureType": "transit.line",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#ebe3cd"
      }
      ]
  },
  {
    "featureType": "transit.station",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "water",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#b9d3c2"
      }
      ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#92998d"
      }
      ]
  }
  ]'