# FuncionAux Configurar consulta por datos geografia
consulta_geografia <- function (seleccion_geografia, valores_Geografia,input) {
  
  valores_validos_Geografia <- valores_Geografia
  lista_seleccion <- input$departamento
  if (length(lista_seleccion) > 0) {
    valores_validos_Geografia <- valores_Geografia %>% 
      filter(valores_Geografia$NombreDepartamentoGeografia %in% lista_seleccion)	  
    lista_seleccion <- input$municipio
    if (length(lista_seleccion) > 0) {
      valores_validos_Geografia <- valores_validos_Geografia %>% 
        filter(valores_validos_Geografia$NombreMunicipioGeografia %in% lista_seleccion)
      lista_seleccion <- input$localidad
      if (length(lista_seleccion) > 0) {
        valores_validos_Geografia <- valores_validos_Geografia %>% 
          filter(valores_validos_Geografia$NombreLocalidadZonaGeografia %in% lista_seleccion)
      }
    }
  }
  valores_validos_Geografia <<- valores_validos_Geografia 
  valores_validos_Geografia
}

# FuncionAux Configurar consulta por datos Zona
consulta_zona <- function (seleccion_operativa, valores_ZonaOperativa,input) {
  
  valores_validos <- valores_ZonaOperativa
  lista_seleccion <- input$zona_comercial
  if (length(lista_seleccion) > 0) { 
    valores_validos <- valores_ZonaOperativa %>% 
      filter(valores_ZonaOperativa$NombreZona %in% lista_seleccion)
    lista_seleccion <- input$region
    if (length(lista_seleccion) > 0) {
      valores_validos <- valores_validos %>% 
        filter(valores_validos$NombreRegion %in% lista_seleccion)
      lista_seleccion <- input$centro
      if (length(lista_seleccion) > 0) { 
        valores_validos <- valores_validos %>% 
          filter(valores_validos$NombreOficina %in% lista_seleccion)
        lista_seleccion <- input$itinerario  
        if (length(lista_seleccion) > 0) {
          x1 <- strsplit(lista_seleccion, " - ",fixed = T)
          valores_validos<- valores_validos %>% filter(Itinerario %in% x1)
        }
      }
    }
  }
  valores_validos <<- valores_validos
  valores_validos
}

# FuncionAux Configurar consulta por datos CNAE
consulta_CNAE <- function (seleccion_CNAE, valores_CNAE,input) {
  # No probado todavía...
  
  valores_validos <- valores_CNAE
  lista_seleccion <- input$cnae
  if (length(lista_seleccion) > 0) { 
    valores_validos <- valores_CNAE %>% 
      filter(valores_CNAE$Grupo %in% lista_seleccion)
    lista_seleccion <- input$cnaegrupo
    if (length(lista_seleccion) > 0) {
      valores_validos <- valores_validos %>% 
        filter(valores_validos$Seccion %in% lista_seleccion)
    }
  }
  valores_validos <<- valores_validos
  valores_validos
}


# Consulta de los datos a usar en los filtros
consultarDatosFiltros <- function (conexion) {
  cad.sql<-"EXEC [dbo].[Lista_FiltroZona]"
  valores_ZonaOperativa <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroGeografia]"
  valores_Geografia <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroCircuitos]"
  valores_Circuitos <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroIniciativa1]"
  valores_Iniciativa <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_CNAE]"
  valores_CNAE <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_yyNormalizacion]"
  valores_Normalizacion <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_PIMT]"
  valores_PIMT <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroTarifa]"
  valores_Tarifa <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroTension]"
  valores_Tension <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_Estados]"
  valores_Estados <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_Mercado]"
  valores_Mercado <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
}

# Carga de filtros con valores iniciales
cargarFiltrosIniciales <- function() {
  
  seleccion_operativa <<- 'no'
  # Datos iniciales para  selectores de jerarquía
  x <-  c(unique(valores_ZonaOperativa[c("NombreZona")]))
  zonaCom <<- x[order(x)]
  zonaComColor <<- rep(paste0("color:black;"),length(zonaCom))
  x  <-  c(unique(valores_ZonaOperativa[c("NombreRegion")]))
  regionCom <<- x[order(x)]
  regionComColor <<- rep(paste0("color:black;"),length(regionCom))
  x <- c(unique(valores_ZonaOperativa[c("NombreOficina")]))
  centroCom <<- x[order(x)]
  centroComColor <<- rep(paste0("color:black;"),length(centroCom))
  #x <- c(unique(valores_ZonaOperativa[c("Itinerario")]))
  x <- valores_ZonaOperativa %>% select("NombreOficina", "Itinerario") %>% 
    distinct() %>% arrange(NombreOficina, Itinerario)
  x <- paste0(x$NombreOficina, " - ", x$Itinerario)
  itinerarioCom <<- x
  itinerarioComColor <<- rep(paste0("color:black;"),length(itinerarioCom))
  
  seleccion_geografia <<- 'no'
  x <-  c(unique(valores_Geografia[c("NombreDepartamentoGeografia")]))
  departamentoGeo <<- x
  x <-  c(unique(valores_Geografia[c("NombreMunicipioGeografia")]))
  municipioGeo <<- x[order(x)]
  x <-  c(unique(valores_Geografia[c("NombreLocalidadZonaGeografia")]))
  localidadGeo <<- x[order(x)]
  
  seleccion_circuito <<- 'no'
  x <-  c(unique(valores_Circuitos[c("CodigoCircuito")]))
  codigosCircuito <<- x[order(x)]
  
  seleccion_iniciativa <<- 'no'
  x <-  c(unique(valores_Iniciativa[c("NombreCampana")]))
  codigosIniciativa <<- x[order(x)]
  
  seleccion_CNAE <<- 'no'
  x <- c(unique(valores_CNAE[c("Grupo")]))
  codigosCNAE <<- x[order(x)]
  
  seleccion_grupo <<- 'no'
  x <- c(unique(valores_CNAE[c("Seccion")] %>% filter(!is.na(Seccion))))
  codigosCNAE_grupos <<- x[order(x)]
  
  seleccion_ynormalizacion <<- 'no'
  seleccion_yyyyNormalizacion <<- 'no' 
  codigosyyyyNormalizacion <<- as.integer(valores_Normalizacion[1,1]):as.integer(valores_Normalizacion[1,2])
  
  seleccion_PIMT <<- 'no'
  x <-  c(unique(valores_PIMT[c("NombreProyecto")]))
  codigosPIMT <<- x[order(x)]
  
  seleccion_tarifa <<- 'tarifa'
  x <-  c(unique(valores_Tarifa[c("NombreTarifa")]))
  codigosTarifa <<- x[order(x)]
  
  seleccion_tension <<- 'no'
  x <-  c(unique(valores_Tension[c("NombreTension")]))
  codigosTension <<- x[order(x)]
  
  seleccion_estado <<- 'estado'
  x <-  c(unique(valores_Estados[c("NombreEstado")]))
  codigosEstado <<- x[order(x)]
  
  seleccion_mercado <<- 'mercado'
  x <-  c(unique(valores_Mercado[c("NombreMercado")]))
  codigosMercado <<- x[order(x)]
  
}

# Capturar y manejar eventos de los filtros dependientes
manejarEventosFiltros <- function(input, output, session){
  
  # Jerarquía de zonas operativas
  observeEvent(input$zona_comercial, {
    seleccion_operativa <<- "zona_comercial"
    lista_zona <- input$zona_comercial
    valores_validos_zona <<- valores_ZonaOperativa %>% 
      filter(valores_ZonaOperativa$NombreZona %in% lista_zona)
    
    valores_validos <<- valores_validos_zona
    x <-  c(unique(valores_validos_zona [c("NombreRegion")]))
    xColor <- rep(paste0("color:black;"),length(x[[1]]))
    updatePickerInput(session,
                      "region",
                      choices = sort(x[[1]]),
                      choicesOpt = list(
                        style=rep(paste0("color:black;"),length(x[[1]])))) #c( atr$Nombre)))  ,
    #    selected = valor.seleccionado)
  }, ignoreInit = TRUE, ignoreNULL = F)
  
  
  
  observeEvent(input$region, {
    
      seleccion_operativa <<- "region"
      lista_region <- input$region   
      CodigosRegion <- unique(
        filter(valores_ZonaOperativa, 
               valores_ZonaOperativa$NombreRegion %in% lista_region
        )[["CodigoRegion"]]
      )
      
      
      valores_validos_region <- valores_ZonaOperativa %>% 
        filter(valores_ZonaOperativa$NombreRegion %in% lista_region)
      x <-  c(unique(valores_validos_region[c("NombreOficina")]))
      chlist <- list(style=rep(c("color:black;"),length(x[[1]]))) 
      updatePickerInput(session,
                        "centro",
                        choices = sort(x[[1]]),
                        choicesOpt = chlist)
      
      # SE: Actualizar SMT
      valores_filtro <- valores_Circuitos %>% 
        filter(valores_Circuitos$NombreRegion %in% lista_region)
      x <-  c(unique(valores_filtro[c("CodigoCircuito")]))
      chlist <- list(style=rep(c("color:black;"),length(x[[1]]))) 
      updatePickerInput(session,
                        "circuitos",
                        choices = sort(x[[1]]),
                        choicesOpt = chlist)
      
      # SE: Actualizar Departamento
      # valores_filtro <- filter(valores_Geografia, valores_Geografia$id_region %in% CodigosRegion)
      #valores_filtro <- valores_Geografia
      #x <-  c(unique(valores_filtro[c("NombreDepartamentoGeografia")]))
      #chlist <- list(style=rep(c("color:black;"),length(x[[1]]))) 
      #updatePickerInput(session,
      #                  "departamento",
      #                  choices = sort(x[[1]]),
      #                  choicesOpt = chlist)
    
  }, ignoreInit = TRUE, ignoreNULL = F)
  
  
  # "centro"
  observeEvent(input$centro, {
    seleccion_operativa <<- "centro"
    lista_centro <- input$centro
    valores_validos_centro <<- valores_ZonaOperativa %>% 
      filter(valores_ZonaOperativa$NombreOficina %in% lista_centro)
    valores_validos <<- valores_validos_centro
    x <- valores_validos_centro %>% select("NombreOficina", "Itinerario") %>% 
      arrange(NombreOficina, Itinerario)
    
    x <- unique(x$Itinerario)
    
    updatePickerInput(session,
                      "itinerario",
                      choices = sort(x),
                      choicesOpt = list(
                        style=rep(paste0("color:black;"),length(x))))
    
  }, ignoreInit = TRUE)
  
  # Itinerario
  observeEvent(input$itinerario, {
    
    if (!is.na(valores_validos_centro[[1]][1])) {
      seleccion_operativa <<- "itinerario"
      lista_itinerario <- input$itinerario
      x1 <- strsplit(lista_itinerario, " - ",fixed = T)
      valores_validos_itinerario <<- valores_validos_centro[valores_validos_centro$Itinerario == x1[[1]],]
      valores_validos <<- valores_validos_itinerario
    }
  }, ignoreInit = TRUE)
  
  #Jerarquía geográfica
  # departamento
  observeEvent(input$departamento, {
    seleccion_geografia <<- "departamento"
    lista_seleccion <- input$departamento
    valores_validos_Geografia_departamento <<- valores_Geografia %>% 
      filter(valores_Geografia$NombreDepartamentoGeografia %in% lista_seleccion)
    valores_validos_Geografia <<- valores_validos_Geografia_departamento
    
    x <-  c(unique(valores_validos_Geografia_departamento[c("NombreMunicipioGeografia")]))
    updatePickerInput(session,
                      "municipio",
                      choices = sort(x[[1]]),
                      choicesOpt = list(
                        style=rep(paste0("color:black;"),length(x[[1]]))))
  }, ignoreInit = TRUE)
  
  # municipio
  observeEvent(input$municipio, {
    if (!is.na(valores_validos_Geografia_departamento[[1]][1])) {
      seleccion_geografia <<- "municipio"
      lista_seleccion <- input$municipio
      valores_validos_Geografia_municipio <<- valores_validos_Geografia_departamento %>% 
        filter(valores_validos_Geografia_departamento$NombreMunicipioGeografia %in% lista_seleccion)
      valores_validos_Geografia <<- valores_validos_Geografia_municipio
      
      x <-  c(unique(valores_validos_Geografia_municipio[c("NombreLocalidadZonaGeografia")]))
      updatePickerInput(session,
                        "localidad",
                        choices = sort(x[[1]]),
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(x[[1]]))))
    }
  }, ignoreInit = TRUE)
  
  # localidad
  observeEvent(input$localidad, {
    if (!is.na(valores_validos_Geografia_municipio[[1]][1])) {
      seleccion_geografia <<- "localidad"
      
      lista_seleccion <- input$localidad
      valores_validos_Geografia_localidad <<- valores_validos_Geografia_municipio %>% 
        filter(valores_validos_Geografia_municipio$NombreLocalidadZonaGeografia %in% lista_seleccion)
      valores_validos_Geografia <<- valores_validos_Geografia_localidad
    }
  }, ignoreInit = TRUE)
  
  # circuito
  observeEvent(input$circuitos, {
    seleccion_circuito <<- 'circuitos'
    lista_seleccion <- input$circuitos
    valores_validos_circuitos <<- valores_Circuitos %>%
      filter(valores_Circuitos$CodigoCircuito %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  # Iniciativa
  observeEvent(input$iniciativa, {
    seleccion_iniciativa <<- 'iniciativa'
    lista_seleccion <- input$iniciativa
    valores_validos_iniciativa <<- valores_Iniciativa %>%
      filter(valores_Iniciativa$NombreCampana %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  # CNAE grupo
  observeEvent(input$cnaegrupo, {
    seleccion_grupo <<- "cnaegrupo"
    lista_seleccion <- input$cnaegrupo
    valores_validos_cnae_seccion <<- valores_CNAE %>% 
      filter(valores_CNAE$Seccion %in% lista_seleccion)
    valores_validos_CNAEgrupo <<- valores_validos_cnae_seccion
    
  }, ignoreInit = TRUE)
  
  # pimt
  observeEvent(input$pimt, {
    seleccion_PIMT<<- "pimt"
    lista_seleccion <- input$pimt
    valores_validos_PIMT <<- valores_PIMT %>% 
      filter(valores_PIMT$NombreProyecto %in% lista_seleccion) 
  }, ignoreInit = TRUE)
  
  # normalizacion  -- no está funcionando todavía (datos en bd, lógica asociada)
  observeEvent(input$ynormalizacion, {
    #seleccion_ynormalizacion<<- "ynormalizacion"
    lista_seleccion <- input$ynormalizacion
    valores_validos_normalizacion <<- lista_seleccion 
  }, ignoreInit = TRUE)
  
  # estado
  observeEvent(input$estado, {
    seleccion_estado<<- "estado"
    lista_seleccion <- input$estado
    valores_validos_estado <<- valores_Estados %>%
      filter(valores_Estados$NombreEstado %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  # tension
  observeEvent(input$tension, {
    seleccion_tension<<- "tension"
    lista_seleccion <- input$tension
    valores_validos_tension <<- valores_Tension %>%
      filter(valores_Tension$NombreTension %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  # tarifa
  observeEvent(input$tarifa, {
    seleccion_tarifa<<- "tarifa"
    lista_seleccion <- input$tarifa
    valores_validos_tarifa <<- valores_Tarifa %>%
      filter(valores_Tarifa$NombreTarifa %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  
  # mercado 
  observeEvent(input$mercado, {
    seleccion_mercado<<- "mercado"
    lista_seleccion <- input$mercado
    valores_validos_mercado <<- valores_Mercado  %>%
      filter(valores_Mercado$NombreMercado %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
}

# Capturar y manejar reinicio de filtros
manejarReinicioFiltros <- function(input, output, session){
  observeEvent(input$ReiniciarControles, {
    
    seleccion_operativa <<- 'no'
    
    # Datos iniciales para  selectores de jerarquía
    x <-  c(unique(valores_ZonaOperativa[c("NombreZona")]))
    zonaCom <- x[order(x)]
    valores_validos_zona <<- NA
    valores_validos_region <<- NA
    valores_validos_centro <<- NA
    
    isolate(
      
      updatePickerInput(session,
                        "zona_comercial", choices = sort(zonaCom[[1]]),
                        selected = '',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(zonaCom[[1]])))))
    isolate(
      updatePickerInput(session,
                        "region", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "centro", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "itinerario", choices = c('')))
    
    isolate(
      updatePickerInput(session,
                        "departamento", 
                        choices = sort(departamentoGeo[[1]]),
                        selected = '',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(departamentoGeo[[1]])))))
    isolate(
      updatePickerInput(session,
                        "municipio", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "localidad", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "zona_geo", choices = c('')))
    
    
    
    seleccion_circuito <<- 'no'
    x <-  c(unique(valores_Circuitos[c("CodigoCircuito")]))
    codigosCircuito <- x
    isolate(
      updatePickerInput(session,
                        "circuitos", choices = c(''), # sort(codigosCircuito[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosCircuito[[1]])))))
    
    seleccion_iniciativa <<- 'no'
    codigosIniciativa <-  c(unique(valores_Iniciativa[c("Iniciativa")]))
    isolate(
      updatePickerInput(session,
                        "iniciativa", choices = sort(codigosIniciativa[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosIniciativa[[1]])))))
    
    seleccion_grupo <<- "no"
    
    codigosCNAE_grupos <- c(unique(valores_CNAE[c("Seccion")]))
    isolate(
      updatePickerInput(session,
                        "cnaegrupo", choices = sort(codigosCNAE_grupos[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosCNAE_grupos[[1]])))))
    
    seleccion_PIMT <<- 'no'
    codigosPIMT <-  c(unique(valores_PIMT[c("NombreProyecto")]))
    isolate(
      updatePickerInput(session,
                        "pimt", choices = sort(codigosPIMT[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosPIMT[[1]])))))
    
    seleccion_yyyyNormalizacion <<- 'no'
    isolate(
      updatePickerInput(session,
                        "ynormalizacion", choices = sort(codigosyyyyNormalizacion[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosyyyyNormalizacion[[1]])))))
    
    
    seleccion_tarifa <<- 'tarifa'
    isolate(
      updatePickerInput(session,
                        "tarifa", choices = sort(codigosTarifa[[1]]),
                        selected = c("BT Simple DC", "BT Simple DR"),
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosTarifa[[1]])))))
    
    seleccion_Estado <<- 'estado'
    isolate(
      updatePickerInput(session,
                        "estado", choices = sort(codigosEstado[[1]]),
                        selected = c("Situacion correcta"),
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosEstado[[1]])))))
    
    seleccion_tension <<- 'no'
    isolate(
      updatePickerInput(session,
                        "tension", choices = sort(codigosTension[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosTension[[1]])))))
    
    seleccion_mercado <<- 'mercado'
    isolate(
      updatePickerInput(session,
                        "mercado" , choices = sort(codigosMercado[[1]]),
                        selected = 'Gestion normal',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosMercado[[1]])))))
    
    
    #actividad, tarifa, tensión, "mercado" 
    
  }, ignoreInit = TRUE)
}

# Obtener box con filtros de zona
obtenerFiltrosZona <- function() {
  return (box( id = "filtros1", width = 12, status = NULL,  background = "black",
               #colorspi <- paste0("color:",rep(c('black'),each=10),";"),
               pickerInput("zona_comercial","Zona:",
                           choices = sort(zonaCom[[1]]),
                           selected = NULL,
                           multiple=T,
                           choicesOpt = list(
                             style=rep(paste0("color:black;"),length(zonaCom[[1]]))),
                           options = list(
                             #`actions-box` = TRUE,
                             #`deselect-all-text` = "Ninguno",
                             #`select-all-text` = "Todos",
                             `none-selected-text` = "Zona comercial"
                           )),
               
               
               pickerInput("region","Región:",
                           choices = c(''), #regionCom,
                           #selected = '-TODOS-',
                           multiple=T,
                           options = list(
                             # `actions-box` = TRUE,
                             # `deselect-all-text` = "Ninguno",
                             # `select-all-text` = "Todos",
                             `none-selected-text` = "Región"
                           )),
               
               pickerInput("centro","Centro técnico:",
                           choices = c(''),
                           # selected = '-TODOS-',
                           multiple=T,
                           options = list(
                             # `actions-box` = TRUE,
                             # `deselect-all-text` = "Ninguno",
                             # `select-all-text` = "Todos",
                             `none-selected-text` = "Centro"
                           )),
               
               pickerInput("itinerario","Control de itinerario:",
                           choices = c(''),
                           #selected = '-TODOS-',
                           multiple=T,
                           options = list(
                             # `actions-box` = TRUE,
                             # `deselect-all-text` = "Ninguno",
                             # `select-all-text` = "Todos",
                             `none-selected-text` = "Itinerario"
                           ))
  ))
}

# Obtener box con filtros de departamento
obtenerFiltrosDepartamento <- function() {
  return (box( id = "filtros2", width = 12, status = NULL,  background = "black",
               pickerInput("departamento","Departamento:",
                           choices = sort(departamentoGeo[[1]]),
                           #selected = '-TODOS-',
                           selected = NULL,
                           multiple=T,
                           choicesOpt = list(
                             style=rep(paste0("color:black;"),length(departamentoGeo[[1]]))),
                           options = pickerOptions(
                             # `actions-box` = TRUE,
                             # `deselect-all-text` = "Ninguno",
                             # `select-all-text` = "Todos",
                             livesearch = TRUE,
                             `none-selected-text` = "Seleccionar Departamento"
                           )),
               
               pickerInput("municipio","Municipio:",
                           choices = c(''), #municipioGeo,
                           #selected = '-TODOS-',
                           multiple=T,
                           options = pickerOptions(
                             # `actions-box` = TRUE,
                             # `deselect-all-text` = "Ninguno",
                             # `select-all-text` = "Todos",
                             livesearch = TRUE,
                             `none-selected-text` = "Seleccionar Municipio"
                           )),
               
               pickerInput("localidad","Localidad:",
                           choices = c(''), #localidadGeo,
                           multiple=T,
                           options = pickerOptions(
                             #`live-search`=TRUE,
                             # `actions-box` = TRUE,
                             # `deselect-all-text` = "Ninguno",
                             # `select-all-text` = "Todos",
                             livesearch = TRUE,
                             `none-selected-text` = "Seleccionar localidad"
                           ))
  ))
}

# Obtener box con filtros de empresa
obtenerFiltrosEmpresa <- function() {
  return( box(id = "Empresas", width = 12, 
              status = NULL,  
              background = "black",
              
              pickerInput("circuitos","SMT:",
                          choices = sort(c('')), #codigosCircuito[[1]]),
                          #selected = '-TODOS-',
                          multiple=T,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),length(codigosCircuito[[1]]))),
                          options = list(
                            # `actions-box` = TRUE,
                            # `deselect-all-text` = "Ninguno",
                            # `select-all-text` = "Todos",
                            `none-selected-text` = "SMT"
                          )),
              pickerInput("estado","Estado:",
                          choices = sort(codigosEstado[[1]]),
                          selected = c("Situacion correcta"),
                          multiple=T,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),length(codigosEstado[[1]]))),
                          options = list(
                            # `actions-box` = TRUE,
                            # `deselect-all-text` = "Ninguno",
                            # `select-all-text` = "Todos",
                            `none-selected-text` = "Estado"
                          )),
              pickerInput("tension","Tensión:",
                          choices = sort(codigosTension[[1]]),
                          #selected = '-TODOS-',
                          multiple=T,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),length(codigosTension[[1]]))),
                          options = list(
                            # `actions-box` = TRUE,
                            # `deselect-all-text` = "Ninguno",
                            # `select-all-text` = "Todos",
                            `none-selected-text` = "Tensión"
                          )),
              pickerInput("tarifa","Tarifa:",
                          choices = sort(codigosTarifa[[1]]),
                          selected = c("BT Simple DC", "BT Simple DR"),
                          multiple=T,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),length(codigosTarifa[[1]]))),
                          options = list(
                            # `actions-box` = TRUE,
                            # `deselect-all-text` = "Ninguno",
                            # `select-all-text` = "Todos",
                            `none-selected-text` = "Tarifa"
                          )),
              pickerInput("mercado","Tipo de mercado:",
                          choices = sort(codigosMercado[[1]]) ,
                          selected = 'Gestion normal',
                          multiple=T,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),length(codigosMercado[[1]]))),
                          options = list(
                            # `actions-box` = TRUE,
                            # `deselect-all-text` = "Ninguno",
                            # `select-all-text` = "Todos",
                            `none-selected-text` = "Mercado"
                          )),
              
              pickerInput("cnaegrupo","CNAE grupo:",
                          choices = sort(codigosCNAE_grupos[[1]]),
                          #selected = '-TODOS-',
                          multiple=T,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),length(codigosCNAE_grupos[[1]]))),
                          options = list(
                            # `actions-box` = TRUE,
                            # `deselect-all-text` = "Ninguno",
                            # `select-all-text` = "Todos",
                            `none-selected-text` = "CNAE grupo"
                          )),
              pickerInput("iniciativa","Línea:",
                          choices = sort(codigosIniciativa[[1]]),
                          #selected = '-TODOS-',
                          multiple=T,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),length(codigosIniciativa[[1]]))),
                          options = list(
                            # `actions-box` = TRUE,
                            # `deselect-all-text` = "Ninguno",
                            # `select-all-text` = "Todos",
                            `none-selected-text` = "Línea"
                          )),
              pickerInput("pimt","PIMT:",
                          choices = sort(codigosPIMT[[1]]),
                          #selected = '-TODOS-',
                          multiple=T,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),length(codigosPIMT[[1]]))),
                          options = list(
                            # `actions-box` = TRUE,
                            # `deselect-all-text` = "Ninguno",
                            # `select-all-text` = "Todos",
                            `none-selected-text` = "PIMT"
                          )),
              # pickerInput("ynormalizacion","Año de normalización:",
              #             choices = sort(codigosyyyyNormalizacion[[1]]),
              #             multiple=T,
              #             choicesOpt = list(
              #               style=rep(paste0("color:black;"),length(codigosyyyyNormalizacion[[1]]))),
              #             options = list(
              #               # `actions-box` = TRUE,
              #               # `deselect-all-text` = "Ninguno",
              #               # `select-all-text` = "Todos",
              #               `none-selected-text` = "Año normalización"
              #             )),
              
              pickerInput("habitacion","Habitación:",
                          choices = c('Todos','Habitado','No habitado', 'Sin definir'),
                          multiple=F,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),4)),
                          options = list(
                            `none-selected-text` = "Habitación"
                          ))
              
              
  )
  )
}
