# =============================================================================
#                             Seguimiento fraudulentos
# =============================================================================
# 
# Fecha de creación:    14.08.2021
# Versión:              0
# Descripción:
#
# =============================================================================

# Carga de librerías ------------------------------------------------------

library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
#library(reactlog)
library(shinydashboard)
library(htmlwidgets)
library(stringr)
library(DT)
library(ggplot2)
library(plotly)         # Gráficas dinámicas plotly
library(rhandsontable)  # Visualización tablas
library(RCurl)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
library(tidyr)
library(tibble)
library(lubridate)
#library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(colorspace)
#require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
library(rintrojs)       # Presentación de ayuda en pantalla

source("helpers.R")
source("../_shared/_filtros.R")
#reactlog_enable()

# Contadores y llamadas--------------------------------------------------------------
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante

Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')
locale <- Sys.getlocale(category="LC_COLLATE")
if (grepl("Spanish", locale, fixed=TRUE)) {
  separador.csv <<- ';'
} else {
  separador.csv <<- ','
}
# nombre_meses <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 
#                   'Sep', 'Oct', 'Nov', 'Dic')
nombre_meses <- c('01', '02', '03', '04', '05', '06', '07', '08', 
                  '09', '10', '11', '12')

# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}

# Retornar tabla para despliegue recuperación ---------------------------------------------
tabla.despliegue <- function(wsumr, titulos_tabla) {
  
  wsumr[wsumr == 0] <- NA;
  rhandsontable(wsumr[,1:length(titulos_tabla)],
                rowHeaders = TRUE,
                colHeaders = titulos_tabla,
                height = 330,
                search = FALSE,
                readOnly = TRUE,
                selectCallback = TRUE) %>%  
    hot_cols(fixedColumnsLeft=2) %>%  hot_cols( format = "#0,000." )
}

tabla.despliegueRatio <- function(wsumr, titulos_tabla) {
  
  wsumr[wsumr == 0] <- NA;
  rhandsontable(wsumr[,1:length(titulos_tabla)],
                rowHeaders = TRUE,
                colHeaders = titulos_tabla,
                height = 330,
                search = FALSE,
                readOnly = TRUE,
                selectCallback = TRUE) %>%  
    hot_cols(fixedColumnsLeft=2) %>%  hot_cols( format = "#0,000." )
}

# Configuración de bd
configuracion.conexion <<- 'externalWM'


# Captura de parámetro para URL servidor shiny -------------
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql<-"EXEC [dbo].[Leer_Parametro]"
cad.sql<-paste (cad.sql," @CODIGOPARAMETRO = ?")
parametros<- data.frame(c('URLshiny'))
URL.servidor.shiny <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
URL.servidor.shiny <- URL.servidor.shiny [1,1]
str.http <<- paste(URL.servidor.shiny,"hvurl/?Codigo=",sep="") # Cadena de llamada para vínculo a hoja de vida

URL.servidor.shiny <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
ListaIniciativa <<- c(sqlExecute(channel = conexion, query = "select DISTINCT(Iniciativa) from Dimension.Campaña WHERE Iniciativa is not null",fetch= T,as.is=T))
ListaTipoGeneracion <<- c(sqlExecute(channel = conexion, query = "select DISTINCT(Tipo_generacion) from Dimension.Campaña WHERE Tipo_generacion is not null",fetch= T,as.is=T))
# Consultar datos de filtros
consultarDatosFiltros(conexion)

# Carga contenido filtros
cargarFiltrosIniciales()

odbcClose(conexion)

# UI ----------------------------------------------------------------------

ui = dashboardPage(
  dashboardHeader(title = "Seguimiento a fraudulentos",
                tags$li(div(
                  img(src = 'Kronos.png',
                      title = "Seguimiento a fraudulentos", height = "30px"),
                  style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                  class = "dropdown"),
                dropdownMenuOutput("MensajeOrdenes")),  # Presenta mensajes en barra de encabezado)
  
  
  # Sidebar -----------------------------------------------------------------
  
  
  dashboardSidebar(width = 500,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   #introjsUI(),   # Se habilita presentación de ayuda
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   fluidRow( column(width = 6,offset = 0, style='padding:0px;',
                                    box(id = "Comandos", width = 12, 
                                        status = NULL,  
                                        background = "black",
                                        fluidRow( 
                                          column(width = 2,offset = 1,
                                                 actionButton("ReiniciarControles", label = icon("fas fa-sync"),
                                                              style="color: #fff; background-color: #0070ba; border-color: #0070ba"),
                                                 bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                                          ),
                                          column(width = 2,
                                                 offset = 1,
                                                 actionButton("TraerDatos", label = icon("fas fa-play"),
                                                              style="color: #fff; background-color: #0070ba; border-color: #0070ba"), 
                                                 bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                                          )
                                        )
                                        
                                    ),
                                    
                                    box(id = "FiltroLegalizacion", width = 12, status = NULL,  background = "black",
                                        
                                        pickerInput("signoAumentoTotal","Signo total:",
                                                    choices = c('Todos','Positivo','Negativo','Cero'),
                                                    selected = NULL,
                                                    choicesOpt = list(
                                                      style=rep(paste0("color:black;"),4)),
                                                    options = list(
                                                      `none-selected-text` = ""
                                                    )),
                                        
                                        pickerInput("signoUltimoPeriodo","Signo ultimo periodo:",
                                                    choices = c('Todos','Positivo','Negativo','Cero'),
                                                    selected = NULL,
                                                    choicesOpt = list(
                                                      style=rep(paste0("color:black;"),4)),
                                                    options = list(
                                                      `none-selected-text` = ""
                                                    )),
                                        
                                        pickerInput("facturadoUltimoPeriodo","Facturado ultimó periodo:",
                                                    choices = c('Todos','Si','No'),
                                                    selected = NULL,
                                                    # multiple=T,
                                                    choicesOpt = list(
                                                      style=rep(paste0("color:black;"),3)),
                                                    options = list(
                                                      `none-selected-text` = ""
                                                    )),
                                    ),
                                        
                                    box(id = "FiltroIniciativa", width = 12, status = NULL,  background = "black",
                                            
                                        pickerInput("Iniciativa","Iniciativa",
                                                    choices = ListaIniciativa[[1]],
                                                    selected = NULL,
                                                    multiple=T,
                                                    choicesOpt = list(
                                                      style=rep(paste0("color:black;"),length(ListaIniciativa[[1]]))),
                                                    options = list(
                                                      `none-selected-text` = "Iniciativa"
                                                    )),
                                        
                                        pickerInput("TipoGeneracion","Tipo generación:",
                                                    choices = ListaTipoGeneracion[[1]],
                                                    selected = NULL,
                                                    multiple=T,
                                                    choicesOpt = list(
                                                      style=rep(paste0("color:black;"),length(ListaTipoGeneracion[[1]]))),
                                                    options = list(
                                                      `none-selected-text` = "Tipo generación"
                                                    )),
                                    ),
                                    
                                    obtenerFiltrosZona(),
                                    obtenerFiltrosDepartamento()
                   ),
                   column(width = 6, offset = 0, style='padding:0px;',
                          obtenerFiltrosEmpresa()
                   ))
  ),
  
  # Body --------------------------------------------------------------------
  
  dashboardBody(
    tags$head(tags$style(
      HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }'
      )
    )),
    # Fin estilo
    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel(
      type = "tabs",
      
      tabPanel(
        "Recuperación",
        icon = icon("bar-chart-o"),
        hr(),
        box(
          width = 12,
          status = "warning",
          solidHeader = FALSE,
          fluidRow(id = "titulo1",
                   "Afloramiento",
                   tags$head(
                     tags$style("#titulo1{color: #00828f; font-size: 16px}")
                   )),
          br(),
          rHandsontableOutput("datos"),
          br(),
          fluidRow(id = "titulo2",
                   "Ratio Energia",
                   tags$head(
                     tags$style("#titulo2{color: #00828f; font-size: 16px}")
                   )),
          br(),
          rHandsontableOutput("datosRatio"),
          br(),
          fluidRow(
            hr() ,
            column(width = 6, plotlyOutput("plot_mes", height = "300px")),
            column(width = 6, plotlyOutput("plot_acumulado", height = "300px"))
          ),     
          useShinyjs()
          # code to reset plotlys event_data("plotly_click", source="A") to NULL -> executed upon action button click
          # note that "A" needs to be replaced with plotly source string if used
          #extendShinyjs(text = "shinyjs.resetGraph = function() { Shiny.onInputChange('.clientValue-plotly_selected-master', 'null'); }")
        ),
        fluidRow(
          column(
            width = 2,
            offset = 9,
            shinyjs::disabled(
              downloadButton('descargar_recuperacion', 'Descargar csv',
                             style =
                               "color: #fff; background-color: #00828f; border-color: #00828f"),
              # Se crea el botón deshabilitado para que
              bsTooltip(
                "descargar_recuperacion",
                "Descargar energía recuperada a archivo csv",
                placement = "bottom",
                trigger = "hover",
                options = NULL
              )
            )                                           # sea habilitado posteriormente por código
            
          ))
      ),
      id = "TabsApp"
    )
  )
)

# Server ------------------------------------------------------------------

server <- shinyServer(function(input, output, session) { # Importante iniciar con shinyServer para que funcione la ayuda
  
  #consulta.activa <<- FALSE
  datos.consulta <- NA
  #tipo.grafica <- 'P'
  #tabla.datos.valida <- FALSE

  valores_validos_zona <<- NA
  valores_validos_region <<- NA
  valores_validos_centro <<- NA
  valores_validos_Geografia_departamento  <<- NA
  valores_validos_Geografia_municipio <<- NA
  
  valores_validos_estado <<- NA
  valores_validos_tarifa <<- NA
  valores_validos_mercado <<- NA
  
  
  updatePickerInput(session,"estado",selected = '')
  updatePickerInput(session,"tarifa",selected = '')
  updatePickerInput(session,"mercado",selected = '')


  # Ayuda -------------------------------------------------------------------
  
  output$Tour <- renderText({"Tour" })  # Presenta acceso de ayuda en la cabecera
  
  steps <- reactive(  # Crea data frame para incluir los temas de ayuda
    data.frame(
      element = c(NA, "#ReiniciarControles", "#TraerDatos", "#selectorFecha", "#filtros", 
      "#Recuperacion", "#selec.tod", "#descargar_recuperacion","#Datos_detalle", 
      "#selec_tod_seguimiento", "#Descargar", "#Generar órdenes"),  # Se incluyen nombres de los objetos
      intro = c(
        "Este reporte muestra la energía recuperada por inspecciones de reducción de pérdidas, y el comportamiento individual de consumo de los usuarios inspeccionados después de la inspección.",
        "Este botón reinicializa las listas de valores en los botones de filtro.",
        "Este botón hace la consulta para traer los datos que corresponden a los valores de filtros seleccionados.",
        "Escoger rango de fechas a tener  en cuenta para la selección de datos.",
        "Utilice las listas desplegables para fitrar por categorías.",
        "La tabla muestra la recuperación mensual para el intervalo de tiempo seleccionado. Las gráficas en la parte inferior muestran la energía recuperada mes a mes y acumulada para cada mes.",
        "El botón de selección en el panel de datos permite marcar todos los datos en la tabla, o desmarcarlos para seguimiento de usuarios individuales inspeccionados en el panel de detalle.",
        "El botón de guardar en el panel de datos crea un archivo csv con los datos de recuperación de energía mostrados en la tabla.",
        "El panel de detalle muestra en forma tabular el comportamiento de consumo posterior a la isnpección para los usuarios inspeccionados durante los meses marcados en el tablero de recuperación de energía.",
        "El botón de selección en el panel de datos permite marcar todos los datos en la tabla, o desmarcarlos para descarga a archivo externo y para generación de órdenes de inspección.",
        "El botón de guardar en el panel de datos crea un archivo csv con los datos de las cuentas seleccionadas en la tabla.",
        "El botón de generar órdenes en el panel de datos crea órdenes de inspección para las cuentas seleccionadas en la tabla."
      )
    )
  )
  
  observeEvent(input$ayuda, {
    # alert("Presionó ayuda")
    introjs(session, options = list("nextLabel"="Siguiente",
                                    "prevLabel"="Anterior",
                                    "skipLabel"="Salir",
                                    "doneLabel"="Terminado",
                                    steps=steps())
    )
    
  })
  
  
  
  # Carga de datos a listas desplegables
  manejarEventosFiltros(input, output, session)
  
  # Reinicial controles
  manejarReinicioFiltros(input, output, session)
  
  
  
  
# Hacer consulta basada en valores de filtros  ---------------------------
  observeEvent(input$TraerDatos, {

    # Construir condiciones de consulta:
    condiciones_consulta = " 1>0 "
    
    if(input$signoUltimoPeriodo != 'Todos'){
      if(input$signoUltimoPeriodo == 'Cero'){
        condiciones_consulta <- paste0(condiciones_consulta, " AND af.AumentoUltimoMes = 0 ")
      }
      if(input$signoUltimoPeriodo == 'Positivo'){
        condiciones_consulta <- paste0(condiciones_consulta, " AND af.AumentoUltimoMes > 0 ")
      }
      if(input$signoUltimoPeriodo == 'Negativo'){
        condiciones_consulta <- paste0(condiciones_consulta, " AND af.AumentoUltimoMes < 0 ")
      }
    }
    if(input$signoAumentoTotal != 'Todos'){
      if(input$signoAumentoTotal == 'Cero'){
        condiciones_consulta <- paste0(condiciones_consulta, " AND af.AumentoTotal = 0 ")
      }
      if(input$signoAumentoTotal == 'Positivo'){
        condiciones_consulta <- paste0(condiciones_consulta, " AND af.AumentoTotal > 0 ")
      }
      if(input$signoAumentoTotal == 'Negativo'){
        condiciones_consulta <- paste0(condiciones_consulta, " AND af.AumentoTotal < 0 ")
      }
    }
    
    if(input$facturadoUltimoPeriodo != 'Todos'){
      if(input$facturadoUltimoPeriodo == 'Si'){
        condiciones_consulta <- paste0(condiciones_consulta, " AND af.FacturadoUltimoMes = 1 ")
      }else{
        condiciones_consulta <- paste0(condiciones_consulta, " AND af.FacturadoUltimoMes = 0 ")
      }
    }
    
    if(!is.null(input$TipoGeneracion)){
      condiciones_consulta <- paste0(
        condiciones_consulta,
        " AND ca.Tipo_generacion in ( ",
        paste0("'",input$TipoGeneracion, "'", collapse = ','),
        " )")
    }
    
    if(!is.null(input$Iniciativa)){
      condiciones_consulta <- paste0(
        condiciones_consulta,
        " AND ca.Iniciativa in ( ",
        paste0("'",input$Iniciativa, "'", collapse = ','),
        " )")
    }
    
    
    
    if(!is.null(input$zona_comercial)){
      # Construir condiciones de consulta:
      if (seleccion_operativa != "no") {
        if (nrow(valores_validos) == 0) {
          noHayValores <- TRUE
        } else { 
          
          #f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos[c("LlaveZona")]), collapse=",")),1,stop =1000000L)
          valores_validos <- consulta_zona(seleccion_operativa, valores_ZonaOperativa,input)
          
          f1 <- t(unique(valores_validos[c("LlaveZona")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos[c("LlaveZona")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.Llavezona IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$region)){
      if (seleccion_geografia != "no") {
        if (nrow(valores_validos_Geografia) == 0) {
          noHayValores <- TRUE
        } else {
          #f1 <- substr(gsub("[\r751:\n]", "",paste0(unique(valores_validos_Geografia[c("LlaveGeografia")]), collapse=",")),1,stop =1000000L)
          valores_validos_Geografia <- consulta_geografia(seleccion_geografia, valores_Geografia,input)
          f1 <- t(unique(valores_validos_Geografia[c("LlaveGeografia")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_Geografia[c("LlaveGeografia")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveGeografia IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$circuitos)){
      if (seleccion_circuito != "no") {
        if (nrow(valores_validos_circuitos) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_circuitos[c("LlaveCircuito")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_circuitos[c("LlaveCircuito")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveCircuito IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$iniciativa)){
      if (seleccion_iniciativa != "no") {
        f1 <- t(unique(valores_validos_iniciativa[c("LlaveCampana")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        f1 <- str_replace(f1, "[)]", "")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND af.LlaveCampaña IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    c1 <- ''
    c2 <- ''
    
    if(!is.null(input$cnae)){
      if (seleccion_CNAE != 'no') {
        if (nrow(valores_validos_cnae_division) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_cnae_division[c("LlaveActividadEconomica")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_cnae_division[c("LlaveActividadEconomica")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          c1 <- str_replace(f1, "[)]", "")
          
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND LlaveActividadEconomica IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$cnaegrupo)){
      if (seleccion_grupo != 'no') {
        
        if (nrow(valores_validos_CNAEgrupo) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_CNAEgrupo[c("LlaveActividadEconomica")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          f1 <- paste0(gsub(":",",",unique(valores_validos_CNAEgrupo[c("LlaveActividadEconomica")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          c2 <- str_replace(f1, "[)]", "")
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND LlaveActividadEconomica IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$cnaegrupo)){
      # Unificar seleccion_CNAE y seleccion_grupo
      if (seleccion_CNAE != 'no' && seleccion_grupo != 'no') {
        condiciones_CNAE <- gsub("[\r\n]", "",substr(c1,1,stop =1000000L),  
                                 ",",substr(c2,1,stop =1000000L) )
        condiciones_consulta <- paste0(condiciones_consulta,
                                       " AND l.LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
      } else if (seleccion_CNAE != 'no' ) {
        condiciones_CNAE <- gsub("[\r\n]", "",substr(c1,1,stop =1000000L) )
        condiciones_consulta <- paste0(condiciones_consulta,
                                       " AND l.LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
        
        
      } else if (seleccion_grupo != 'no') {
        condiciones_CNAE<- gsub("[\r\n]", "",substr(c2,1,stop =1000000L) )
        condiciones_consulta <- paste0(condiciones_consulta,
                                       " AND l.LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
      }
    }
    
    if(!is.null(input$estado)){
      if (seleccion_estado != 'no') {
        ifelse (is.na(valores_validos_estado),
                {
                  lista_seleccion <- input$estado
                  valores_validos_estado <<- valores_Estados %>%
                    filter(valores_Estados$NombreEstado %in% lista_seleccion)
                },NA)  
        if (nrow(valores_validos_estado) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_estado[c("LlaveEstado")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tension[c("Llavetension")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND l.LlaveEstado IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$tension)){
      if (seleccion_tension != 'no') {
        if (nrow(valores_validos_tension) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_tension[c("Llavetension")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tension[c("Llavetension")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveTension IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$tarifa)){
      if (seleccion_tarifa != 'no') {
        ifelse (is.na(valores_validos_tarifa),
                {
                  lista_seleccion <- input$tarifa
                  valores_validos_tarifa <<- valores_Tarifa %>%
                    filter(valores_Tarifa$NombreTarifa %in% lista_seleccion)
                } , NA) 
        if (nrow(valores_validos_tarifa) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_tarifa[c("LlaveTarifa")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tarifa[c("LlaveTarifa")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveTarifa IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$mercado)){
      if (seleccion_mercado != 'no') {
        ifelse (is.na(valores_validos_mercado),
                {
                  lista_seleccion <- input$mercado
                  valores_validos_mercado <<- valores_Mercado  %>%
                    filter(valores_Mercado$NombreMercado %in% lista_seleccion)
                } , NA) 
        if (nrow(valores_validos_mercado) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_mercado[c("LlaveMercado")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_mercado[c("LlaveMercado")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveTipoObjeto IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$pimt)){
      if (seleccion_PIMT != 'no') {
        
        if (nrow(valores_validos_PIMT) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_PIMT[c("LlavePIMT")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_PIMT[c("LlavePIMT")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlavePIMT IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$ynormalizacion)){
      if (seleccion_ynormalizacion != 'no') {
        if (nrow(valores_validos_ynormalizacion) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_ynormalizacion[c("Llaveynormalizacion")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          f1 <- paste0(gsub(":",",",unique(valores_validos_ynormalizacion[c("Llaveynormalizacion")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND Llaveynormalizacion IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$habitacion)){
      if(input$habitacion == 'Habitado'){
        condiciones_consulta <- paste0(condiciones_consulta," AND l.Habitado = 1 ")
      }
      if(input$habitacion == 'No habitado'){      
        condiciones_consulta <- paste0(condiciones_consulta," AND l.Habitado = 0 ")
      }
      if(input$habitacion == 'Sin definir'){
        condiciones_consulta <- paste0(condiciones_consulta," AND l.Habitado is NULL ")
      }
    }
    
    disable("ReiniciarControles")  
    disable("TraerDatos")
    # traer datos de recuperación
    config <- config::get(config=configuracion.conexion)
    config.conexion <- config$conexion
    conexion <- odbcDriverConnect (config.conexion)
    ano_actual <- format(Sys.Date(), "%Y")
    cad.sql<-paste0("select CAST(fa.Periodo AS VARCHAR) Accion
              	, count(DISTINCT (LlaveInspeccion)) Ordenes
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"01 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M01'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"02 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M02'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"03 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M03'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"04 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M04'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"05 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M05'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"06 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M06'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"07 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M07'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"08 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M08'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"09 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M09'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"10 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M10'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"11 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M11'
              	, CAST(sum(CASE WHEN f.Periodo=",ano_actual,"12 THEN ConsumoNormalizadoActivaAumento END) AS INT) 'M12'
              	, CAST(sum(ConsumoNormalizadoActivaAumento) AS INT) 'Total'
              	from hecho.AumentoFacturacion af
              		inner join Dimension.Fecha f on af.llavefecha = f.LlaveFecha 
              		inner join Dimension.Fecha fa on af.llavefechaAccion = fa.LlaveFecha
              		left join Dimension.Campaña ca on ca.LlaveCampaña = af.LlaveCampaña
              		left join Hecho.Llaves l on af.LlavePuntoConsumo = l.llavePuntoConsumo 
                WHERE ", condiciones_consulta
               ," group by fa.Periodo
	                order by fa.Periodo")
    
    datos.consulta <<-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
    
    odbcClose(conexion)
    
    if (nrow(datos.consulta ) > 0) {
      nombre_meses
      totalPorMes <- colSums(datos.consulta[, c(3:14)], na.rm=TRUE)
      TotalPorMesacumulado <- cumsum(totalPorMes)
      
      datos.consultaRatio <- datos.consulta;
      datos.consultaRatio$M01 <- as.integer(datos.consultaRatio$M01/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M02 <- as.integer(datos.consultaRatio$M02/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M03 <- as.integer(datos.consultaRatio$M03/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M04 <- as.integer(datos.consultaRatio$M04/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M05 <- as.integer(datos.consultaRatio$M05/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M06 <- as.integer(datos.consultaRatio$M06/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M07 <- as.integer(datos.consultaRatio$M07/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M08 <- as.integer(datos.consultaRatio$M08/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M09 <- as.integer(datos.consultaRatio$M09/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M10 <- as.integer(datos.consultaRatio$M10/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M11 <- as.integer(datos.consultaRatio$M11/datos.consultaRatio$Ordenes)
      datos.consultaRatio$M12 <- as.integer(datos.consultaRatio$M12/datos.consultaRatio$Ordenes)
      
      columnasSinCeros <- t(t(rowSums(apply(ifelse(datos.consulta[3:14]>0,1,0), 2, function(x) as.numeric(as.character(x))))))
      
      datos.consultaRatio$Total <- as.integer((datos.consultaRatio$Total/datos.consultaRatio$Ordenes/columnasSinCeros))
      
      datos.consultaRatio[nrow(datos.consultaRatio) + 1,] = c(
        "Total",
        sum(datos.consulta$Ordenes),
        as.integer(sum(datos.consulta$M01)/sum(datos.consulta[,2][1:1])),
        as.integer(sum(datos.consulta$M02)/sum(datos.consulta[,2][1:2])),
        as.integer(sum(datos.consulta$M03)/sum(datos.consulta[,2][1:3])),
        as.integer(sum(datos.consulta$M04)/sum(datos.consulta[,2][1:4])),
        as.integer(sum(datos.consulta$M05)/sum(datos.consulta[,2][1:5])),
        as.integer(sum(datos.consulta$M06)/sum(datos.consulta[,2][1:6])),
        as.integer(sum(datos.consulta$M07)/sum(datos.consulta[,2][1:7])),
        as.integer(sum(datos.consulta$M08)/sum(datos.consulta[,2][1:8])),
        as.integer(sum(datos.consulta$M09)/sum(datos.consulta[,2][1:9])),
        as.integer(sum(datos.consulta$M10)/sum(datos.consulta[,2][1:10])),
        as.integer(sum(datos.consulta$M11)/sum(datos.consulta[,2][1:11])),
        as.integer(sum(datos.consulta$M12)/sum(datos.consulta[,2][1:12])),
        as.integer(sum(datos.consulta$Total)/sum(
                      sum(datos.consulta[,2][1:1]),
                      sum(datos.consulta[,2][1:2]),
                      sum(datos.consulta[,2][1:3]),
                      sum(datos.consulta[,2][1:4]),
                      sum(datos.consulta[,2][1:5]),
                      sum(datos.consulta[,2][1:6]),
                      sum(datos.consulta[,2][1:7]),
                      sum(datos.consulta[,2][1:8]),
                      sum(datos.consulta[,2][1:9]),
                      sum(datos.consulta[,2][1:10]),
                      sum(datos.consulta[,2][1:11]),
                      sum(datos.consulta[,2][1:12]),
                      na.rm=T
                    ))
        );
      
      datos.consultaRatio$Ordenes <- as.integer(datos.consultaRatio$Ordenes)
      datos.consultaRatio$M01 <- as.integer(datos.consultaRatio$M01)
      datos.consultaRatio$M02 <- as.integer(datos.consultaRatio$M02)
      datos.consultaRatio$M03 <- as.integer(datos.consultaRatio$M03)
      datos.consultaRatio$M04 <- as.integer(datos.consultaRatio$M04)
      datos.consultaRatio$M05 <- as.integer(datos.consultaRatio$M05)
      datos.consultaRatio$M06 <- as.integer(datos.consultaRatio$M06)
      datos.consultaRatio$M07 <- as.integer(datos.consultaRatio$M07)
      datos.consultaRatio$M08 <- as.integer(datos.consultaRatio$M08)
      datos.consultaRatio$M09 <- as.integer(datos.consultaRatio$M09)
      datos.consultaRatio$M10 <- as.integer(datos.consultaRatio$M10)
      datos.consultaRatio$M11 <- as.integer(datos.consultaRatio$M11)
      datos.consultaRatio$M12 <- as.integer(datos.consultaRatio$M12)
      datos.consultaRatio$Total <- as.integer(datos.consultaRatio$Total)
      
      
      datos.consulta <- datos.consulta %>% bind_rows(summarise(.,
                                                               across(where(is.numeric), sum),
                                                               across(where(is.character), ~"Total")))
      
      output$datos <- renderRHandsontable({
        tabla.despliegue(datos.consulta, c('Mes', 'Ordenes', nombre_meses, 'Total'))
      })
      
      output$datosRatio <- renderRHandsontable({
        tabla.despliegueRatio(datos.consultaRatio, c('Mes', 'Ordenes', nombre_meses, 'Total'))
      })
      
      
      output$plot_mes <- renderPlotly({
        plot_ly(
          x = nombre_meses,
          y = totalPorMes,
          name= 'Energía recuperada mensual',
          type= 'bar', marker=list(color='rgba(0,130,143,1)')) %>%
          layout(title= "Energía recuperada por mes", xaxis = list(title = "", tickangle = -45,
                                                                   categoryarray=nombre_meses,categoryorder="array"),
                 yaxis = list(title = "kWh"),
                 margin = list(b = 100))
      })

      output$plot_acumulado <- renderPlotly({
        plot_ly(
          x = nombre_meses,
          y = TotalPorMesacumulado,
          name= 'Energía recuperada acumulada',
          type= 'bar', marker=list(color='rgba(0,130,143,1)')) %>%
          layout(title= "Energía recuperada acumulada", xaxis = list(title = "", tickangle = -45,
                                                                     categoryarray=nombre_meses,categoryorder="array"),
                 yaxis = list(title = "kWh"),
                 margin = list(b = 100))
      })
      
      shinyjs::enable("descargar_recuperacion") 

      
    } else{
      showModal(modalDialog(
        title = "La consulta no encuentra datos que cumplan.",
        footer = tags$div(id="modal1",modalButton("Cerrar")),
        easyClose = TRUE
      ))
    }
    
    shinyjs::enable("ReiniciarControles")
    shinyjs::enable("TraerDatos")

  }, ignoreInit = TRUE)
  
  
  # Seleccionar o deselecionar todos seguimiento ----------------------------------------
  observeEvent(input$selec_tod_seguimiento,{
    sel_ancho <<- hot_to_r(input$datos_seguimiento)
    encabezados_detalle <- names(sel_ancho)
    if(input$selec_tod_seguimiento == "Todos"){
      sel_ancho[,1] <- TRUE             # Cambia primera columna a seleccionado
    }
    if(input$selec_tod_seguimiento == "Ninguno"){
      sel_ancho[,1] <- FALSE               # Cambia primera columna a deseleccionado
    }
    output$datos_seguimiento <- renderRHandsontable({
      tabla_detalle(sel_ancho, encabezados_detalle)
    })
  }, ignoreInit = TRUE)
  
  # Descargar CSV tabla recuperación -----------------------------------------------------
  output$descargar_recuperacion <- downloadHandler(
    
    filename = function() { 
      paste0("Recuperacion", Sys.Date(), ".csv")
    },
    content = function(file) {
      ordenes <- hot_to_r(input$datos)                      # Transforma los datos tomados del objeto rhandsontable.
      ordenes <-  ordenes[,2:ncol(ordenes)]
      if (nrow(ordenes) > 0 ){
        write.table(ordenes,file,sep=separador.csv, fileEncoding = "latin1", row.names = F)
      }
    },
    contentType = "csv"
  )
  
  # Descargar CSV tabla fraudulentos -----------------------------------------------------
  
  output$Descargar <- downloadHandler(
    filename = function() { 
      paste0("SeguimientoFraudulentos", Sys.Date(), ".csv")
    },
    content = function(file) {
      ordenes <- hot_to_r(input$datos_seguimiento)
      
      ordenes <- subset(ordenes, ordenes[,1] == TRUE)[,-1]      # Filtra aquellos con checkbox activo y omite primera columna
      ordenes <- transf.rhand(ordenes)
      if (nrow(ordenes) > 0 ) {
        write.table(ordenes[,2:ncol(ordenes)],file,sep=separador.csv, fileEncoding = "latin1", row.names = F)
      }
    },
    contentType = "csv"
  )
  
 
  # Generar órdenes de inspección en BD ---------------------------------------------------
  observeEvent(input$Guardar,{

    showModal(modalDialog(
    
      title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("Generar órdenes"),style="color: #00828F"),style="text-align: center;"),
      
      "Se guardarán los clientes seleccionados para ser incluidos \n en la lista de órdenes de inspección",
      hr(),
      selectInput("variable", 
                  "Seleccione campaña:",
                  nom.camp),
      textAreaInput("observ.orden", label = "Observaciones:",
                    height = "100px", rows = 4, 
                    placeholder = "Comentarios para acompañar la órden", 
                    resize = "vertical"),
      footer = list(tags$div(id="modal1",modalButton("Cancelar", icon = icon("far fa-window-close")),
                    actionButton("Guardar2", "Guardar",icon = icon("fas fa-save"),
                                 style="color: #fff; background-color: #00828f; border-color: #00828f"))
      ),
      easyClose =TRUE
    )
    )
  }, ignoreInit = TRUE)
  
  
  observeEvent(input$Guardar2, {                                          # Código para botón diálogo modal
    
    #  Grabar órdenes en BD
    
    ordenes <- hot_to_r(input$datos_seguimiento)
    ordenes <- subset(ordenes, ordenes[,1] == TRUE)[,-1]
    if (nrow(ordenes) > 0 ){
      ordenes <- transf.rhand(ordenes)                      # Transforma los datos tomados del objeto rhandsontable.

      ordenes<-cbind(ordenes[,2],                                         # Punto de consumo: 'CodigoPuntoConsumo'
                     rep(as.character(input$variable), nrow(ordenes)),    # Línea para tipo de campaña seleccionada: 'NombreCampana'
                     rep("Seguimiento fraudulentos", nrow(ordenes)),          # Reporte origen de las órdenes: 'ReporteOrigen'
                     rep(as.character(Sys.time()), nrow(ordenes)),        # Fecha y hora de generación de las órdenes: 'FechaGeneracion'
                     rep(analista, nrow(ordenes)),                        # Usuario que genera las órdenes: 'AnalistaSolicitante'
                     rep(0.5, nrow(ordenes)),                             # 'Probabilidad' de detección. ** Se debe incluir probabilidad de la campaña, por ahora es 0.5
                     0,                                         # 'RecuperacionMedia': Se asume promedio anterior
                     rep(as.character(input$observ.orden), nrow(ordenes)) #  Observación que acompaña la orden 'ObservacionOrden'
      )
      
      ordenes<-data.frame(ordenes,stringsAsFactors = F)
      #ordenes[,7]<-as.numeric(as.character(ordenes[,7]))                  # Se convierte a texto el dato tomado de la tabla
      
      #conexion2 <- odbcDriverConnect ("driver={SQL Server};server=WMENERTOLIMA\\SQL2017;database=DWSRBI_2;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" )
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      
      cad.sql<-"EXEC [dbo].[Leer_Parametro]"
      cad.sql<-paste (cad.sql," @CODIGOPARAMETRO = ?")
      parametros<- data.frame(c('InsertarInspeccion1'))
      sentencia.sql <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
      sentencia.sql <- sentencia.sql[1,1]
      parametros<- data.frame(c('InsertarInspeccion2'))
      sentencia.sql2 <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
      sentencia.sql <- paste0(sentencia.sql, sentencia.sql2[1,1])
      cad.sql <- sentencia.sql
      #cad.sql<-" INSERT INTO [DWSRBI_2].[Hecho].[OrdenInspeccion]([CodigoPuntoConsumo],[NombreCampana],[ReporteOrigen],[FechaGeneracion],[AnalistaSolicitante],[Probabilidad],[RecuperacionMedia],[ObservacionOrden])"
      cad.sql<-paste (cad.sql,"VALUES (?,?,?,?,?,?,?,?)")
      
      sqlExecute(channel = conexion,
                 cad.sql,
                 data = ordenes)              # En 'ordenes' se incluyen las órdenes a ser incluidas en la tabla 'OrdenInspeccion'
      odbcClose(conexion)
      
      ord.gen <<- ord.gen + nrow(ordenes)     # Se actualiza el contador de órdenes generadas en la sesión. Variable global
      
      output$MensajeOrdenes <- renderMenu({   # Actualiza mensaje en la barra de menú para órdenes generadas
        
        dropdownMenu(type = "notifications",  # Mensaje en barra de encabezado para indicar generación de órdenes
                     headerText = "Tiene una notificación",
                     icon =icon("fas fa-comments"),
                     notificationItem(
                       text = paste(ord.gen, "órdenes generadas en esta sesión"),
                       icon("fas fa-gavel")
                     )
        )
      })
    }
    
    removeModal()
  })
  

})



# Ejecutar aplicación -----------------------------------------------------


shinyApp(ui = ui, server = server)