# =============================================================================
#          Titulo
# =============================================================================
# 
# =============================================================================

# Carga de librerías ------------------------------------------------------
options(useFancyQuotes = FALSE)
library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
library(rhandsontable)  # Visualización tablas
library(htmlwidgets)
library(scales)
library(lubridate)
library(shinydashboard)
library(DT)
library(ggplot2)
library(plotly)         # Graficas dinámicas plotly
library(RCurl)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
#library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(stringr)
require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
#library(rintrojs)       # Presentación de ayuda en pantalla
library(openxlsx)




source("helpers.R")
source("../_shared/_filtros.R")
#reactlog_enable()

# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}


# Retornar tabla para despliegue ---------------------------------------------
tabla.despliegue <- function(tabla.temp, obj) {
  
  if(is.null(tabla.temp)){
  }else{
  
    rhandsontable(tabla.temp,
                  rowHeaders = TRUE,
                  height =380,
                  search = FALSE,
                  readOnly = TRUE
                  #,selectCallback = TRUE
                  )%>% 
      #hot_col(1, halign = "htCenter", readOnly = FALSE) %>% 
      #hot_cols(fixedColumnsLeft=1) %>%  
      hot_col(10,format="#.00", halign="htRight" ) %>% 
      #hot_heatmap(10, color_scale =c("#17F556", "#ED6D47")) %>%  # Habilitar escala de color
      hot_cols(columnSorting = TRUE)  %>%   
      #hot_context_menu(allowRowEdit = FALSE, allowColEdit = FALSE) %>%    # Bloquea opciones de menú contextual
      hot_table(highlightCol = TRUE, highlightRow = TRUE)                 # Resalta fila y columna seleccionada
  }
}

# Configuración de bd y código para api google --------------------------------------------------------------
configuracion.conexion <<- 'externalWM' # Sys.getenv("CONEXIONSHINY") #'windows', 'externalENERG' para energuate
#  'GoogleKey' CodigoParametro api google en [DWSRBI_KRONOS].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "SELECT TOP 1 ValorParametro FROM [DWSRBI_KRONOS].[Aux].[Parametros] where EstadoParametro = 1 AND   CodigoParametro = 'GoogleKey'"
api_key <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)
api_key <<- api_key[1,1]


# Contadores y llamadas --------------------------------------------------------------
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante
#api_key <- "AIzaSyAYoARt3zU_arrmeiZmMCjXhLEyRoE7Z2Q"  # Solicitar clave a WM y cambiar
Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')
locale <- Sys.getlocale(category="LC_COLLATE")
if (grepl("Spanish", locale, fixed=TRUE)) {
  separador.csv <<- ';'
} else {
  separador.csv <<- ','
}

# Captura de parámetro para URL servidor shiny -------------
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)


# Consultar datos de filtros
consultarDatosFiltros(conexion)

# Carga contenido filtros
cargarFiltrosIniciales()

# Consulta filtro rango
valores_IdentificadorProceso <<- sqlExecute(channel = conexion,
                                            query = "SELECT id, FORMAT (startTime, 'yyy-MM-dd hh:mm') + ' ('+ status+')' as identificadorProceso  FROM SMRIDB.SMR.ETLTask order by startTime desc",
                                            fetch= T,
                                            as.is=T)

codigosIdentificadorProceso <- c(unique(valores_IdentificadorProceso[c("identificadorProceso")]))
codigosIdentificadorEstados <- c("FAILED", "RUNNING", "START", "OK", "READY")

 

odbcClose(conexion)

# UI ----------------------------------------------------------------------
# ref https://stackoverflow.com/questions/31440564/adding-a-company-logo-to-shinydashboard-header

# font negro para pickerinput
col_list2 <- c("black")
colorspi <- paste0("color:",rep(c('black'),each=10),";")

dbHeader <- dashboardHeader()
dbHeader <- dashboardHeader(title = "Carga",
                            tags$li(div(
                                      img(src = 'Kronos.png',
                                          title = "Titulo", height = "30px"),
                                      style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                                    class = "dropdown"),
                            dropdownMenuOutput("MensajeOrdenes"))  # Presenta mensajes en barra de encabezado)

ui = dashboardPage(

  dbHeader,
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 300,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   fluidRow( column(width = 12,offset = 0, style='padding:0px;',
                                    box(id = "Comandos", width = 12, 
                                        status = NULL,  
                                        background = "black",
                                        fluidRow( 
                                              column(width = 2,offset = 1,
                                                         actionButton("ReiniciarControles", label = icon("fas fa-sync"),
                                                                      style="color: #fff; background-color: #0070ba; border-color: #0070ba"),
                                                         bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                                              ),
                                              column(width = 2,
                                                     offset = 1,
                                                     actionButton("TraerDatos", label = icon("fas fa-play"),
                                                                  style="color: #fff; background-color: #0070ba; border-color: #0070ba"), 
                                                     bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                                              )
                                        )
                                        
                                    ),
                                    
                                    box( id = "filtros0", width = 12, status = NULL,  background = "black",
                                         pickerInput("Proceso","Proceso:",
                                                     choices = codigosIdentificadorProceso[[1]],
                                                     selected = NULL,
                                                     multiple=T,
                                                     choicesOpt = list(
                                                       style=rep(paste0("color:black;"),length(codigosIdentificadorProceso[[1]]))),
                                                     options = list(
                                                       `none-selected-text` = "Proceso"
                                                     ))
                                    ),

                                     box( id = "filtros1", width = 12, status = NULL,  background = "black",
                                         pickerInput("Estado","Estado:",
                                                     choices = codigosIdentificadorEstados,
                                                     selected = NULL,
                                                     multiple=T,
                                                     choicesOpt = list(
                                                       style=rep(paste0("color:black;"),length(codigosIdentificadorEstados))),
                                                     options = list(
                                                       `none-selected-text` = "Estado"
                                                     ))
                                    )
                              ))
  ),
  
  # Body --------------------------------------------------------------------
  ##00828F;
  dashboardBody(    
    tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }'
                              
    )
    )
    ), # Fin estilo

    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel( type = "tabs",           
                 tabPanel("Datos",
                          icon = icon("fas fa-table"),
                          hr(),
                          useShinyjs(),
                          
                          fluidRow( 
                            box(#height = 420,
                              width = 12,
                              status = "warning",
                              solidHeader = FALSE,
                              title = "Estado de carga",
                              br(),
                              hidden(
                                div(
                                  id = 'containerDatos', 
                                  withSpinner(rHandsontableOutput("datos", height = "600px"),         # Incluir spinner de espera
                                            color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                                  )
                                )
                              )
                              
                            )),
                          hr(),
                          fluidRow(hr() ,      
                                   
                                   column(width = 2,
                                          offset = 10,
                                          shinyjs::disabled(downloadButton('Descargar', 'Descargar excel',
                                                                           style="color: #fff; background-color: #0070ba; border-color: #0070ba"),  # Se crea el botón deshabilitado para que
                                                            bsTooltip("Descargar", "Descargar archivo excel", 
                                                                      placement = "bottom", trigger = "hover", options = NULL)
                                          )                                           # sea habilitado posteriormente por código
                                          
                                   )
                          ),
                          textOutput("LlavePC"),
                          tags$head(tags$style("#LlavePC{color: white;
                                 font-size: 20px;
                                 font-style: italic;
                                 }"
                          )
                          )                         
                 ),
                 tabPanel("Ayuda",
                          icon = icon("fas fa-table"),
                          includeMarkdown("Ayuda.Rmd")
                          
                 ),
                 
                 id="TabsApp"
    )
  )
)

# Server ------------------------------------------------------------------

server <- shinyServer(function(input, output, session) { # Importante iniciar con shinyServer para que funcione la ayuda
  
  consulta.activa <<- FALSE
  datos.consulta <- NA
  tipo.grafica <- 'P'
  tabla.datos.valida <- FALSE

  # Ocultar Botones auxiliares para sincronizar paneles, paneles
  shinyjs::hide("MostrarTabla")
  shinyjs::hide("MostrarMapa")



  
  # Ayuda -------------------------------------------------------------------
  
  
  # Seleccion de fila en tabla de datos --------------------------------------------------
  observeEvent(
    input$datos_sort
    ,{

      xyz <<- input$datos_sort$data
    }
  )
  
  # Carga de datos a listas desplegables
  manejarEventosFiltros(input, output, session)
  
  # Reinicial controles
  manejarReinicioFiltros(input, output, session)
  
  # Hacer consulta basada en valores de filtros  ---------------------------
  observeEvent(input$TraerDatos, {
    noHayValores <- FALSE
    condiciones_consulta = " 1 = 1 "
    
    show('containerDatos')
    toggle(id = 'containerDatos', condition = TRUE)
    Sys.sleep(1)
    
    if(!is.null(input$Proceso)){
      condiciones_consulta <- paste0(condiciones_consulta, " AND c.task_id in ('",
                                     paste(filter(valores_IdentificadorProceso, valores_IdentificadorProceso$identificadorProceso %in% input$Proceso)$id, collapse = "','")
                                     ,"')")
    }
    
    if(!is.null(input$Estado)){
      condiciones_consulta <- paste0(condiciones_consulta, " AND (0=1")
      
      if(any(grepl("OK", input$Estado))){
        condiciones_consulta <- paste0(condiciones_consulta, " OR (c.status = 'EXITED' AND c.exitcode = 0)")
      }
      
      if(any(grepl("FAILED", input$Estado))){
          condiciones_consulta <- paste0(condiciones_consulta, " OR (c.status = 'EXITED' AND c.exitcode != 0)")
      }
      
      condiciones_consulta <- paste0(condiciones_consulta, " OR c.status in ('", paste(input$Estado, collapse = "','"),"')")
      
      condiciones_consulta <- paste0(condiciones_consulta, " )")
    }

      disable("ReiniciarControles")  
      disable("TraerDatos")
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      cad.sql<-paste0("select
	etl.name as 'Nombre ETL',
case
		when c.status = 'EXITED'
		and c.exitcode = 0 then 'OK'
		when c.status = 'EXITED'
		and c.exitcode != 0 then 'FAILED'
		else c.status
	end as 'Estado',
CONVERT(varchar(8), DATEADD(second, DATEDIFF(second, c.startTime, ISNULL(c.endTime, GETDATE())), '00:00:00'), 108) as 'HH:MM:SS',
err.text as 'Resultado',
case
		when charindex ('2', etl.name) != 0 then substring (etl.name, 1, charindex('2', etl.name) - 1)
		else etl.name
	end as Origen,
	concat (
		d.smr_name,
		case
			when tab.schema_or_owner is null then concat('@', tab.tabname)
			else concat(
				'@',
				'/',
				tab.schema_or_owner,
				'/',
				'.',
				tab.tabname
			)
		end
	) as 'Destino',
	c.createTime,
	c.startTime,
	c.endTime,
	r.command_line as 'Script',
	c.etl_id,
	c.source_id,
	c.dest_id
  from
	SMRIDB.SMR.ETLTask t
	inner join SMRIDB.SMR.ETLCommand c on c.task_id = t.id
	left join SMRIDB.SMR.ETLCommandRun r on c.run_id = r.id
	left join SMRIDB.SMR.ETLRunStdErr err on err.id = r.id
	and err.line = 1
	inner join SMRIDB.SMR.sysetl etl on etl.id = c.etl_id
	inner join SMRIDB.SMR.systable tab on tab.id = etl.dest_id
	inner join SMRIDB.SMR.sysdatabase d on d.id = tab.database_id
                      Where ", condiciones_consulta, "ORDER BY c.createTime DESC")
      datos.consulta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      odbcClose(conexion)
      
      if (nrow(datos.consulta ) > 0) {
        tabla.datos.valida <<- FALSE
        datos.consulta <- as.data.frame(datos.consulta,stringsAsFactors=FALSE)
        
        
        shinyjs::enable("Guardar")                                   # Habilita el botón para guardar
        shinyjs::enable("Descargar")
        # Armar tabla de datos para despliegue
        
        tabla.datos<- datos.consulta
        
        datos.consulta <<- datos.consulta
        
        # tabla.datos <- cbind("°" = TRUE, tabla.datos)
        tabla.datos <<- tabla.datos
        
      output$datos <- renderRHandsontable({
      tabla.despliegue(tabla.datos, data.grafica()$sel) %>%
        hot_cols(manualColumnResize = TRUE) %>%
        hot_col(1, width = 400)
      })

      } else{
        disable("Guardar")                                  # Deshabilita el botón para guardar
        disable("Descargar")
        showModal(modalDialog(
          title = "La consulta no encuentra datos que cumplan.",
          footer = tags$div(id="modal1",modalButton("Cerrar")),
          easyClose = TRUE
        ))
      }
    shinyjs::enable("ReiniciarControles")
    shinyjs::enable("TraerDatos")

  }, ignoreInit = TRUE)
  
  
  
  # Seleccionar o deselecionar todos ----------------------------------------
  
  observeEvent(input$selec.tod,{
    tabla.temp <<- hot_to_r(input$datos)    # Tabla temporal para alimentar rhandsontable
    
    if(input$selec.tod == "Todos"){
      tabla.temp[,1] <- TRUE             # Cambia primera columna a seleccionado
    }
    
    if(input$selec.tod == "Ninguno"){
      tabla.temp[,1] <- FALSE               # Cambia primera columna a deseleccionado
    }
    output$datos <- renderRHandsontable({   # Actualiza rhandsontable
    tabla.despliegue(tabla.temp, data.grafica()$sel)
    })
    # output$map <- renderGoogle_map({
    #   mapa.despliegue(tabla.temp, data.grafica()$sel, datos.consulta, TRUE,tabla.datos.valida, input) #, datos.imagen, input)
    # })
    
  }, ignoreInit = TRUE)
  
  # Descargar excel -----------------------------------------------------------
  
  output$Descargar <- downloadHandler(
    
    filename = function() { 
      #paste0("Ceros", Sys.Date(), ".csv")
      paste0("EstadoCarga", Sys.Date(), ".xlsx")
    },
    content = function(file) {
      
      #ordenes <- transf.rhand(input$datos)                      # Transforma los datos tomados del objeto rhandsontable.
      ordenes<-hot_to_r(input$datos) 
      
      wbk <- createWorkbook()
      addWorksheet( wb = wbk,  sheetName = "Data" )
       setColWidths(wbk,1,cols = 1:13,
                    widths = "auto")
      addStyle(wbk,sheet = 1, style = createStyle( fontSize = 12, textDecoration = "bold" ), rows = 1:1, cols = 1:ncol(ordenes) )
      writeData(wbk,sheet = 1,ordenes,startRow = 1,startCol = 1 )
      saveWorkbook(wbk, file)
      
    }#,
    #contentType = "csv"
  )
  
  # Generar órdenes de inspección en BD ---------------------------------------------------
  observeEvent(input$Guardar,{
 
    showModal(modalDialog(
      
      title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("Generar órdenes"),style="color: #0070ba"),style="text-align: center;"),
      
      "Se guardarán los clientes seleccionados para ser incluidos \n en la lista de órdenes de inspección",
      hr(),
      
      selectInput("variable", 
                  "Seleccione campaña:",
                  nom.camp),
      textAreaInput("observ.orden", label = "Observaciones:",
                    height = "100px", rows = 4, 
                    placeholder = "Comentarios para acompañar la órden", 
                    resize = "vertical"),
      # footer = list(tags$div(id="modal1",modalButton("Cancelar", icon = icon("fas fa-table"))),
      #               actionButton("Guardar2", "Guardar",icon = icon("fas fa-table"),
      #                            style="color: #fff; background-color: #0070ba; border-color: #0070ba")
      # ),
      footer = fluidRow(column(width=2, offset=7,tags$div(id="modal1", 
                                                          modalButton("Cancelar", icon = icon("fas fa-table")))),
                        column(width=2,actionButton("Guardar2", "Guardar",icon = icon("fas fa-table"),
                                                    style="color: #fff; background-color: #0070ba; border-color: #0070ba"))
      ),
      easyClose =TRUE
    )
    )
  }, ignoreInit = TRUE)
  
})



# Ejecutar aplicación -----------------------------------------------------


shinyApp(ui = ui, server = server)