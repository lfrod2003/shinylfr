# =============================================================================
#          Análisis Predictivo Probabilidad de Fraude y Recuperación
# =============================================================================
# 
# =============================================================================

# Carga de librerías ------------------------------------------------------
options(useFancyQuotes = FALSE)
library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
library(rhandsontable)  # Visualización tablas
library(htmlwidgets)
library(scales)
library(lubridate)
library(shinydashboard)
library(DT)
library(ggplot2)
library(plotly)         # Graficas dinámicas plotly
library(RCurl)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
#library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(stringr)
require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
#library(rintrojs)       # Presentación de ayuda en pantalla
library(openxlsx)




source("helpers.R")
source("_shared/_filtros.R")
#reactlog_enable()

# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}




# Configuración de bd y código para api google --------------------------------------------------------------
configuracion.conexion <<- 'externalWM' # Sys.getenv("CONEXIONSHINY") #'windows', 'externalENERG' para energuate
#  'GoogleKey' CodigoParametro api google en [DWSRBI_KRONOS].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "SELECT TOP 1 ValorParametro FROM [DWSRBI_KRONOS].[Aux].[Parametros] where EstadoParametro = 1 AND   CodigoParametro = 'GoogleKey'"
api_key <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)
api_key <<- api_key[1,1]


# Contadores y llamadas --------------------------------------------------------------
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante
#api_key <- "AIzaSyAYoARt3zU_arrmeiZmMCjXhLEyRoE7Z2Q"  # Solicitar clave a WM y cambiar
Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')
locale <- Sys.getlocale(category="LC_COLLATE")
if (grepl("Spanish", locale, fixed=TRUE)) {
  separador.csv <<- ';'
} else {
  separador.csv <<- ','
}

# Captura de parámetro para URL servidor shiny -------------
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql<- "SELECT [ValorParametro]  FROM [DWSRBI_KRONOS].[Aux].[Parametros]  WHERE [CodigoParametro] = 'URLshiny'"
URL.servidor.shiny <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
URL.servidor.shiny <- URL.servidor.shiny [1,1]
str.http <<- paste(URL.servidor.shiny,"hvurl/?Codigo=",sep="") # Cadena de llamada para vinculo a hoja de vida




# Captura de campañas disponibles en BD -----------------------------------
cad.sql<- "[dbo].[Leer_Campanas1]"
nom.camp <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom.camp)<-"Nombre"
nom.camp <- nom.camp  %>% filter(!is.na(Nombre))


# Consultar datos de filtros
consultarDatosFiltros(conexion)

# Carga contenido filtros
cargarFiltrosIniciales()

odbcClose(conexion)


month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
           'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
# UI ----------------------------------------------------------------------
# ref https://stackoverflow.com/questions/31440564/adding-a-company-logo-to-shinydashboard-header

# font negro para pickerinput
col_list2 <- c("black")
colorspi <- paste0("color:",rep(c('black'),each=10),";")

dbHeader <- dashboardHeader()
dbHeader <- dashboardHeader(title = "Macromedición",
                            tags$li(div(
                              img(src = 'Kronos.png',
                                  title = "Macromedición", height = "30px"),
                              style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                              class = "dropdown"),
                            dropdownMenuOutput("MensajeOrdenes"))  # Presenta mensajes en barra de encabezado)

ui = dashboardPage(

  dbHeader,
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 260,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   #introjsUI(),   # Se habilita presentación de ayuda
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   fluidRow( column(width = 12,offset = 0, style='padding:0px;',
                                    box(id = "Comandos", width = 12, 
                                        status = NULL,  
                                        background = "black",
                                        fluidRow( 
                                          column(width = 2,offset = 1,
                                                 actionButton("ReiniciarControles", label = icon("fas fa-sync"),
                                                              style="color: #fff; background-color: #0070ba; border-color: #0070ba"),
                                                 bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                                          ),
                                          column(width = 2,
                                                 offset = 1,
                                                 actionButton("TraerDatos", label = icon("fas fa-play"),
                                                              style="color: #fff; background-color: #0070ba; border-color: #0070ba"), 
                                                 bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                                          )
                                        )
                                        
                                    ),
                                    obtenerFiltrosZona(),
                                    obtenerFiltrosEmpresa()
                                    # obtenerFiltrosDepartamento()
                   )
                   # column(width = 6, offset = 0, style='padding:0px;',
                   #        
                   # )
                   )
  ),
  
  # Body --------------------------------------------------------------------
  ##00828F;
  dashboardBody(    
    tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }
                              .content-wrapper{
                               margin-left: 270px;
                              }
                              #plotSeriesPerdidas{
                               margin-bottom: 80px;
                               //box-shadow: 1px 1px 7px 3px #ccc;
                              }
                              #plotSeriesPerdidasTrimestrales{
                                margin-bottom: 80px;
                                //box-shadow: 1px 1px 7px 3px #ccc;
                              }
                              #plotSeriesPerdidasTAM{
                                //box-shadow: 1px 1px 7px 3px #ccc;
                              }
                              #plotSeriesRecupero{
                                //box-shadow: 1px 1px 7px 3px #ccc;
                              }
                              #plotSeriesSalidas{
                                //box-shadow: 1px 1px 7px 3px #ccc;
                              }
                              #plotSeries{
                                //box-shadow: 1px 1px 7px 3px #ccc;
                              }
                              .card{
                                font-weight: bold;
                                color: #43439e;
                                font-size: 17px;
                                box-shadow: 1px 1px 8px 3px #ccc;
                                float: left;
                                margin-left: 20px;
                                //height: 58px;
                              }
                              .indicador{
                                width: 10%;

                              }
                              .indicador-segmento{
                                width: 30%;
                              }
                              .card-title{
                                    text-align: center;
                                    font-weight: bold;
                                    font-size: 16px;
                              }
                              .content-trafos{
                                padding-left: 13px;
                              }
                              .blindajes{
                                  /*width: 47%;
                                  height: 106px;*/
                                 margin: 0;
                                 margin-bottom: 25px;
                              }
                              .blindajes > .card-body{
                                font-size: 10px;
                              }
                              .trafos{
                                width: 50%;
                                float: left;
                                margin-bottom: 5px;
                                padding-right: 3px;
                              }
                              .lb{
                                  margin:0;
                              }
                              .porcent{
                                color: #ff6c00;
                                font-size: 11px;
                              }
                              .text-porcent{
                                color: #7676ff;
                              }
                              .card-footer{
                                font-size: 12px;
                                color: #7676ff;
                              }
                              '
                              
    )
    )
    ), # Fin estilo
    
    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel( type = "tabs",           
                 tabPanel("Datos",
                          icon = icon("fas fa-table"),
                          hr(),
                          
                          fluidRow( 
                            box(#height = 420,
                              width = 12,
                              status = "warning",
                              solidHeader = FALSE,
                              title = "Macromedición",
                              br(),
                              HTML(
                                '
                                  <div class="card indicador text-center">
                                    <div class="card-body">
                                      <p id="card_ipactual" class="card-text"></p>
                                    </div>
                                    <div class="card-footer text-muted">
                                      IP Actual (%)
                                    </div>
                                  </div>
                                  
                                  <div class="card indicador text-center">
                                    <div class="card-body">
                                      <p id="card_trim" class="card-text"></p>
                                    </div>
                                    <div class="card-footer text-muted">
                                      TRM
                                    </div>
                                  </div>
                                  
                                  <div class="card indicador text-center">
                                    <div class="card-body">
                                      <p id="card_variacion" class="card-text"></p>
                                    </div>
                                    <div class="card-footer text-muted">
                                      VAR
                                    </div>
                                  </div>
                                  
                                  <div class="card indicador text-center">
                                    <div class="card-body">
                                      <p id="card_reincidencia" class="card-text"></p>
                                    </div>
                                    <div class="card-footer text-muted">
                                      % Reincidencia
                                    </div>
                                  </div>
                                  <div class="card indicador-segmento text-center">
                                    <div class="card-body">
                                      <p id="card_segmentacion" class="card-text">-</p>
                                    </div>
                                    <div class="card-footer text-muted">
                                      Segmentación Control Perdidas
                                    </div>
                                  </div>
                                  '
                              )
                            )),
                          hr(),
                          fluidRow(
                            column(width=5,plotlyOutput("plotSeriesPerdidasTAM", height = "236px")),
                            column(width=5,plotlyOutput("plotSeriesPerdidasTrimestrales", height = "236px")),
                            column(width=2, 
                                HTML(
                                  '
                                    <div class="card blindajes">
                                      <div class="card-body">
                                        <h5 class="card-title">Blindajes</h5>
                                        <div class="content-trafos">
                                          <div class="trafos">
                                           <label class="lb porcent" id="trafos_totales">0</label>
                                           <p class="lb text-porcent">Trafos totales</p>
                                          </div>
                                          <div class="trafos">
                                           <label class="lb porcent" id="trafos_blindados">0</label>
                                           <p class="lb text-porcent">Trafos blindados</p>
                                          </div>
                                          <div class="trafos">
                                            <label class="lb porcent" id="porcent_blindaje">0</label>
                                            <p class="lb text-porcent">% Blindaje</p>
                                          </div>
                                        </div>
                                        <p id="card_ipactual" class="card-text"></p>
                                      </div>
                                    </div>
                                    
                                    <div class="card blindajes">
                                      <div class="card-body">
                                        <h5 class="card-title">Brigadas Juridicas</h5>
                                        <div class="content-trafos">
                                          <div class="trafos">
                                           <label class="lb porcent" id="brig_denuncias">0</label>
                                           <p class="lb text-porcent">%Denuncias</p>
                                          </div>
                                          <div class="trafos">
                                           <label class="lb porcent" id="brig_sentencia">0</label>
                                           <p class="lb text-porcent">Con Sentencia</p>
                                          </div>
                                          <div class="trafos">
                                            <label class="lb porcent" id="brig_elaboracion">0</label>
                                            <p class="lb text-porcent">En Elaboración</p>
                                          </div>
                                          <div class="trafos">
                                            <label class="lb porcent" id="brig_juridico">0</label>
                                            <p class="lb text-porcent">Enviados a Juridico</p>
                                          </div>
                                          <div class="trafos">
                                            <label class="lb porcent" id="brig_cnee">0</label>
                                            <p class="lb text-porcent">Presentados a CNEE y/o MP</p>
                                          </div>
                                        </div>
                                        <p id="card_ipactual" class="card-text"></p>
                                      </div>
                                    </div>
                                    '
                                )
                            )
                          ),
                          fluidRow(
                            column(width=5,plotlyOutput("plotSeriesRecupero", height = "236px")),
                            column(width=5,plotlyOutput("plotSeriesPerdidas", height = "236px"))
                          ),
                          fluidRow(
                            column(width=5,plotlyOutput("plotSeries", height = "200px")),
                            column(width=5,plotlyOutput("plotSeriesSalidas", height = "200px"))
                          ),
                          useShinyjs(),
                          textOutput("GraficaEntradas"),
                          tags$head(tags$style("#GraficaEntradas{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaSalidas"),
                          tags$head(tags$style("#GraficaSalidas{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaPerdidasMensuales"),
                          tags$head(tags$style("#GraficaPerdidas{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaPerdidasTAM"),
                          tags$head(tags$style("#GraficaPerdidasTAM{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaPerdidasTrimestrales"),
                          tags$head(tags$style("#GraficaPerdidasTrimestrales{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaRecupero"),
                          tags$head(tags$style("#GraficaRecupero{color: white;font-size: 20px;font-style: italic;}"))
                 ),
                 tabPanel("Ayuda",
                          icon = icon("fas fa-table"),
                          includeMarkdown("Ayuda.Rmd")
                          
                 ),
                 id="TabsApp"
    )
  )
)

# Server ------------------------------------------------------------------

server <- shinyServer(function(input, output, session) { # Importante iniciar con shinyServer para que funcione la ayuda
  #output$IpActual <- renderText("0%")
  trmActual <- 0
  ipActual <- 0
  trafos_totales <- 0
  trafos_blindados <- 0
  porcent_blindaje <- 0
  
  observe({
    runjs(paste0('$("#card_ipactual").text("', ipActual, '%")'))
    runjs(paste0('$("#card_trim").text("', trmActual, '%")'))
    runjs(paste0('$("#card_variacion").text("', 0, '%")'))
    runjs(paste0('$("#card_reincidencia").text("', 0, '%")'))
  })
  
  
  consulta.activa <<- FALSE
  datos.consulta <- NA
  tipo.grafica <- 'P'
  tabla.datos.valida <- FALSE
  valores_validos_zona <<- NA
  valores_validos_region <<- NA
  valores_validos_centro <<- NA
  valores_validos_Geografia_departamento  <<- NA
  valores_validos_Geografia_municipio <<- NA
  
  valores_validos_estado <<- NA
  valores_validos_tarifa <<- NA
  valores_validos_mercado <<- NA
  
  # Ocultar Botones auxiliares para sincronizar paneles, paneles
  shinyjs::hide("MostrarTabla")
  shinyjs::hide("MostrarMapa")
  
  
  
  
  # Ayuda -------------------------------------------------------------------
  
  
  # Cambio de tab ----------------------------------------------------------------------
  observeEvent(input$TabsApp, {
    
    if (input$TabsApp == "Datos") {
      tabla.datos.valida <<- TRUE
    } else if (input$TabsApp == "Mapa") {
      click("MostrarMapa")
    }
  }, ignoreInit = TRUE)
  
  
  # Seleccion de fila en tabla de datos --------------------------------------------------
  observeEvent(
    input$datos_sort
    ,{
      
      xyz <<- input$datos_sort$data
    }
  )
  
  # output$LlavePC <- renderPrint({
  # 
  # })
  
  # Carga de datos a listas desplegables
  manejarEventosFiltros(input, output, session)
  
  # Reinicial controles
  manejarReinicioFiltros(input, output, session)
  
  # Hacer consulta basada en valores de filtros  ---------------------------
  observeEvent(input$TraerDatos, {
    noHayValores <- FALSE

    
    #meses_busqueda <- input$mesesRevisar
    #fecha_minimo <- today() %m-% months(meses_busqueda)
    #fecha_minimo <- paste0(substring(fecha_minimo,1,4),substring(fecha_minimo,6,7),"01")
    condiciones_consulta = " 1>0 " #paste0(" LlaveFecha >= ", fecha_minimo, " ")
    condiciones_consulta_consumos = "1>0"
    condiciones_consulta_consumos_base = "1>0"
    condiciones_consulta_blindaje = "1>0"
    condiciones_consulta_brigadas = "1>0"
    innerValuesZona = ""
    innerValuesSmt = ""
    innerValuesPimt = ""
    
    if(!is.null(input$anio_ip)){
      
      datf <- data.frame()
      datfBlindaje <- data.frame()
      
      for(i in 1:length(input$anio_ip)){
        annio <- input$anio_ip[i]
        f1 <- t(unique(annio))

        datf <- rbind(datf,paste0(f1),stringsAsFactors=FALSE)
      }
      
      f1 <- paste0(apply(datf, 1, function(x) paste0("'",x,"'")), collapse=",")
      condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                       " AND be.IdMes / 100 IN (",substr(f1,1,stop =1000000L),") "))
      
      
      condiciones_consulta_blindaje <- gsub("[\r\n]", "",paste0(condiciones_consulta_blindaje,
                                                       " AND be.AnioEjecucionDeProyecto IN (",substr(f1,1,stop =1000000L),") "))
      
      condiciones_consulta_consumos <- gsub("[\r\n]", "",paste0(condiciones_consulta_consumos,
                                                                " AND cn.LlaveFecha / 10000 IN (",substr(f1,1,stop =1000000L),") "))
      
    }
    
    if(!is.null(input$zona_comercial)){
      # Construir condiciones de consulta:
      if (seleccion_operativa != "no") {
        if (nrow(valores_validos) == 0) {
          noHayValores <- TRUE
        } else { 
          
          #f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos[c("LlaveZona")]), collapse=",")),1,stop =1000000L)
          valores_validos <- consulta_zona(seleccion_operativa, valores_ZonaOperativa,input)
          
          f1 <- t(unique(valores_validos[c("LlaveZona")]))
          f2 <- paste0(apply(f1, 1, function(x) paste0("(",x,")")), collapse=",")
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          
          innerValuesZona <- paste0("inner join (values ",f2,")  as z(llave) on l.llaveZona = z.llave")

          
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND be.Region IN (select z.CodigoRegion from Dimension.Zona z WHERE z.LlaveZona IN ( ",substr(f1,1,stop =1000000L),")) "))
          
          condiciones_consulta_blindaje<- gsub("[\r\n]", "",paste0(condiciones_consulta_blindaje,
                                                           " AND be.Region IN (select z.CodigoRegion from Dimension.Zona z WHERE z.LlaveZona IN ( ",substr(f1,1,stop =1000000L),")) "))
        }
      }
    }
    
    
    if(!is.null(input$circuitos)){
      if (seleccion_circuito != "no") {
        if (nrow(valores_validos_circuitos) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_circuitos[c("LlaveCircuito")]))
          f2 <- paste0(apply(f1, 1, function(x) paste0("(",x,")")), collapse=",")
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")

          # 
          # condiciones_consulta_consumos <- gsub("[\r\n]", "",paste0(condiciones_consulta_consumos,
          #                                                   " AND l.LlaveCircuito IN ( ",substr(f1,1,stop =1000000L)," ) ") )
          
          innerValuesSmt <- paste0("inner join (values ",f2,")  as s(llave) on l.LlaveCircuito = s.llave")
          
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND be.CodigoSMT IN ( select c.codigocircuito from Dimension.Circuito c where c.LlaveCircuito IN (",substr(f1,1,stop =1000000L),")) "))
        
          condiciones_consulta_blindaje <- gsub("[\r\n]", "",paste0(condiciones_consulta_blindaje,
                                                           " AND be.CodigoSMT IN ( select c.codigocircuito from Dimension.Circuito c where c.LlaveCircuito IN (",substr(f1,1,stop =1000000L),")) "))
          }
      }
    }
    
    
    
    if(!is.null(input$pimt)){
      if (seleccion_PIMT != 'no') {
        if (nrow(valores_validos_PIMT) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_PIMT[c("CodigoProyecto")]))
          f2 <- paste0(apply(f1, 1, function(x) paste0("(",x,")")), collapse=",")
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")

          #innerValuesPimt <- paste0("inner join (values ",f2,")  as p(llave) on l.LlavePIMT = p.llave")
          
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND be.CodigoProyecto IN ( ",substr(f1,1,stop =1000000L)," ) ") )
          
          condiciones_consulta_blindaje <- gsub("[\r\n]", "",paste0(condiciones_consulta_blindaje,
                                                           " AND be.CodigoProyecto IN ( ",substr(f1,1,stop =1000000L)," ) ") )
          
          condiciones_consulta_brigadas <- gsub("[\r\n]", "",paste0(condiciones_consulta_brigadas,
                                                           " AND be.CodigoProyecto IN ( ",substr(f1,1,stop =1000000L)," ) ") )
          

          condiciones_consulta_consumos_base <- gsub("[\r\n]", "",paste0(condiciones_consulta_consumos_base,
                                                            "AND CodigoProyecto IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    
    # traer valores de ceros
    
    if (noHayValores) {
      showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        
        "La consulta no genera resultados",
        footer = list(modalButton("Cancelar", icon = icon("fas fa-table"))
        ),
        easyClose =TRUE
      )
      )
    }  else {
      

      disable("ReiniciarControles")  
      disable("TraerDatos")
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      
      #recupero
      cad.sql<-paste0("select 
                        IdMes,
                        EntradasInicio,
                        SalidasInicio 
                        from 
                        Hecho.Macro1InventarioProyectos be
                        where ",condiciones_consulta," and EntradasInicio is not null and SalidasInicio is not null
                        order by IdMes ASC")
      datos.consultaProyecto <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      #blindajes
      cad.sql<-paste0("SELECT
                        CodigoProyecto,
                        TotalCTEnProyecto,
                        TotalBlindajesPorProyecto 
                  	   	from Hecho.Macro7IndicadorCoberturaBlindaje be
                  	   	where ",condiciones_consulta_blindaje)
      datos.consultaBlindaje <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      #brigadas
      cad.sql<-paste0("select 
                        count(EstadoExpediente) as CantidadExpediente,
                        EstadoExpediente  
                        from
                        Hecho.Macro10IntervencionBrigadasJuridicas be
                  	   	where ",condiciones_consulta_brigadas," group by EstadoExpediente")
      datos.consultaBrigadas <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      #entradas
      cad.sql<-paste0(" select 
                          IdMes, 
                          EntradasKWh as Entradas
                        from Hecho.Macro2CompraEnergia be
                        where ",condiciones_consulta," order by IdMes ASC")
      datos.consulta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      ##Salidas
      cad.sql<-paste0("SELECT
                  	   	IdMes, 
                  	   	EnergiaAP as salidas 
                  	   	from Hecho.Macro3AlumbradoPublicoConsumosFijos be
                  	   	where ",condiciones_consulta,"  order by IdMes ASC")
      datos.consultaSalidasAP <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT
                  	   	IdMes, 
                  	   	PeajesKWh as salidas
                  	   	from Hecho.Macro6Peajes be
                  	   	where ",condiciones_consulta," order by IdMes ASC")


      datos.consultaSalidasPeajes <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("select 
                           LlaveFecha / 100 as IdMes,
                        	 cn.csmo_n as salidas 
                        from Hecho.ConsumoNormalizado cn
                        left join Hecho.Llaves l on l.llavePuntoConsumo = cn.LlavePuntoConsumo 
                         ",innerValuesZona,"
                         ",innerValuesSmt,"
                         ",innerValuesPimt,"
                    	 where ",condiciones_consulta_consumos, " 
                      AND cn.LlavePuntoConsumo in (select NIS from Hecho.Macro5BaseSuministros where ",condiciones_consulta_consumos_base,")")
      
      

      datos.consultaSalidasConsumos <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

      
      salAP <- datos.consultaSalidasAP %>% filter(!is.na(salidas))
      salPeajes <- datos.consultaSalidasPeajes %>% filter(!is.na(salidas))
      salConsumos <- datos.consultaSalidasConsumos %>% filter(!is.na(salidas))
      
      dataProyectosInicio <- data.frame(IdMes = datos.consultaProyecto$IdMes, EntradasInicio = datos.consultaProyecto$EntradasInicio, SalidasInicio = datos.consultaProyecto$SalidasInicio ,stringsAsFactors=FALSE)
      dataSumEntradasInicio <- dataProyectosInicio %>% group_by(IdMes) %>% summarise(EntradasInicio = round(sum(as.numeric(EntradasInicio)),digits = 2))
      dataSumSalidasInicio <- dataProyectosInicio %>% group_by(IdMes) %>% summarise(SalidasInicio = round(sum(as.numeric(SalidasInicio)),digits = 2))
      
      dataEntradas <- data.frame(IdMes = datos.consulta$IdMes, Entradas = datos.consulta$Entradas ,stringsAsFactors=FALSE)
      dataSumEntradas <- dataEntradas %>% group_by(IdMes) %>% summarise(Entradas = round(sum(as.numeric(Entradas)),digits = 2))
      
      
      rvSalidas <- reactiveValues(data = data.frame())
      rvSalidas$data <- rbind(rvSalidas$data, data.frame(IdMes = as.numeric(salConsumos$IdMes), Salidas = salConsumos$salidas,stringsAsFactors=FALSE))
      rvSalidas$data <- rbind(rvSalidas$data, data.frame(IdMes = as.numeric(salPeajes$IdMes), Salidas = salPeajes$salidas,stringsAsFactors=FALSE))
      rvSalidas$data <- rbind(rvSalidas$data, data.frame(IdMes = as.numeric(salAP$IdMes), Salidas = salAP$salidas,stringsAsFactors=FALSE))
      
      dataSumSalidas <- rvSalidas$data %>% group_by(IdMes) %>% summarise(Salidas = round(sum(as.numeric(Salidas)), digits = 2))
      
      
      odbcClose(conexion)
      
      datos.consultaEnt <- dataSumEntradas
      datos.consultaSal <- dataSumSalidas
      datos.consultaProyecto <- data.frame(IdMes = dataSumEntradasInicio[1], EntradasInicio = dataSumEntradasInicio[2], SalidasInicio = dataSumSalidasInicio[2],stringsAsFactors=FALSE)
      


      listaSalidas <- reactiveValues(data = data.frame())
      listaEntradas <- reactiveValues(data = data.frame())
      listaProyectos <- reactiveValues(data = data.frame())
      
      
      ############# Entradas ######################
      
      if (nrow(datos.consultaEnt ) > 0) {
        
        #Entradas
        contador = 0
        if(!is.null(input$anio_ip)){
          for(i in 1:length(input$anio_ip)){
            contador <- contador + 1
            
            assign(paste0("rowsEnt_",i),datos.consultaEnt$IdMes >= as.numeric(paste0(input$anio_ip[i],"01")) & datos.consultaEnt$IdMes <= as.numeric(paste0(input$anio_ip[i],"12"))) 
            E_list <- mget(ls(pattern = "rowsEnt_"))
            
            assign(paste0("Entradas_",i),datos.consultaEnt[E_list[[contador]],])
            E_Entradas <- mget(ls(pattern = "Entradas_"))
            
            assign(paste0("datafrEnt_",i),data.frame(IdMes= c(paste0(input$anio_ip[i],"01"):paste0(input$anio_ip[i],"12"))))
            E_datafr <- mget(ls(pattern = "datafrEnt_"))
            
            assign(paste0("mergeEnt_",i),base::merge(x = E_datafr[[contador]],y = E_Entradas[[contador]] , by= "IdMes",all.x = TRUE))
            E_merge <- mget(ls(pattern = "mergeEnt_"))
            
            listaEntradas$data <- rbind(listaEntradas$data, data.frame(IdMes = E_merge[[contador]]$IdMes, Entradas = E_merge[[contador]]$Entradas,stringsAsFactors=FALSE))
          }
        }else{
          for(i in anioInicial:anioActual){
            contador <- contador + 1
            
            assign(paste0("rowsEnt_",i),datos.consultaEnt$IdMes >= as.numeric(paste0(i,"01")) & datos.consultaEnt$IdMes <= as.numeric(paste0(i,"12"))) 
            E_list <- mget(ls(pattern = "rowsEnt_"))
            
            assign(paste0("Entradas_",i),datos.consultaEnt[E_list[[contador]],])
            E_Entradas <- mget(ls(pattern = "Entradas_"))
            
            assign(paste0("datafrEnt_",i),data.frame(IdMes= c(paste0(i,"01"):paste0(i,"12"))))
            E_datafr <- mget(ls(pattern = "datafrEnt_"))
            
            assign(paste0("mergeEnt_",i),base::merge(x = E_datafr[[contador]],y = E_Entradas[[contador]] , by= "IdMes",all.x = TRUE))
            E_merge <- mget(ls(pattern = "mergeEnt_"))
            
            listaEntradas$data <- rbind(listaEntradas$data, data.frame(IdMes = E_merge[[contador]]$IdMes, Entradas = E_merge[[contador]]$Entradas,stringsAsFactors=FALSE))
          }
        }
        
        
        #output$GraficaEntradas <- renderPrint({
          
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')

          
          df_e <- data.frame(month,stringsAsFactors=FALSE)
          
          contador = 0
          contadorDos = 0
          totalRegistros <- nrow(listaEntradas$data)
          for(k in 1:length(periodosIp)){
            contador <- contador + 12
            if(k == 1){
              contadorDos <- contadorDos + 1
            }else{
              contadorDos <- contadorDos + 12
            }
            if(contadorDos <= totalRegistros){
              assign(paste0("entradasFig_",k),listaEntradas$data$Entradas[contadorDos:contador])
            }
          }
          
          df_e <- cbind(df_e,mget(ls(pattern = "entradasFig_")))
          
          df_e$month <- factor(df_e$month, levels = df_e[["month"]])
          
          fig_e <- plot_ly(data = df_e)
          
          # Si filtra año recorre los años seleccionados sino recorre todos
          contCol = 1
          if(!is.null(input$anio_ip)){
            for(i in 1:length(input$anio_ip)){
              contCol <- contCol + 1
              if(contCol <= ncol(df_e)){
                dkf <- data.frame(month = df_e[,1], y = df_e[,contCol],stringsAsFactors=FALSE)
                fig_e <- add_trace(fig_e, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = input$anio_ip[i])
              }
              #colnames(df_e)[contCol] <- input$anio_ip[i]
            }
          }else{
            for(i in anioInicial:anioActual){
              contCol <- contCol + 1
              if(contCol <= ncol(df_e)){
                dkf <- data.frame(month = df_e[,1], y = df_e[,contCol],stringsAsFactors=FALSE)
                fig_e <- add_trace(fig_e, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = i)
              }
              #colnames(df_e)[contCol] <- i
            }
          }
  
          fig_e <- fig_e %>% layout(title = "Entradas",
                                xaxis = list(title = "Meses",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
          fig_e <- fig_e %>% layout(showlegend = TRUE)
          output$plotSeries <- renderPlotly({fig_e})
        #})
        
      } else{
        #showModal(modalDialog(
        #  title = "La consulta no encuentra datos que cumplan1",
        #  footer = tags$div(id="modal1",modalButton("Cerrar")),
        #  easyClose = TRUE
        #))
      }
      
      
      ############# Salidas ######################
      
      if (nrow(datos.consultaSal) > 0) {
        
        contador = 0
        if(!is.null(input$anio_ip)){
          for(i in 1:length(input$anio_ip)){
            contador <- contador + 1
            
            assign(paste0("rowSal_",i),datos.consultaSal$IdMes >= as.numeric(paste0(input$anio_ip[i],"01")) & datos.consultaSal$IdMes <= as.numeric(paste0(input$anio_ip[i],"12"))) 
            S_list <- mget(ls(pattern = "rowSal_"))
            
            assign(paste0("salidas_",i),datos.consultaSal[S_list[[contador]],])
            S_salidas <- mget(ls(pattern = "salidas_"))
            
            assign(paste0("datafrSal_",i),data.frame(IdMes= c(paste0(input$anio_ip[i],"01"):paste0(input$anio_ip[i],"12"))))
            S_datafr <- mget(ls(pattern = "datafrSal_"))
            
            assign(paste0("mergeSal_",i),base::merge(x = S_datafr[[contador]],y = S_salidas[[contador]] , by= "IdMes",all.x = TRUE))
            S_merge <- mget(ls(pattern = "mergeSal_"))
            
            listaSalidas$data <- rbind(listaSalidas$data, data.frame(IdMes = S_merge[[contador]]$IdMes, Salidas = S_merge[[contador]]$Salidas,stringsAsFactors=FALSE))
          }
        }else{
          for(i in anioInicial:anioActual){
            contador <- contador + 1
            
            assign(paste0("rowSal_",i),datos.consultaSal$IdMes >= as.numeric(paste0(i,"01")) & datos.consultaSal$IdMes <= as.numeric(paste0(i,"12"))) 
            S_list <- mget(ls(pattern = "rowSal_"))
            
            assign(paste0("salidas_",i),datos.consultaSal[S_list[[contador]],])
            S_salidas <- mget(ls(pattern = "salidas_"))
            
            assign(paste0("datafrSal_",i),data.frame(IdMes= c(paste0(i,"01"):paste0(i,"12"))))
            S_datafr <- mget(ls(pattern = "datafrSal_"))
            
            assign(paste0("mergeSal_",i),base::merge(x = S_datafr[[contador]],y = S_salidas[[contador]] , by= "IdMes",all.x = TRUE))
            S_merge <- mget(ls(pattern = "mergeSal_"))
            
            listaSalidas$data <- rbind(listaSalidas$data, data.frame(IdMes = S_merge[[contador]]$IdMes, Salidas = S_merge[[contador]]$Salidas,stringsAsFactors=FALSE))
          }
        }
        
        #output$GraficaSalidas <- renderPrint({
          

          
          df_s <- data.frame(month,stringsAsFactors=FALSE)
          
          contador = 0
          contadorDos = 0
          totalRegistros <- nrow(listaSalidas$data)
          for(k in 1:length(periodosIp)){
            contador <- contador + 12
            if(k == 1){
              contadorDos <- contadorDos + 1
            }else{
              contadorDos <- contadorDos + 12
            }
            if(contadorDos <= totalRegistros){
              assign(paste0("salidasFig_",k),listaSalidas$data$Salidas[contadorDos:contador])
            }
          }
          
          df_s <- cbind(df_s,mget(ls(pattern = "salidasFig_")))
          
          df_s$month <- factor(df_s$month, levels = df_s[["month"]])
          
          fig_s <- plot_ly(data = df_s)
          
          # Si filtra año recorre los años seleccionados sino recorre todos
          contCol = 1
          if(!is.null(input$anio_ip)){
            for(i in 1:length(input$anio_ip)){
              contCol <- contCol + 1
              if(contCol <= ncol(df_s)){
                dkf <- data.frame(month = df_s[,1], y = df_s[,contCol],stringsAsFactors=FALSE)
                fig_s <- add_trace(fig_s, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = input$anio_ip[i])
              }
              #colnames(df_s)[contCol] <- input$anio_ip[i]
            }
          }else{
            for(i in anioInicial:anioActual){
              contCol <- contCol + 1
              if(contCol <= ncol(df_s)){
                dkf <- data.frame(month = df_s[,1], y = df_s[,contCol],stringsAsFactors=FALSE)
                fig_s <- add_trace(fig_s, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = i)
               #colnames(df_s)[contCol] <- i
              }
            }
          }
            
          fig_s <- fig_s %>% layout(title = "Salidas",
                                xaxis = list(title = "Meses",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
          fig_s <- fig_s %>% layout(showlegend = TRUE)
          output$plotSeriesSalidas <- renderPlotly({fig_s})
          
        #})
        
      } else{
        #showModal(modalDialog(
        #  title = "La consulta no encuentra datos que cumplan2",
        #  footer = tags$div(id="modal1",modalButton("Cerrar")),
        #  easyClose = TRUE
        #))
      }
      
      ############# Perdidas Mensuales ######################
      
      if (nrow(datos.consultaSal) > 0 && nrow(datos.consultaEnt ) > 0) {
        
        #shinyjs::show('test')
        #Se calculan perdidas
        entradas <- listaEntradas$data[2]
        salidas <- listaSalidas$data[2]
        Perdidas <- entradas - salidas
        PorcentPerdidas <- (Perdidas / entradas) * 100
        dataPerdidas <- data.frame(IdMes=listaEntradas$data[1], PerdidasPorcentaje = round(PorcentPerdidas,digits = 2),stringsAsFactors=FALSE)
        
        quitarNa <- dataPerdidas %>% filter(!is.na(Entradas))
        Ordenado <- arrange(quitarNa,desc(IdMes))
        ipActual <- Ordenado[1,]
        
        observe({
          runjs(paste0('$("#card_ipactual").text("', round(ipActual[2], digits = 2), '%")'))
        })

        #output$GraficaPerdidasMensuales <- renderPrint({
          
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          df_pm <- data.frame(month,stringsAsFactors=FALSE)
          
          contador = 0
          contadorDos = 0
          totalRegistros <- nrow(dataPerdidas)
          for(k in 1:length(periodosIp)){
            contador <- contador + 12
            if(k == 1){
              contadorDos <- contadorDos + 1
            }else{
              contadorDos <- contadorDos + 12
            }
            if(contadorDos <= totalRegistros){
              assign(paste0("perdidasmFig_",k),dataPerdidas$Entradas[contadorDos:contador])
            }
          }
          
          df_pm <- cbind(df_pm,mget(ls(pattern = "perdidasmFig_")))
          
          df_pm$month <- factor(df_pm$month, levels = df_pm[["month"]])
          
          fig_pm <- plot_ly(data = df_pm)
          
          # Si filtra año recorre los años seleccionados sino recorre todos
          contCol = 1
          if(!is.null(input$anio_ip)){
            for(i in 1:length(input$anio_ip)){
              contCol <- contCol + 1
              dkf <- data.frame(month = df_pm[,1], y = df_pm[,contCol],stringsAsFactors=FALSE)
              fig_pm <- add_trace(fig_pm, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = input$anio_ip[i])
              #colnames(df_pm)[contCol] <- input$anio_ip[i]
            }
          }else{
            for(i in anioInicial:anioActual){
              contCol <- contCol + 1
              if(contCol <= ncol(df_pm)){
                dkf <- data.frame(month = df_pm[,1], y = df_pm[,contCol],stringsAsFactors=FALSE)
                fig_pm <- add_trace(fig_pm, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = i)
              }
              #colnames(df_pm)[contCol] <- i
            }
          }
          
  
          
          fig_pm <- fig_pm %>% layout(title = "Perdidas Mensuales",
                                xaxis = list(title = "Meses",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
          fig_pm <- fig_pm %>% layout(yaxis = list(ticksuffix = "%"))
          
          fig_pm <- fig_pm %>% layout(showlegend = TRUE)
          output$plotSeriesPerdidas <- renderPlotly({fig_pm})
          
        #})
        
      } else{
        # showModal(modalDialog(
        #   title = "La consulta no encuentra datos que cumplan.",
        #   footer = tags$div(id="modal1",modalButton("Cerrar")),
        #   easyClose = TRUE
        # ))
      }
      
      
      ############# Perdidas TAM ######################
      
      if (nrow(datos.consultaSal) > 0 && nrow(datos.consultaEnt ) > 0) {
        
        #shinyjs::show('test')
        
        #output$GraficaPerdidasTAM <- renderPrint({
          
          EdataFrameInicial <- data.frame(IdMes= listaEntradas$data$IdMes, entradatotal = listaEntradas$data$Entradas,stringsAsFactors=FALSE)
          SdataFrameInicial <- data.frame(IdMes= listaSalidas$data$IdMes, salidatotal = listaSalidas$data$Salidas,stringsAsFactors=FALSE)
          #se quitan vacios
          ent <- EdataFrameInicial %>% filter(!is.na(entradatotal))
          sal <- SdataFrameInicial %>% filter(!is.na(salidatotal))
          #se ordenan desde el ultimo mes reciente
          EdataFrameOrdenado <- arrange(ent,desc(IdMes))
          SdataFrameOrdenado <- arrange(sal,desc(IdMes))

          
          E_dataframeMeses <- data.frame(IdMes = EdataFrameOrdenado$IdMes, totalEntrada = 0,stringsAsFactors=FALSE)
          S_dataframeMeses <- data.frame(IdMes = SdataFrameOrdenado$IdMes, totalSalida= 0,stringsAsFactors=FALSE)
          
          mesFin <- 11
          for(i in 1:nrow(EdataFrameOrdenado)){
            mesFin <- mesFin + 1
            
            if(mesFin <= nrow(EdataFrameOrdenado)){
              E_ultimos12Meses <- data.frame(EdataFrameOrdenado$entradatotal[i:mesFin],stringsAsFactors=FALSE)
              E_dataframeMeses$totalEntrada[i:i] <- colSums(E_ultimos12Meses) / 12
            }else{
              E_ultimos12Meses <- data.frame(EdataFrameOrdenado$entradatotal[i:nrow(EdataFrameOrdenado)],stringsAsFactors=FALSE)
              E_dataframeMeses$totalEntrada[i:i] <- colSums(E_ultimos12Meses) / 12
            }
          }
          
          mesFin <- 11
          for(i in 1:nrow(SdataFrameOrdenado)){
            mesFin <- mesFin + 1
            
            if(mesFin <= nrow(SdataFrameOrdenado)){
              S_ultimos12Meses <- data.frame(SdataFrameOrdenado$salidatotal[i:mesFin],stringsAsFactors=FALSE)
              S_dataframeMeses$totalSalida[i:i] <- colSums(S_ultimos12Meses) / 12
            }else{
              S_ultimos12Meses <- data.frame(SdataFrameOrdenado$salidatotal[i:nrow(SdataFrameOrdenado)],stringsAsFactors=FALSE)
              S_dataframeMeses$totalSalida[i:i] <- colSums(S_ultimos12Meses) / 12
            }
          }

          datosMerge <- base::merge(x = E_dataframeMeses,y = S_dataframeMeses , by= "IdMes",all.x = TRUE)
          PorcentPerdidasTAM <-  round(((datosMerge$totalEntrada - datosMerge$totalSalida) / datosMerge$totalEntrada) * 100, digits = 2)

          
          
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          df_ptam <- data.frame(month,stringsAsFactors=FALSE)
          
          contador = 0
          contadorDos = 0
          totalRegistros <- length(PorcentPerdidasTAM)
          for(k in 1:length(periodosIp)){
            contador <- contador + 12
            if(k == 1){
              contadorDos <- contadorDos + 1
            }else{
              contadorDos <- contadorDos + 12
            }
            if(contadorDos <= totalRegistros){
              assign(paste0("perdidasTamFig_",k),PorcentPerdidasTAM[contadorDos:contador])
            }
          }
          
          df_ptam <- cbind(df_ptam,mget(ls(pattern = "perdidasTamFig_")))
          
          df_ptam$month <- factor(df_ptam$month, levels = df_ptam[["month"]])
          
          fig_ptam <- plot_ly(data = df_ptam)
          
          # Si filtra año recorre los años seleccionados sino recorre todos
          contCol = 1
          if(!is.null(input$anio_ip)){
            for(i in 1:length(input$anio_ip)){
              contCol <- contCol + 1
              if(contCol <= ncol(df_ptam)){
                dkf <- data.frame(month = df_ptam[,1], y = df_ptam[,contCol],stringsAsFactors=FALSE)
                fig_ptam <- add_trace(fig_ptam, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = input$anio_ip[i])
              }
              #colnames(df_ptam)[contCol] <- input$anio_ip[i]
            }
          }else{
            for(i in anioInicial:anioActual){
              contCol <- contCol + 1
              if(contCol <= ncol(df_ptam)){
                dkf <- data.frame(month = df_ptam[,1], y = df_ptam[,contCol],stringsAsFactors=FALSE)
                fig_ptam <- add_trace(fig_ptam, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = i)
              }
              #colnames(df_ptam)[contCol] <- i
            }
          }
          
          
        
          fig_ptam <- fig_ptam %>% layout(title = "Pérdidas TAM",
                                xaxis = list(title = "Meses",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))

          fig_ptam <- fig_ptam %>% layout(yaxis = list(ticksuffix = "%"))

          fig_ptam <- fig_ptam %>% layout(showlegend = TRUE)
          output$plotSeriesPerdidasTAM <- renderPlotly({fig_ptam})
          # 
        #})
        
      } else{
        # showModal(modalDialog(
        #   title = "La consulta no encuentra datos que cumplan.",
        #   footer = tags$div(id="modal1",modalButton("Cerrar")),
        #   easyClose = TRUE
        # ))
      }
      
      ############# Perdidas Trimestrales ######################
      
      if (nrow(datos.consultaSal) > 0 && nrow(datos.consultaEnt ) > 0) {
        
        #shinyjs::show('test')
        EdataFrameInicial <- data.frame(IdMes= listaEntradas$data$IdMes, entradatotal = listaEntradas$data$Entradas,stringsAsFactors=FALSE)
        SdataFrameInicial <- data.frame(IdMes= listaSalidas$data$IdMes, salidatotal = listaSalidas$data$Salidas,stringsAsFactors=FALSE)
        #se quitan vacios
        ent <- EdataFrameInicial %>% filter(!is.na(entradatotal))
        sal <- SdataFrameInicial %>% filter(!is.na(salidatotal))
        #se ordenan desde el ultimo mes reciente
        EdataFrameOrdenado <- arrange(ent,desc(IdMes))
        SdataFrameOrdenado <- arrange(sal,desc(IdMes))
        
        
        E_dataframeMeses <- data.frame(IdMes = EdataFrameOrdenado$IdMes, totalEntrada = 0,stringsAsFactors=FALSE)
        S_dataframeMeses <- data.frame(IdMes = SdataFrameOrdenado$IdMes, totalSalida= 0,stringsAsFactors=FALSE)
        
        mesFin <- 2
        for(i in 1:nrow(EdataFrameOrdenado)){
          mesFin <- mesFin + 1
          
          if(mesFin <= nrow(EdataFrameOrdenado)){
            E_ultimos3Meses <- data.frame(EdataFrameOrdenado$entradatotal[i:mesFin],stringsAsFactors=FALSE)
            E_dataframeMeses$totalEntrada[i:i] <- colSums(E_ultimos3Meses) / 3
          }else{
            E_ultimos3Meses <- data.frame(EdataFrameOrdenado$entradatotal[i:nrow(EdataFrameOrdenado)],stringsAsFactors=FALSE)
            E_dataframeMeses$totalEntrada[i:i] <- colSums(E_ultimos3Meses) / 3
          }
        }
        
        mesFin <- 2
        for(i in 1:nrow(SdataFrameOrdenado)){
          mesFin <- mesFin + 1
          
          if(mesFin <= nrow(SdataFrameOrdenado)){
            S_ultimos3Meses <- data.frame(SdataFrameOrdenado$salidatotal[i:mesFin],stringsAsFactors=FALSE)
            S_dataframeMeses$totalSalida[i:i] <- colSums(S_ultimos3Meses) / 3
          }else{
            S_ultimos3Meses <- data.frame(SdataFrameOrdenado$salidatotal[i:nrow(SdataFrameOrdenado)],stringsAsFactors=FALSE)
            S_dataframeMeses$totalSalida[i:i] <- colSums(S_ultimos3Meses) / 3
          }
        }
        
        datosMerge <- base::merge(x = E_dataframeMeses,y = S_dataframeMeses , by= "IdMes",all.x = TRUE)
        PorcentPerdidasTAM <-  round(((datosMerge$totalEntrada - datosMerge$totalSalida) / datosMerge$totalEntrada) * 100, digits = 2)
        frameTAM <- data.frame(IdMes = datosMerge$IdMes, PorcentPerdidasTAM = PorcentPerdidasTAM)
        
        
        quitarNa <- frameTAM %>% filter(!is.na(PorcentPerdidasTAM))
        Ordenado <- arrange(quitarNa,desc(IdMes))
        trmActual <- Ordenado[1,]
        variacion <- trmActual[2] - ipActual[2]
        segmentacion <- paste0("")
        if(variacion < 0){
          segmentacion <- paste0("Descenso")
        }else if(variacion > 0){
          segmentacion <- paste0("Alza")
        }else{
          segmentacion <- paste0("Sin Variación")
        }
        observe({
          runjs(paste0('$("#card_trim").text("', round(trmActual[2], digits = 2), '%")'))
          runjs(paste0('$("#card_variacion").text("', round(variacion, digits = 2), '%")'))
          runjs(paste0('$("#card_segmentacion").text("', segmentacion, '")'))
        })
        
        #output$GraficaPerdidasTrimestrales <- renderPrint({
        
        month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                   'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
        
        df_ptrimes <- data.frame(month,stringsAsFactors=FALSE)
        
        contador = 0
        contadorDos = 0
        totalRegistros <- length(PorcentPerdidasTAM)
        for(k in 1:length(periodosIp)){
          contador <- contador + 12
          if(k == 1){
            contadorDos <- contadorDos + 1
          }else{
            contadorDos <- contadorDos + 12
          }
          if(contadorDos <= totalRegistros){
            assign(paste0("perdidasTFig_",k),PorcentPerdidasTAM[contadorDos:contador])
          }
        }
        
        df_ptrimes <- cbind(df_ptrimes,mget(ls(pattern = "perdidasTFig_")))
        
        df_ptrimes$month <- factor(df_ptrimes$month, levels = df_ptrimes[["month"]])
        
        fig_ptrimes <- plot_ly(data = df_ptrimes)
        
        # Si filtra año recorre los años seleccionados sino recorre todos
        contCol = 1
        if(!is.null(input$anio_ip)){
          for(i in 1:length(input$anio_ip)){
            contCol <- contCol + 1
            if(contCol <= ncol(df_ptrimes)){
              dkf <- data.frame(month = df_ptrimes[,1], y = df_ptrimes[,contCol],stringsAsFactors=FALSE)
              fig_ptrimes <- add_trace(fig_ptrimes, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = input$anio_ip[i])
            }
            #colnames(df_ptrimes)[contCol] <- input$anio_ip[i]
          }
        }else{
          for(i in anioInicial:anioActual){
            contCol <- contCol + 1
            if(contCol <= ncol(df_ptrimes)){
              dkf <- data.frame(month = df_ptrimes[,1], y = df_ptrimes[,contCol],stringsAsFactors=FALSE)
              fig_ptrimes <- add_trace(fig_ptrimes, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = i)
            }
            #colnames(df_ptrimes)[contCol] <- i
          }
        }
          
          
        fig_ptrimes <- fig_ptrimes %>% layout(title = "Pérdidas Trimestrales",
                                xaxis = list(title = "Meses",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
        fig_ptrimes <- fig_ptrimes %>% layout(yaxis = list(ticksuffix = "%"))
          
        fig_ptrimes <- fig_ptrimes %>% layout(showlegend = TRUE)
          output$plotSeriesPerdidasTrimestrales <- renderPlotly({fig_ptrimes})
          # 
        #)
        
      } else{
        # showModal(modalDialog(
        #   title = "La consulta no encuentra datos que cumplan.",
        #   footer = tags$div(id="modal1",modalButton("Cerrar")),
        #   easyClose = TRUE
        # ))
      }
      
      
      
      ############# Recupero Mensual ######################
      
      if (nrow(datos.consultaProyecto ) > 0) {
        
        
        contador = 0
        if(!is.null(input$anio_ip)){
          for(i in 1:length(input$anio_ip)){
            contador <- contador + 1
            
            assign(paste0("rowsPry_",i),datos.consultaProyecto$IdMes >= as.numeric(paste0(input$anio_ip[i],"01")) & datos.consultaProyecto$IdMes <= as.numeric(paste0(input$anio_ip[i],"12"))) 
            Pr_list <- mget(ls(pattern = "rowsPry_"))
            
            assign(paste0("EntradasInicio_",i),datos.consultaProyecto[Pr_list[[contador]],])
            Pr_EntradasInicio <- mget(ls(pattern = "EntradasInicio_"))
            
            assign(paste0("datafrPry_",i),data.frame(IdMes= c(paste0(input$anio_ip[i],"01"):paste0(input$anio_ip[i],"12"))))
            Pr_datafr <- mget(ls(pattern = "datafrPry_"))
            
            assign(paste0("mergPr_",i),base::merge(x = Pr_datafr[[contador]],y = Pr_EntradasInicio[[contador]] , by= "IdMes",all.x = TRUE))
            Pr_merge <- mget(ls(pattern = "mergPr_"))
            
            listaProyectos$data <- rbind(listaProyectos$data, data.frame(IdMes = Pr_merge[[contador]]$IdMes, EntradasInicio = Pr_merge[[contador]]$EntradasInicio, SalidasInicio = Pr_merge[[contador]]$SalidasInicio,stringsAsFactors=FALSE))
          }
        }else{
          for(i in anioInicial:anioActual){
            contador <- contador + 1
            
            assign(paste0("rowsPry_",i),datos.consultaProyecto$IdMes >= as.numeric(paste0(i,"01")) & datos.consultaProyecto$IdMes <= as.numeric(paste0(i,"12"))) 
            Pr_list <- mget(ls(pattern = "rowsPry_"))
            
            assign(paste0("EntradasInicio_",i),datos.consultaProyecto[Pr_list[[contador]],])
            Pr_EntradasInicio <- mget(ls(pattern = "EntradasInicio_"))
            
            assign(paste0("datafrPry_",i),data.frame(IdMes= c(paste0(i,"01"):paste0(i,"12"))))
            Pr_datafr <- mget(ls(pattern = "datafrPry_"))
            
            assign(paste0("mergPr_",i),base::merge(x = Pr_datafr[[contador]],y = Pr_EntradasInicio[[contador]] , by= "IdMes",all.x = TRUE))
            Pr_merge <- mget(ls(pattern = "mergPr_"))
            
            listaProyectos$data <- rbind(listaProyectos$data, data.frame(IdMes = Pr_merge[[contador]]$IdMes, EntradasInicio = Pr_merge[[contador]]$EntradasInicio, SalidasInicio = Pr_merge[[contador]]$SalidasInicio,stringsAsFactors=FALSE))
          }
        }
        
        #output$GraficaRecupero <- renderPrint({
        if(nrow(listaEntradas$data) > 0 && nrow(listaSalidas$data) > 0){
          tablaRecupero <- data.frame(listaProyectos$data , listaEntradas$data[2], listaSalidas$data[2],stringsAsFactors=FALSE)
        }else{
          tablaRecupero <- data.frame(listaProyectos$data , Entradas = 0, Salidas = 0,stringsAsFactors=FALSE)
        }
        #entinicial - entactual
        MenorCompra <- tablaRecupero$EntradasInicio - tablaRecupero$Entradas
        #salActual - salInicial
        MayorVenta <- tablaRecupero$Salidas - tablaRecupero$SalidasInicio

        RecuperoTotal <- round(MenorCompra + MayorVenta, digits = 2)
          
        month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                   'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
        
        df_recupero <- data.frame(month,stringsAsFactors=FALSE)
        
        contador = 0
        contadorDos = 0
        totalRegistros <- length(RecuperoTotal)
        for(k in 1:length(periodosIp)){
          contador <- contador + 12
          if(k == 1){
            contadorDos <- contadorDos + 1
          }else{
            contadorDos <- contadorDos + 12
          }
          if(contadorDos <= totalRegistros){
            assign(paste0("recuperoFig_",k),RecuperoTotal[contadorDos:contador])
          }
        }
        
        df_recupero <- cbind(df_recupero,mget(ls(pattern = "recuperoFig_")))
        
        df_recupero$month <- factor(df_recupero$month, levels = df_recupero[["month"]])
        
        fig_recupero <- plot_ly(data = df_recupero)
        
        # Si filtra año recorre los años seleccionados sino recorre todos
        contCol = 1
        if(!is.null(input$anio_ip)){
          for(i in 1:length(input$anio_ip)){
            contCol <- contCol + 1
            if(contCol <= ncol(df_recupero)){
              dkf <- data.frame(month = df_recupero[,1], y = df_recupero[,contCol],stringsAsFactors=FALSE)
              fig_recupero <- add_trace(fig_recupero, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = input$anio_ip[i])
            }
            #colnames(df_recupero)[contCol] <- input$anio_ip[i]
          }
        }else{
          for(i in anioInicial:anioActual){
            contCol <- contCol + 1
            if(contCol <= ncol(df_recupero)){
              dkf <- data.frame(month = df_recupero[,1], y = df_recupero[,contCol],stringsAsFactors=FALSE)
              fig_recupero <- add_trace(fig_recupero, y=~y, x=~month, data=dkf,type="scatter", mode="lines+markers", name = i)
            }
            #colnames(df_recupero)[contCol] <- i
          }
        }
        
          
        fig_recupero <- fig_recupero %>% layout(title = "Recupero Mensual",
                                xaxis = list(title = "Meses",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
        fig_recupero <- fig_recupero %>% layout(showlegend = TRUE)
          output$plotSeriesRecupero <- renderPlotly({fig_recupero})
          
        #})
        
      } else{
        # showModal(modalDialog(
        #   title = "La consulta no encuentra datos que cumplan.",
        #   footer = tags$div(id="modal1",modalButton("Cerrar")),
        #   easyClose = TRUE
        # ))
      }
      
      
      ################ Blindajes #####################
      if(nrow(datos.consultaBlindaje) > 0){
        
        datatrafosTotales <- data.frame(as.numeric(datos.consultaBlindaje$TotalCTEnProyecto),stringsAsFactors=FALSE)
        trafosTotales <- colSums(datatrafosTotales)
        
        datatrafosBlindados <- data.frame(as.numeric(datos.consultaBlindaje$TotalBlindajesPorProyecto),stringsAsFactors=FALSE)
        trafosBlindados <- colSums(datatrafosBlindados)
        
        porcentajeBlindaje <- (trafosBlindados / trafosTotales) * 100
        
        #,TotalBlindajesPorProyecto = datos.consultaBlindaje$TotalBlindajesPorProyecto
        
        
        observe({
           runjs(paste0('$("#trafos_totales").text("', trafosTotales, '")'))
           runjs(paste0('$("#trafos_blindados").text("', trafosBlindados, '")'))
           runjs(paste0('$("#porcent_blindaje").text("', round(porcentajeBlindaje , digits = 2), '%")'))
        })
      }
      
      
      ############### Brigadas ###############
      if(nrow(datos.consultaBrigadas) > 0){
        tablaBrigadas <- datos.consultaBrigadas
        
        cantidadSentencia <- filter(tablaBrigadas, grepl('Con Sentencia', EstadoExpediente))
        cantidadElaboracion <- filter(tablaBrigadas, grepl('En elaboración', EstadoExpediente))
        cantidadJuridico <- filter(tablaBrigadas, grepl('Enviados a Jurídico', EstadoExpediente))
        cantidadCnee <- filter(tablaBrigadas, grepl('Presentados a CNEE y/o MP', EstadoExpediente))
        
        if(nrow(cantidadSentencia) > 0){
          observe({
            runjs(paste0('$("#brig_sentencia").text("', cantidadSentencia$CantidadExpediente, '")'))
          })
        }else{
          observe({
            runjs(paste0('$("#brig_sentencia").text("', 0, '")'))
          })
        }
        
        if(nrow(cantidadElaboracion) > 0){
          observe({
            runjs(paste0('$("#brig_elaboracion").text("', cantidadElaboracion$CantidadExpediente, '")'))
          })
        }else{
          observe({
            runjs(paste0('$("#brig_elaboracion").text("', 0, '")'))
          })  
        }
        
        if(nrow(cantidadJuridico) > 0){
          observe({
            runjs(paste0('$("#brig_juridico").text("', cantidadJuridico$CantidadExpediente, '")'))
          })
        }else{
          observe({
            runjs(paste0('$("#brig_juridico").text("', 0, '")'))
          })  
        }
        
        if(nrow(cantidadCnee) > 0){
          observe({
            runjs(paste0('$("#brig_cnee").text("',cantidadCnee$CantidadExpediente, '")'))
          })
        }else{
          observe({
            runjs(paste0('$("#brig_cnee").text("',0, '")'))
          })
        }

      }

      # Validación de consultas -> Si no encuentra datos en ninguna consulta entonces muestra modal
      if(nrow(datos.consultaBrigadas) <= 0 &&
         nrow(datos.consultaProyecto ) <= 0 &&
         nrow(datos.consultaSal) <= 0 && 
         nrow(datos.consultaEnt ) <= 0){
          showModal(modalDialog(
            title = "¡Información!",
            "La consulta no encuentra datos que cumplan.",
            easyClose = TRUE,
            footer = tagList(
              modalButton("Cerrar")
            )
          ))




      }
      
      
      shinyjs::enable("ReiniciarControles")
      shinyjs::enable("TraerDatos")
    }
    
  }, ignoreInit = TRUE)
  
  # Presentación del mapa --------------------------------------------------- 
  # output$map <- renderGoogle_map({
  #   if (exists("tabla.datos")) {
  #     mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta, FALSE, tabla.datos.valida, input) #, datos.imagen, input)
  #   }
  # })
  
  # Cambiar tipo de gráfica  ----------------------------------------
  observeEvent(input$selec.graf,{
    
    valorSwitch <- input$selec.graf
    if (valorSwitch == TRUE) {
      tipo.grafica <<- 'B'
      output$plot <- renderPlotly({
        p <- ggplot(tabla.datos, mapping = aes(x = AcumuladoConsumoCero)) +
          geom_bar(color ="#0070ba",fill= "#0070ba",size =1) + theme_bw()+
          ylab("Conteo") +
          xlab("Períodos consecutivos en cero")
        # Manejo de selección en gráfica
        obj <- data.grafica()$sel
        if(nrow(obj)!=0) {
          p <- p + geom_bar(data=obj,color="orange",fill="orange")
        }
        ggplotly(p,source="master")
      })
    } else {
      tipo.grafica <<- 'P'
      output$plot <- renderPlotly({
        p <-
          ggplot(tabla.datos,
                 mapping = aes(x = AcumuladoConsumoCero, y = PromedioActiva6CN, text = texto)) +
          geom_point(color = "#0070ba", size = 1) + theme_bw() +
          ylab("Consumo promedio 6 meses anteriores [kWh]") +
          xlab("Períodos consecutivos en cero")
        
        # Manejo de selección en gráfica
        obj <- data.grafica()$sel
        if(nrow(obj)!=0) {
          p <- p + geom_point(data=obj,color="orange")
        }
        ggplotly(p, source = "master")
      })
    }
  }, ignoreInit = TRUE)
  
  
})



# Ejecutar aplicación -----------------------------------------------------


shinyApp(ui = ui, server = server)