# Encabezado de programa ------------------------------------------------------
# =============================================================================
#                             Series de tiempo
# =============================================================================
# 
# Autor:                Nelson Beltrán Celis - F Rodríguez
# Fecha de creación:    06.03.2021
# Versión:              1.0
# Descripción:
# 
# Funciones auxiliares para tablero de cálculo de series 


# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}


# Función para actualizar controles -----------------------------------------

# actualizar.filtros <-
#   function (session,
#             input,
#             atributoCambiado,
#             ValoresAtributo,
#             valores.atributos, idx) {
#     print(paste0(
#       'actualizar.filtros: ',
#       atributoCambiado,
#       '/',
#       paste(ValoresAtributo, collapse = ',')
#     ))
#     
#     f1 <-
#       valores.atributos %>% filter(Atributo == atributoCambiado) %>% filter(Nombre %in% ValoresAtributo)
#     
#     if (atributoCambiado == "Estrato") {
#       idx.filtrado <- idx %>% filter(idx$LlaveEstrato %in% f1$Llave)
#     } else     if (atributoCambiado== "Actividad") {
#       idx.filtrado <-
#         idx %>% filter(idx$LlaveActividadEconomica %in% f1$Llave)
#     } else if (atributoCambiado == "Ciclo") {
#       idx.filtrado <- idx %>% filter(idx$LlaveCiclo %in% f1$Llave)
#     } else if (atributoCambiado == "Circuito") {
#       idx.filtrado <- idx %>% filter(idx$LlaveCircuito %in% f1$Llave)
#     } else if (atributoCambiado == "Municipio") {
#       idx.filtrado <- idx %>% filter(idx$LlaveGeografia %in% f1$Llave)
#     }else if (atributoCambiado == "Zona") {
#       idx.filtrado <- idx %>% filter(idx$LlaveZona %in% f1$Llave)
#     }else if (atributoCambiado == "Transformador") {
#       idx.filtrado <- idx %>% filter(idx$LlaveTransformador %in% f1$Llave)
#     }
#     
#     datos.filtrados <- valores.atributos  %>% 
#       filter((Atributo=='Zona' & Llave %in% idx.filtrado$LlaveZona) | 
#                (Atributo=='Municipio' & Llave %in% idx.filtrado$LlaveGeografia) |
#                (Atributo=='Circuito' & Llave %in% idx.filtrado$LlaveCircuito) |
#                (Atributo=='Ciclo' & Llave %in% idx.filtrado$LlaveCiclo) |
#                (Atributo=='Actividad' & Llave %in% idx.filtrado$LlaveActividad) |
#                (Atributo=='Transformador' & Llave %in% idx.filtrado$LlaveTransformador) |
#                (Atributo=='Estrato' & Llave %in% idx.filtrado$LlaveEstrato))
#     
#     # Actualizar controles
#     # Actualizar control Estrato
#     if (atributoCambiado != "Estrato") {
#       valor.seleccionado <- input$estrato
#       atr <- valores.atributos %>% filter(Atributo == 'Estrato') %>% filter(Llave %in% idx.filtrado$LlaveEstrato)
#       
#       updatePickerInput(session,
#                         "estrato",
#                         choices = c( atr$Nombre),
#                         selected = valor.seleccionado)
#     }
#     
#     # Actualizar control actividad
#     if (atributoCambiado != "Actividad") {
#       valor.seleccionado <- input$actividad
#       atr <- valores.atributos %>% filter(Atributo == 'Actividad') %>% filter(Llave %in% idx.filtrado$LlaveActividadEconomica)
#       
#       updatePickerInput(session,
#                         "actividad",
#                         choices = c( atr$Nombre),
#                         selected = valor.seleccionado)
#     }
#     
#     # Actualizar control ciclo
#     if (atributoCambiado != "Ciclo") {
#       valor.seleccionado <- input$ciclo
#       atr <- valores.atributos %>% filter(Atributo == 'Ciclo') %>% filter(Llave %in% idx.filtrado$LlaveCiclo)
#       
#       updatePickerInput(session,
#                         "ciclo",
#                         choices = c(atr$Nombre),
#                         selected = valor.seleccionado)
#     }
#     
#     # Actualizar control circuito
#     if (atributoCambiado != "Circuito") {
#       valor.seleccionado <- input$circuito
#       atr <- valores.atributos %>% filter(Atributo == 'Circuito') %>% filter(Llave %in% idx.filtrado$LlaveCircuito)
#       
#       updatePickerInput(session,
#                         "circuito",
#                         choices = c(atr$Nombre),
#                         selected = valor.seleccionado)
#     }
#     
#     # actualizar control municipio
#     if (atributoCambiado != "Municipio") {
#       valor.seleccionado <- input$municipio
#       atr <- valores.atributos %>% filter(Atributo == 'Municipio') %>% filter(Llave %in% idx.filtrado$LlaveGeografia)
#       
#       #updateSelectInput(session,
#       updatePickerInput(session,
#                         "municipio",
#                         choices = c(atr$Nombre),
#                         selected = valor.seleccionado)
#     }
#     # Actualizar control zona
#     if (atributoCambiado != "Zona") {
#       valor.seleccionado <- input$zona
#       atr <- valores.atributos %>% filter(Atributo == 'Zona') %>% filter(Llave %in% idx.filtrado$LlaveZona)
#       
#       updatePickerInput(session,
#                         "zona",
#                         choices = c(atr$Nombre),
#                         selected = valor.seleccionado)
#     }
#     # Actualizar control transformador
#     if (atributoCambiado != "Transformador") {
#       valor.seleccionado <- input$transformador
#       atr <- valores.atributos %>% filter(Atributo == 'Transformador') %>% filter(Llave %in% idx.filtrado$LlaveTransformador)
#       
#       updatePickerInput(session,
#                         "transformador",
#                         choices = c(atr$Nombre),
#                         selected = valor.seleccionado)
#     }
#     
#   }

# Obtener datos según filtros --------------------------------------------------
# obtener.datos.filtrados <- function(input, output, valores.atributos){
# 
#   # Construir condiciones de consulta:
#   browser()
#   noHayValores <- FALSE
#   condiciones_Zona <- " "
#   if (seleccion_operativa != "no") {
#     if ( nrow(valores_validos) == 0) {
#       noHayValores <- TRUE
#     } else {
#       f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos[c("LlaveZona")]), collapse=',')),2,stop =1000000L)
#       
#       condiciones_Zona <- gsub("[\r\n]", "",paste0(" Llavezona IN ( ",substr(f1,1,stop =1000000L),"  ") )
#     }
#   }
#   
#   condiciones_Geografia <- " "
#   if (seleccion_geografia != "no") {
#     if (nrow(valores_validos_Geografia) == 0) {
#       noHayValores <- TRUE
#     } else {
#       f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos_Geografia[c("LlaveGeografia")]), collapse=',')),2,stop =1000000L)
#       
#       condiciones_Geografia <- gsub("[\r\n]", "",paste0(" LlaveGeografia IN ( ",substr(f1,1,stop =1000000L)," ) ") )
#     }
#   }
#   
#   condiciones_consulta = " "
#   if (nchar(condiciones_Zona) > 17) {
#     condiciones_consulta <- paste0(condiciones_consulta, " ", condiciones_Zona)
#   }
#   if (nchar(condiciones_Geografia) > 22) {
#     if (nchar(condiciones_consulta) > 10) {
#       condiciones_consulta <- paste0(condiciones_consulta, " AND ")
#     }
#     condiciones_consulta <- paste0(condiciones_consulta, " ", condiciones_Geografia)
#   }
#   
# 
#   
# # 
# #   if (nchar(condiciones.consulta) <= 1) {
# #     df <- data.frame(matrix(ncol = 1, nrow = 0))
# #     return(df) 
# #   }
#   
#   # traer valores de series
#   if (noHayValores) {
#     showModal(modalDialog(
#       title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
#       
#       "La consulta no genera resultados",
#       footer = list(modalButton("Cancelar", icon = icon("far fa-window-close"))
#       ),
#       easyClose =TRUE
#     )
#     )
#     datos.consulta <- data.frame(name = character())
#   } else {
#     if (nchar(condiciones_consulta) > 10) {
#       condiciones_consulta <- paste0(" WHERE ", condiciones_consulta)
#     }
#     config <- config::get(config=configuracion.conexion)
#     config.conexion <- config$conexion
#     conexion <- odbcDriverConnect (config.conexion)
#     cad.sql<-"EXEC [dbo].[Dataset_ConsumosPrediccionSeries_shiny]"
#     cad.sql<-paste (cad.sql,"  @CONDICION = ? ")
#     parametros<- data.frame(condiciones_consulta)
#     datos.consulta <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
#     
#     odbcClose(conexion)
#   }
#   
#   datos.consulta 
# }


# Obtener datos por lista externa  --------------------------------------------------
# obtener.datos.porLista <- function(input, output, lista.nombres, str.http){
#   
#   config <- config::get(config=configuracion.conexion)
#   conexion <- odbcDriverConnect(config$conexion)
#   cad.sql<-paste ('[dbo].[Dataset_ConsumosPrediccionSeriesLista_shiny] '," @LISTACODIGOS = ? ")
#   parametros<- data.frame(unique(c(lista.nombres)))
#   datos.entrada<-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
#   odbcClose(conexion)
#   
#   return(datos.entrada)
# }


# Generar tabla de códigos a cargar -----------------------------------
salida.tabla <- function(input, ouput, lista.valida) {    
  
  if (!error.lectura) {
    # Verificar validez de códigos, y mostrar códigos válidos
    
    names(lista.valida) <- c('listacodigos','CodigoPuntoConsumo')
    
    conteo.invalidos <- nrow(filter(lista.valida,is.na(CodigoPuntoConsumo)))
    #conteo.nogeodata <- nrow(filter(lista.valida, is.na(LongitudPuntoConsumo) | is.na(LatitudPuntoConsumo))) - conteo.invalidos
    lista.valida <- lista.valida %>% filter(!(is.na(CodigoPuntoConsumo)))
    
    
    msg.num.entradas <- paste0("El archivo contiene ",nrow(lista.valida), " filas. Códigos inválidos: ",
                               conteo.invalidos)
    title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("Cargar clientes"),style="color: #00828F"),style="text-align: center;")
    
    return(
      fixedRow(column(width = 12,
                      
                      tags$h5(tags$img(src="cambio_ok.svg" ,alt="" ,width="16", height="16"),msg.num.entradas ,style="color: #00828F"),  # Título e ícono 
                      renderRHandsontable( {
                        rhandsontable(data.frame(lista.valida[[1]], stringsAsFactors = FALSE),
                                      colHeaders = c("Código"),
                                      search = FALSE,
                                      readOnly = TRUE,
                                      #selectCallback = TRUE,
                                      height =150
                        )
                      })
      )
      ))
  } else{
    return(
      fixedRow(column(width = 12,
                      renderText({ paste0("Error en la lectura del archivo") })
      )))
  }
  
}

# Preparar texto svg para gráfica de consumo 12 meses en popup  -----------------
# texto.popup <- function(l) {
#   l[is.na(l)] <- 0  # reemplazar NA por 0
#   x0 <- 2
#   espacio.vertical = 48
#   y0 <- ceiling(max(l))
#   escala.vertical = 48 / y0
#   colwidth <- 5
#   xwidth <- 8
#   texto.svg <- ""
#   for (i in 1:length(l)) 
#   {
#     colheight = ceiling(l[i]*escala.vertical)
#     texto.svg <- paste0(texto.svg,"<rect y='", espacio.vertical-colheight
#                         ,"' x='",x0 + xwidth*(i-1),"' height='",colheight ,"' width='5'"
#                         ," style='opacity:1;fill:#008b8a;stroke:#008b8a;' />")
#   }
#   texto.svg
# }




# Función para transformar vista de un objeto rhandsontable con primera columna de hipervínculo a
# un data frame

transf.rhand <- function(obj.hand.table){
  ordenes<-hot_to_r(obj.hand.table)                                 # Almacena información de la tabla en dataframe temporal
  ordenes$CodigoPuntoConsumo <- as.character(ordenes$CodigoPuntoConsumo)
  # quitar comentario cuando se reimplemente link para llamar hoja de vida
  # for(i in 1:nrow(ordenes)){                                      # Extrae el número de cliente del hipervínculo
  #   pos.cliente <- gregexpr(">",ordenes$CodigoPuntoConsumo[i])
  #   pos.cliente <- pos.cliente[[1]][1] + 1
  #   fin.cad <- nchar(ordenes$CodigoPuntoConsumo[i]) - 4
  #   ordenes$CodigoPuntoConsumo[i] <- substr(ordenes$CodigoPuntoConsumo[i],pos.cliente,fin.cad)
  # }
  ordenes
  
}


# Funciones para alternar entre 'true' y 'false' en un objeto rhandsontable

# cambia.true.false <-function(obj.rhandsont){
#   text.json <-obj.rhandsont$x$data      
#   text.json <-gsub( ":true",":false",text.json)  # Cambia 'true' por 'false'
#   obj.rhandsont$x$data <- text.json
#   return(obj.rhandsont)
# }

# cambia.false.true <-function(obj.rhandsont){
#   text.json <-obj.rhandsont$x$data 
#   text.json <-gsub( ":false",":true",text.json) # Cambia 'false' por 'true'
#   obj.rhandsont$x$data <- text.json
#   return(obj.rhandsont)
# }


# Validar códigos contra bd, y retornar tabla de códigos válidos -------------------------
validar.archivo <- function(input, ouput,lista.nombres) {
  
  error.lectura <<- FALSE
  
  tryCatch({
    cad.sql<- " [dbo].[Lista_Confirmacion_puntosSeries] @LISTACODIGOS = ? "
    config <- config::get(config=configuracion.conexion)
    conexion <- odbcDriverConnect(config$conexion)
    datos.entrada<-sqlExecute(channel = conexion, query = cad.sql, data = lista.nombres,fetch= T,as.is=T)
    odbcClose(conexion)
  }, error = function(e){
    error.lectura <<- TRUE
    
  }
  )
  
  if (!error.lectura) {
    lista.valida <<- datos.entrada
    return(lista.valida)
  } else
    return(NULL)
}
  
