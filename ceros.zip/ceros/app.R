# =============================================================================
#                             Ceros consecutivos
# =============================================================================
# 
# Autor:                Luis Fernando Rodríguez
# Fecha de creación:    14.08.2020
# Versión:              0
# Descripción:
# Reporte para encontrar usuarios con factura cero repetidas.
#
# Tablas de consulta directa: [Aux].[Parametros], [Dimension].[Campaña]
# Tablas en las que escribe: [Hecho].[ConsumoNormalizado]
# Procedimientos almacenados relacionados: [dbo].[Dataset_ConsumosCeroConsecutivos_shiny] 
# Pendientes:  Ajustar hipervínculos para conectar con hoja de vida
#
# =============================================================================

# Carga de librerías ------------------------------------------------------

library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
library(lubridate)
library(shinydashboard)
library(DT)
library(ggplot2)
library(plotly)         # Gráficas dinámicas plotly
library(rhandsontable)  # Visualización tablas
library(RCurl)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers

require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
library(rintrojs)       # Presentación de ayuda en pantalla

source("helpers.R")
#reactlog_enable()

# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}



# Retornar tabla para despliegue ---------------------------------------------
tabla.despliegue <- function(tabla.temp, obj) {
  if(nrow(obj)!=0 ) {
    b1 <- tabla.temp %>% filter(CodigoPuntoConsumo %in% obj$CodigoPuntoConsumo)
    if (nrow(obj)== nrow(b1)){
      obj[,1] <- b1[,1]}
    tabla.temp <- obj
  }
  
  
  rhandsontable(tabla.temp[,1:14],
                rowHeaders = TRUE,
                colHeaders = c(
                  '°',
                  'Código',
                  'Nombre',
                  'Dirección',
                  'Actividad',
                  'Ceros consecutivos',
                  'Prom. 6 mss ant. [kWh]',
                  'Zona',
                  'Región',
                  'Oficina',
                  'Departamento',
                  'Municipio',
                  'Localidad',
                  'Circuito'
                ),
                height =380,
                search = FALSE,
                readOnly = TRUE,
                selectCallback = TRUE)%>% 
    hot_col(1, halign = "htCenter", readOnly = FALSE) %>% 
    hot_col(2, renderer = "html",halign = "htRight") %>%                # Mostrar como hipervínculo
    hot_col(2, renderer = htmlwidgets::JS("safeHtmlRenderer")) %>%      # Mostrar como hipervínculo
    hot_cols(fixedColumnsLeft=3) %>%  
    hot_col(7,format="#.00", halign="htRight" ) %>% 
    hot_heatmap(7, color_scale =c("#17F556", "#ED6D47")) %>%  # Habilitar escala de color
    hot_cols(columnSorting = TRUE)  %>%   
    hot_context_menu(allowRowEdit = FALSE, allowColEdit = FALSE) %>%    # Bloquea opciones de menú contextual
    hot_table(highlightCol = TRUE, highlightRow = TRUE)                 # Resalta fila y columna seleccionada
  
}

# Retornar mapa para despliegue --------------------------------------------
mapa.despliegue<- function(tabla.temp, obj, datos.consulta, banderaRefresco,tabla.datos.valida, input) { #} datos.imagen, input) { 

  if (tabla.datos.valida) {
    tabla.temp <-  hot_to_r(input$datos)
    ordenes <- subset(tabla.temp, tabla.temp[,1] == TRUE)[,-1]
  } else if(nrow(obj)!=0) {
    ordenes <- obj
  } else {
    ordenes <- subset(tabla.temp, tabla.temp[,1] == TRUE)[,-1]
  }


  for(i in 1:nrow(ordenes)){                                      # Extrae el número de cliente del hipervínculo
    pos.cliente <- gregexpr(">",ordenes$CodigoPuntoConsumo[i])
    pos.cliente <- pos.cliente[[1]][1] + 1
    fin.cad <- nchar(ordenes$CodigoPuntoConsumo[i]) - 4
    ordenes$CodigoPuntoConsumo[i] <- substr(ordenes$CodigoPuntoConsumo[i],pos.cliente,fin.cad)
  }
  ordenes$CodigoPuntoConsumo <- unlist(ordenes$CodigoPuntoConsumo)
  
  datos<-left_join(ordenes,datos.consulta,by = "CodigoPuntoConsumo") # Efectua unión para traer coordenadas
  datos.consulta$PromedioActiva6CN<-as.numeric(as.character(datos.consulta$PromedioActiva6CN))  # Convierte a numérico
  datos.consulta$PromedioActiva6CN[is.na(datos.consulta$PromedioActiva6CN)]=0                  # Ajuste de valores nulos
  datos$LatitudPuntoConsumo <-as.numeric(as.character(datos$LatitudPuntoConsumo))
  datos$LongitudPuntoConsumo <-as.numeric(as.character(datos$LongitudPuntoConsumo))

  
  if (banderaRefresco) {
    google_map_update(map_id = "map") %>%
      clear_markers() %>%
      googleway::add_markers(data = datos,lat = "LatitudPuntoConsumo", lon = "LongitudPuntoConsumo", 
                             info_window = "Texto1",close_info_window = TRUE)
                             #info_window = "texto",close_info_window = TRUE)
  } else {
    google_map(key = api_key, data = datos, style=estilo.map01) %>%
      googleway::add_markers(lat = "LatitudPuntoConsumo", lon = "LongitudPuntoConsumo", 
                             info_window = "Texto1",close_info_window = TRUE)
  #  info_window = "texto",close_info_window = TRUE)
  }
  
  
}

# Configuración de bd y código para api google
configuracion.conexion <<- Sys.getenv("CONEXIONSHINY") #'windows'
#  'GoogleKey' CodigoParametro api google en [DWSRBI_ENERGUATE].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "SELECT TOP 1 ValorParametro FROM [DWSRBI_ENERGUATE].[Aux].[Parametros] where EstadoParametro = 1 AND   CodigoParametro = 'GoogleKey'"
api_key <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)
api_key <<- api_key[1,1]


# Contadores y llamadas--------------------------------------------------------------
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante
#api_key <- "AIzaSyAYoARt3zU_arrmeiZmMCjXhLEyRoE7Z2Q"  # Solicitar clave a WM y cambiar
Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')
locale <- Sys.getlocale(category="LC_COLLATE")
if (grepl("Spanish", locale, fixed=TRUE)) {
  separador.csv <<- ';'
} else {
  separador.csv <<- ','
}

# Captura de parámetro para URL servidor shiny -------------
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql<- "SELECT [ValorParametro]  FROM [DWSRBI_ENERGUATE].[Aux].[Parametros]  WHERE [CodigoParametro] = 'URLshiny'"
URL.servidor.shiny <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
URL.servidor.shiny <- URL.servidor.shiny [1,1]
str.http <<- paste(URL.servidor.shiny,"hvurl/?Codigo=",sep="") # Cadena de llamada para vínculo a hoja de vida




# Captura de campañas disponibles en BD -----------------------------------
cad.sql<- "[dbo].[Leer_Campanas]"
nom.camp <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom.camp)<-"Nombre"
nom.camp <- nom.camp  %>% filter(!is.na(Nombre))

cad.sql <- "[dbo].[Leer_Campanas]"
nom_servicios <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom_servicios) <- "Nombre"
nom_servicios <- nom_servicios   %>% filter(!is.na(Nombre))

cad.sql<-"EXEC [dbo].[Lista_FiltroZona]"
valores_ZonaOperativa <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

cad.sql <- "EXEC [dbo].[Lista_FiltroGeografia]"
valores_Geografia <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

odbcClose(conexion)

# Carga contenido filtros -----------------------------------

seleccion_operativa <<- 'no'
# Datos iniciales para  selectores de jerarquía
x <-  c(unique(valores_ZonaOperativa[c("NombreZona")]))
zonaCom <- x[order(x)]
x  <-  c(unique(valores_ZonaOperativa[c("NombreRegion")]))
regionCom <- x[order(x)]
x <- c(unique(valores_ZonaOperativa[c("NombreOficina")]))
centroCom <- x[order(x)]
x <- c(unique(valores_ZonaOperativa[c("Itinerario")]))
itinerarioCom <- x[order(x)]

seleccion_geografia <<- 'no'
x <-  c(unique(valores_Geografia[c("NombreDepartamentoGeografia")]))
departamentoGeo <- x
x <-  c(unique(valores_Geografia[c("NombreMunicipioGeografia")]))
municipioGeo <- x[order(x)]
x <-  c(unique(valores_Geografia[c("NombreLocalidadZonaGeografia")]))
localidadGeo <- x[order(x)]
#x <-  c(unique(valores_Geografia[c("NombreZona")]))
#zonaGeo <- x[order(x)]


# UI ----------------------------------------------------------------------

ui = dashboardPage(
 
  
  dashboardHeader(
     # title = div(tags$a(img(src="LogoEnerguate.svg", height=1000)),
     #             style = "position: relative; top: -5px;"), # Navigation bar
    title = "Ceros consecutivos",
    
    titleWidth = 300,
    
    tags$li(class = "dropdown",            # Presenta vínculo para 'Tour'
            tags$li(class = "dropdown", actionLink("ayuda", textOutput("Tour")))),
    
    dropdownMenuOutput("MensajeOrdenes"),  # Presenta mensajes en barra de encabezado
    dropdownMenuOutput("MensajeMapa")      # Presenta mensajes en barra de encabezado    
  ),
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 300,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   introjsUI(),   # Se habilita presentación de ayuda
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   box(id = "Comandos", width = 12, 
                        status = NULL,  
                        background = "black",
                        fluidRow( column(width = 1,
                                         actionButton("ReiniciarControles", label = icon("fas fa-sync")),
                                        bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                        ),
                        column(width = 1,
                               offset = 1,
                               actionButton("TraerDatos", label = icon("fas fa-play")), 
                               bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                        )
                        )
                        
                   ),

                   box(id = "Contadores", width = 12, status = NULL,  background = "black",

                        sliderInput(inputId="mesesRevisar",
                                    label="Meses de historia a revisar",
                                    min=1,max=12 ,
                                    value=6,
                                    step=1,round=TRUE),
                       bsTooltip("mesesRevisar", "Meses de historia a revisar por consumos cero",
                                 placement = "bottom", trigger = "hover", options = NULL)
                   ),
                   box(id = "Empresas", width = 12, 
                       status = NULL,  
                       background = "black",
                       fluidRow( column(width = 2,
                                        actionButton("empresaOccidente", label = "Occidente"),
                                        bsTooltip("empresaOccidente"
                                                  , "Datos de Distribuidora de Electricidad de Occidente, S.A.", placement = "bottom", trigger = "hover", options = NULL)
                       ),
                       column(width = 2,
                              offset = 4,
                              actionButton("empresaOriente", label = "Oriente"), 
                              bsTooltip("empresaOriente"
                                        , "Datos de Distribuidora de Electricidad de Oriente, S.A.", placement = "bottom", trigger = "hover", options = NULL)
                       ),
                       pickerInput("Servicio","servicio:",
                                   choices = nom_servicios,
                                   #selected = '-TODOS-',
                                   multiple=T,
                                   options = list(
                                     `actions-box` = TRUE,
                                     `deselect-all-text` = "Ninguno",
                                     `select-all-text` = "Todos",
                                     `none-selected-text` = "Servicios"
                                   ))
                       )
                       
                   ),
                   box( id = "filtros1", width = 12, status = NULL,  background = "black",
                        
                        pickerInput("zona_comercial","Zona:",
                                    choices = zonaCom,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Zona comercial"
                                    )),
                        
                        
                        pickerInput("region","Región:",
                                    choices = c(''), #regionCom,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      #   `live-search`=TRUE,
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Región"
                                    )),
                        
                        pickerInput("centro","Centro:",
                                    choices = c(''),
                                    # selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Centro"
                                    )),
                        
                        pickerInput("itinerario","Itinerario:",
                                    choices = c(''),
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Itinerario"
                                    ))  #,
                   ),
                   
                   box( id = "filtros2", width = 12, status = NULL,  background = "black",
                        pickerInput("departamento","Departamento:",
                                    choices = departamentoGeo,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Seleccionar Circuito"
                                    )),
                        
                        pickerInput("municipio","Municipio:",
                                    choices = c(''), #municipioGeo,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Seleccionar Municipio"
                                    )),
                        
                        pickerInput("localidad","Localidad:",
                                    choices = c(''), #localidadGeo,
                                    multiple=T,
                                    options = list(
                                      #`live-search`=TRUE,
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Seleccionar localidad"
                                    )) #,
                        #      pickerInput("zona_geo","Zona:",
                        #                  choices = zonaGeo,
                        #                  multiple=T,
                        #                  options = list(
                        #                    `live-search`=TRUE,
                        #                    `actions-box` = TRUE,
                        #                    `deselect-all-text` = "Ninguno",
                        #                    `select-all-text` = "Todos",
                        #                    `none-selected-text` = "Seleccionar zona"
                        #                  )),
                        #      
                   )
                   
 
                   
  ),
  
  # Body --------------------------------------------------------------------
  ##00828F;
  dashboardBody(    
    tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }'
    )
    )
    ), # Fin estilo
    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel( type = "tabs", 

                tabPanel("Gráfica", icon = icon("fas fa-table"),
                         hr(),
                         box(
                           width = 12,
                           status = "warning",
                           solidHeader = FALSE,
                           title = "Cuentas con ceros consecutivos",
                         fluidRow(column(width = 2,
                                         offset = 10,
                                         materialSwitch('selec.graf', 
                                                        label = "Puntos / Barras", 
                                                        value = FALSE, 
                                                        inline =  FALSE),
                                         bsTooltip("selec.graf", "Presentar en gráfica de puntos / barras", 
                                                   placement = "bottom", trigger = "hover", options = NULL)
                         )),
                         hr(),
                         
                         withSpinner(                                                        # Incluir spinner de espera
                           plotlyOutput("plot",height = "600px"), # height = "500px"), #,brush = brushOpts("b1")),                 
                           color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                         ),
                         
                         useShinyjs(),
                         # code to reset plotlys event_data("plotly_click", source="A") to NULL -> executed upon action button click
                         # note that "A" needs to be replaced with plotly source string if used
                         extendShinyjs(text = "shinyjs.resetGraph = function() { Shiny.onInputChange('.clientValue-plotly_selected-master', 'null'); }",
                                       functions=c("resetGraph"))   
                )),              
                tabPanel("Datos",
                         icon = icon("fas fa-table"),
                         hr(),
                         
                         fluidRow( 
                           box(#height = 420,
                               width = 12,
                               status = "warning",
                               solidHeader = FALSE,
                               title = "Períodos consecutivos en cero",
                               radioButtons(inputId = "selec.tod", 
                                            label = "Seleccionar datos:", 
                                            choices = c("Todos", "Ninguno"),                                  
                                            inline = TRUE
                               ),
                               bsTooltip("selec.tod", "Seleccionar todos / ninguno", 
                                           placement = "bottom", trigger = "hover", options = NULL),
                               
                               
                               br(),
                               withSpinner(rHandsontableOutput("datos", height = "600px"),         # Incluir spinner de espera
                                           color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                               )
                               
                           )),
                         hr(),
                         fluidRow(hr() ,      
                                  column(width = 2,
                                  actionButton("MostrarTabla",   # Se crea el botón deshabilitado para que
                                               "Actualizar tabla"    # sea habilitado posteriormente por código
                                  )),
                                  column(width = 2,
                                         offset = 6,
                                         shinyjs::disabled(downloadButton('Descargar', 'Descargar csv'),  # Se crea el botón deshabilitado para que
                                                           bsTooltip("Descargar", "Descargar usuarios seleccionados a archivo csv", 
                                                                     placement = "bottom", trigger = "hover", options = NULL)
                                         )                                           # sea habilitado posteriormente por código
                                         
                                  ),
                                  column(width = 2,
                                         shinyjs::disabled(  # Se crea el botón deshabilitado para que
                                           actionButton("Guardar",   
                                                        "Generar órdenes",   
                                                        icon = icon("fas fa-save")
                                         ),
                                         bsTooltip("Guardar", "Crear órdenes de inspección para usuarios seleccionados", 
                                                   placement = "bottom", trigger = "hover", options = NULL)
                                         )
                                  )
                         )                         
                ),


                # tabPanel("Mapa",icon = icon("fas fa-map-marker-alt"),
                #          hr(),
                #          box(#height = 420,
                #              width = 12,
                #                status = "warning",
                #              solidHeader = FALSE,
                #              title = "Localización de cuentas seleccionadas",
                # 
                #          withSpinner(google_mapOutput("map", width='auto',height="770px"),
                #                      color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                #          ),
                #          hr(),
                #          fluidRow(
                #                   column(width = 2,
                #                          offset = 8,
                #                          actionButton("MostrarMapa",   # Se crea el botón deshabilitado para que
                #                                       "Actualizar mapa"    # sea habilitado posteriormente por código
                #                          )
                #                   )
                #          ) )),  
                
      id="TabsApp"
    )
  )
)

# Server ------------------------------------------------------------------

server <- shinyServer(function(input, output, session) { # Importante iniciar con shinyServer para que funcione la ayuda
  
  consulta.activa <<- FALSE
  datos.consulta <- NA
  tipo.grafica <- 'P'
  tabla.datos.valida <- FALSE
  # tabla.datos <- data.frame( '°'= logical(),
  #                            CodigoPuntoConsumo=character(),
  #                            NombreCliente=character(),
  #                            DireccionPuntoConsumo=character(),
  #                            Zona=character(),
  #                            Municipio=character(),
  #                            Circuito=character(),
  #                            AcumuladoConsumoCeroCN=double(),
  #                            PromedioActiva6CN=double(),
  #                            Ciclo=character(),
  #                            Estrato=character(),
  #                            Actividad=character(),
  #                            Transformador=character(),
  #                            LlaveFechaEjecucion=character(),
  #                            texto=character(),
  #                            stringsAsFactors = FALSE)

  
  # Ocultar Botones auxiliares para sincronizar paneles, paneles
  shinyjs::hide("MostrarTabla")
  shinyjs::hide("MostrarMapa")



  
  # Ayuda -------------------------------------------------------------------
  
  output$Tour <- renderText({"Tour" })  # Presenta acceso de ayuda en la cabecera
  
  steps <- reactive(  # Crea data frame para incluir los temas de ayuda
    data.frame(
      element = c(NA, "#Comandos", "#Contadores", "#filtros", "#Gráfica",
                  "#selec.graf", "#Datos", "#selec.tod", "#Descargar", "#Guardar", "#Mapa"),  # Se incluyen nombres de los objetos
      intro = c(
        "Este reporte muestra las cuentas con consumos cero repetidos. Las cuentas se seleccionan por fecha, número de consumos cero seguidos, y pueden filtrarse por varios atributos de cada cuenta. La información se muestra de forma gráfica, tabular, y por información geográfica asociada, si está disponible.",
        "El botón izquierdo Reinicializa las listas de valores en los botones de filtro. El botón derecho hace la consulta para traer los datos que corresponden a los filtros seleccionados.",
        "Escoger fecha de último mes con consumos cero que se tiene en cuenta para la selección, y número mínimo de consumos cero consecutivos para las cuentas seleccionadas.",
        "Utilice las listas desplegables para efectuar fitros por categorías.",
        "La gráfica muestra las cuentas seleccionadas. La gráfica de puntos muestra cada usuario como un punto, situado de acuerdo al número de ceros consecutivos (eje horizontal), y el promedio de consumo en los últimos seis meses (eje vertical). La gráfica de barras muestra el número de usuarios para cada valor de consumos cero consecutivos en la muestra. En la parte superior de las gráficas hay  herramientas que le facilitarán la visualización, la navegación y exportación de imágenes.",
        "El selector de tipo de gráfica permite alternar en la presentación de los datos por gráfica de puntos o diagrama de barras",
        "El panel de datos muestra en forma tabular las cuentas seleccionadas y los valores de atributos asociados. La columna de selección indica los datos para descarga a archivo o generación de órdenes de consumo.",
        "El botón de selección en el panel de datos permite marcar todos los datos en la tabla, o desmarcarlos.",
        "El botón de guardar en el panel de datos crea un archivo csv con los datos de las cuentas seleccionadas en la tabla.",
        "El botón de generar órdenes en el panel de datos crea órdenes de consumo para las cuentas seleccionadas en la tabla.",
        "El panel de mapas muestra la ubicación geográfica de las cuentas de interés."
      )
    )
  )
  
  observeEvent(input$ayuda, {
    # alert("Presionó ayuda")
    introjs(session, options = list("nextLabel"="Siguiente",
                                    "prevLabel"="Anterior",
                                    "skipLabel"="Salir",
                                    "doneLabel"="Terminado",
                                    steps=steps())
    )
    
  })
  
  # Cambio de tab ----------------------------------------------------------------------
  observeEvent(input$TabsApp, {

    if (input$TabsApp == "Datos") {
      tabla.datos.valida <<- TRUE
    } else if (input$TabsApp == "Mapa") {
      click("MostrarMapa")
    }
  }, ignoreInit = TRUE)
  
  # Carga de datos a listas desplegables  ---------------------------------------------------
  #
  
  observeEvent(input$zona_comercial, {
    seleccion_operativa <<- "zona_comercial"
    lista_seleccion <- input$zona_comercial
    valores_validos <<- valores_ZonaOperativa %>% 
      filter(valores_ZonaOperativa$NombreZona %in% lista_seleccion)
    
    x <-  c(unique(valores_validos[c("NombreRegion")]))
    updatePickerInput(session,
                      "region",
                      choices = x[order(x)]) #, #c( atr$Nombre)))  ,
    #    selected = valor.seleccionado)
  }, ignoreInit = TRUE)
  
  
  observeEvent(input$region, {
    seleccion_operativa <<- "region"
    lista_seleccion <- input$region
    valores_validos <<- valores_validos %>% 
      filter(valores_validos$NombreRegion %in% lista_seleccion)
    x <-  c(unique(valores_validos[c("NombreOficina")]))
    
    updatePickerInput(session,
                      "centro",
                      choices = x[order(x)]) #, #c( atr$Nombre)))  ,
    #    selected = valor.seleccionado)
  }, ignoreInit = TRUE)
  
  
  # "centro"
  observeEvent(input$centro, {
    seleccion_operativa <<- "centro"
    lista_seleccion <- input$centro
    valores_validos <<- valores_validos %>% 
      filter(valores_validos$NombreOficina %in% lista_seleccion)
    x <-  c(unique(valores_validos[c("Itinerario")]))
    
    updatePickerInput(session,
                      "itinerario",
                      choices = x[order(x)]) #, #c( atr$Nombre)))  ,
    #    selected = valor.seleccionado)
  }, ignoreInit = TRUE)
  
  # Itinerario
  observeEvent(input$itinerario, {
    seleccion_operativa <<- "itinerario"
    lista_seleccion <- input$itinerario
    valores_validos <<- valores_validos %>% 
      filter(valores_validos$Itinerario %in% lista_seleccion)
    
    #    selected = valor.seleccionado)
  }, ignoreInit = TRUE)
  
  # departamento
  observeEvent(input$departamento, {
    seleccion_geografia <<- "departamento"
    lista_seleccion <- input$departamento
    valores_validos_Geografia <<- valores_Geografia %>% 
      filter(valores_Geografia$NombreDepartamentoGeografia %in% lista_seleccion)
    
    x <-  c(unique(valores_validos_Geografia[c("NombreMunicipioGeografia")]))
    updatePickerInput(session,
                      "municipio",
                      choices = x[order(x)])
  }, ignoreInit = TRUE)
  
  # municipio
  observeEvent(input$municipio, {
    seleccion_geografia <<- "municipio"
    lista_seleccion <- input$municipio
    valores_validos_Geografia <<- valores_validos_Geografia %>% 
      filter(valores_validos_Geografia$NombreDepartamentoGeografia %in% lista_seleccion)
    
    x <-  c(unique(valores_validos_Geografia[c("NombreLocalidadZonaGeografia")]))
    updatePickerInput(session,
                      "localidad",
                      choices = x[order(x)])
  }, ignoreInit = TRUE)
  
  # localidad
  observeEvent(input$localidad, {
    seleccion_geografia <<- "localidad"
    lista_seleccion <- input$localidad
    valores_validos_Geografia <<- valores_validos_Geografia %>% 
      filter(valores_validos_Geografia$NombreLocalidadZonaGeografia %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  
# Hacer consulta basada en valores de filtros  ---------------------------
  observeEvent(input$TraerDatos, {
    noHayValores <- FALSE
    meses_busqueda <- input$mesesRevisar
    fecha_minimo <- today() %m-% months(meses_busqueda)
    fecha_minimo <- paste0(substring(fecha_minimo,1,4),substring(fecha_minimo,6,7),"01")
    condiciones_consulta = paste0(" AND  LlaveFecha > ", fecha_minimo, " ")
    # Construir condiciones de consulta:
    if (seleccion_operativa != "no") {
      if (nrow(valores_validos) == 0) {
        noHayValores <- TRUE
      } else {
        f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos[c("LlaveZona")]), collapse=',')),2,stop =1000000L)
        
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND Llavezona IN ( ",substr(f1,2,stop =1000000L),"  ") )
      }
    }
    
    if (seleccion_geografia != "no") {
      if (nrow(valores_validos_Geografia) == 0) {
        noHayValores <- TRUE
      } else {
        f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos_Geografia[c("LlaveGeografia")]), collapse=',')),2,stop =1000000L)
        
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND LlaveGeografia IN ( ",substr(f1,2,stop =1000000L),"  ") )
      }
    }
    
    
    # traer valores de ceros
    if (noHayValores) {
      showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        
        "La consulta no genera resultados",
        footer = list(modalButton("Cancelar", icon = icon("far fa-window-close"))
        ),
        easyClose =TRUE
      )
      )
    }  else {
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      cad.sql<-"EXEC [dbo].[Dataset_ConsumosCeroConsecutivos_shiny]"
      cad.sql<-paste (cad.sql,"  @CONDICION = ? ")
      parametros<- data.frame( condiciones_consulta)
      datos.consulta <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
      
      odbcClose(conexion)
      
      if (nrow(datos.consulta ) > 0) {
        tabla.datos.valida <<- FALSE
        datos.consulta <- as.data.frame(datos.consulta,stringsAsFactors=FALSE)
        datos.consulta$PromedioActiva6CN<-as.numeric(as.character(datos.consulta$PromedioActiva6CN))  # Convierte a numérico
        datos.consulta$PromedioActiva6CN[is.na(datos.consulta$PromedioActiva6CN)]=0                  # Ajuste de valores nulos
        
        
        shinyjs::enable("Guardar")                                   # Habilita el botón para guardar
        shinyjs::enable("Descargar")
        # Armar tabla de datos para despliegue
        datos.consulta$texto <- paste0(" Código : ",                                           # Campo de texto a presentar en tooltip de los puntos
                                       datos.consulta$CodigoPuntoConsumo,
                                       " \n ",                                                 # Se incluye salto de línea
                                       "Cliente: ",
                                       datos.consulta$NombreCliente,
                                       " \n ",
                                       "Dirección: ",
                                       datos.consulta$DireccionPuntoConsumo #,
                                       # " \n " ,
                                       # "Ultima inspeccion: ",
                                       # datos.consulta$LlaveFechaEjecucion
        )
        
        #datos.imagen$image <- lapply(datos.imagen$image, aCode64)
        
        consumos.numericos <-sapply(datos.consulta$Consumo12,function(x) sapply(strsplit(x,','), as.numeric))
        for (i in 1:nrow(datos.consulta)) {
          datos.consulta$Consumo12[i] <- texto.popup(unlist(consumos.numericos[i]))
        }
        
        datos.consulta$Texto1 <- paste0(
          "<p></p>",
          "<table border= '0' style= 'height: 120px; width: 100%; border-collapse: collapse;'>",
          "<tbody>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px; background-color: #f0f2f2;'><strong><span style='color: #0070ba;'>Cliente:&nbsp;</span></strong></td>",
          
          "<td style='width: 65%; height: 20px; background-color: #f0f2f2; text-align: right;'><strong><span style='color: #0070ba;'>",
          "<a href='",paste(str.http,datos.consulta$CodigoPuntoConsumo, sep=""),
          "' target='_blank' rel='noopener'>",datos.consulta$CodigoPuntoConsumo,"</a>",
          "</span></strong></td>",
          "</tr>",
          
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px; vertical-align: top;'>Nombre:</td>",
          "<td style='width: 65%; height: 20px;'>",datos.consulta$NombreCliente,"</td>",
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px; vertical-align: top;'>Actividad:</td>",
          "<td style='width: 65%; height: 20px;'>",datos.consulta$Actividad,"</td>",
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px;'>Cons. Prom.:</td>",
          "<td style='width: 65%; height: 20px; text-align: right;'>",datos.consulta$PromedioActiva6CN," [kWh]</td>",
          "</tr>",
          # "<tr style='height: 20px;'>",
          # "<td style='width: 35%; height: 20px;'>Transformador:</td>",
          # "<td style='width: 65%; height: 20px; text-align: right;'>",datos.consulta$Transformador,"</td>",
          # "</tr>",
          # "<tr style='height: 20px;'>",
          # "<td style='width: 35%; height: 20px;'>Ultima inspección:</td>",
          # "<td style='width: 65%; height: 20px; text-align: right;'>",datos.consulta$LlaveFechaEjecucion,"</td>",
          # "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px;'>Perfil de consumo:</td>",
          "<td style='width: 65%; text-align: right; height: 20px;'>",
          "<svg xmlns='http://www.w3.org/2000/svg'",
          "xmlns:xlink='http://www.w3.org/1999/xlink' width='100' height='50' viewBox='0 0 100 50'>",
          datos.consulta$Consumo12,
          "</svg>",
          "</td>",
          "</tr>",
          "</tbody>",
          "</table>"             
        )
        
        
        
        tabla.datos<- datos.consulta  %>% select(CodigoPuntoConsumo, NombreCliente
                                                 ,DireccionPuntoConsumo, Seccion
                                                 , AcumuladoConsumoCero   ,PromedioActiva6CN
                                                 , NombreZona, NombreRegion, NombreOficina
                                                 ,NombreDepartamentoGeografia, NombreMunicipioGeografia, NombreLocalidadZonaGeografia
                                                 ,Nombre_corto_SMT 
                                                 ,  texto)
        
        datos.consulta <<- datos.consulta
        #datos.imagen <<- datos.imagen
        
        for (i in 1:nrow(tabla.datos)){      # Crea los tags para el hipervínculo de num. de cliente
          tabla.datos$CodigoPuntoConsumo[i] <- tagList(as.character(a(as.character(tabla.datos$CodigoPuntoConsumo[i]), 
                                                                      href = paste(str.http,tabla.datos$CodigoPuntoConsumo[i], sep=""))))
        }
        
        tabla.datos <- cbind("°" = TRUE, tabla.datos)
        tabla.datos <<- tabla.datos
        
        
        # Cargar datos gráfico de puntos
        updateMaterialSwitch(session, 'selec.graf', value = FALSE)
        output$plot <- renderPlotly({
          p <-
            ggplot(tabla.datos,
                   mapping = aes(x = AcumuladoConsumoCero, y = PromedioActiva6CN, text = texto)) +
            geom_point(color = "#0070ba", size = 1) + theme_bw() +
            ylab("Consumo promedio 6 meses anteriores [kWh]") +
            xlab("Períodos consecutivos en cero")
          
          # Manejo de selección en gráfica
          obj <- data.grafica()$sel
          #      if (exists("obj")) {
          if(nrow(obj)!=0 ) {
            p <- p + geom_point(data=obj,color="orange")
          }
          #      }
          ggplotly(p, source = "master")
        })
        
        showTab("Gráfica", "Datos", select = FALSE,  session = getDefaultReactiveDomain())
        showTab("Gráfica", "Mapa", select = FALSE,  session = getDefaultReactiveDomain())
        output$datos <- renderRHandsontable({
          tabla.despliegue(tabla.datos, data.grafica()$sel)
        })
        # output$map <- renderGoogle_map({
        #   mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta, FALSE, tabla.datos.valida, input) #, datos.imagen, input)
        # })
        
      } else{
        disable("Guardar")                                  # Deshabilita el botón para guardar
        disable("Descargar")
        showModal(modalDialog(
          title = "La consulta no encuentra datos que cumplan.",
          footer = modalButton("Cerrar"),
          easyClose = TRUE
        ))
      }
    }

  }, ignoreInit = TRUE)
  
  # Cargar datos a tabla
  output$datos <-
    renderRHandsontable({
      if (exists("tabla.datos")){
      obj <- data.grafica()$sel
      if(nrow(obj) >0) {
        p <- p <- tryCatch(tabla.datos[(selected()$pointNumber+1),,drop=FALSE] , error=function(e){NULL})
      } else if (exists("tabla.datos")) {
        p <- tabla.datos
      }
        if (nrow(p ) > 0) {
      # Actualiza rhandsontable
          tabla.despliegue(p, data.grafica()$sel)

        }
      }
    })
  
  # Puntos seleccionados
  selected<-reactive({

    event_data("plotly_selected", source = "master")
  })
  
  data.grafica<-reactive({
    if (exists("tabla.datos")){
      tabla.datos.valida <<- FALSE
      tmp<-tabla.datos
      sel<-tryCatch(tabla.datos[(selected()$pointNumber+1),,drop=FALSE] , error=function(e){NULL})
      if (nrow(sel) > 0 & tipo.grafica == 'B') {
        secuencia.sel <- selected()$pointNumber + 1
        valores.ceros <- sort(unique(tabla.datos$AcumuladoConsumoCero))[secuencia.sel]
        sel <-  tabla.datos %>% filter(AcumuladoConsumoCero %in% valores.ceros)
        list(data=tmp,sel=sel)
      } else {
        click('MostrarTabla')
        list(data=tmp,sel=sel)
      }
      
    }
    
   # list(data=tmp,sel=sel)
    
  })
 
  # Presentación del mapa --------------------------------------------------- 
  output$map <- renderGoogle_map({
    if (exists("tabla.datos")) {
      mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta, FALSE, tabla.datos.valida, input) #, datos.imagen, input)
    }
  })
  
 
  
  # Reinicial controles ----------------------------------------------
  observeEvent(input$ReiniciarControles, {
    
   seleccion_operativa <<- 'no'
   
    # Datos iniciales para  selectores de jerarquía
    x <-  c(unique(valores_ZonaOperativa[c("NombreZona")]))
    zonaCom <- x[order(x)]
    isolate(
      updatePickerInput(session,
                      "zona_comercial", choices = zonaCom))
    isolate(
      updatePickerInput(session,
                        "region", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "centro", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "itinerario", choices = c('')))


    
    seleccion_geografia <<- 'no'
    x <-  c(unique(valores_Geografia[c("NombreDepartamentoGeografia")]))
    departamentoGeo <- x
    isolate(
      updatePickerInput(session,
                        "departamento", choices = departamentoGeo))
    isolate(
      updatePickerInput(session,
                        "municipio", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "localidad", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "zona_geo", choices = c('')))
    
  }, ignoreInit = TRUE)
  
  # Cambiar tipo de gráfica  ----------------------------------------
  observeEvent(input$selec.graf,{

    valorSwitch <- input$selec.graf
    if (valorSwitch == TRUE) {
      tipo.grafica <<- 'B'
      output$plot <- renderPlotly({
        p <- ggplot(tabla.datos, mapping = aes(x = AcumuladoConsumoCero)) +
          geom_bar(color ="#0070ba",fill= "#0070ba",size =1) + theme_bw()+
          ylab("Conteo") +
          xlab("Períodos consecutivos en cero")
        # Manejo de selección en gráfica
        obj <- data.grafica()$sel
        if(nrow(obj)!=0) {
          p <- p + geom_bar(data=obj,color="orange",fill="orange")
        }
        ggplotly(p,source="master")
      })
    } else {
      tipo.grafica <<- 'P'
      output$plot <- renderPlotly({
        p <-
          ggplot(tabla.datos,
                 mapping = aes(x = AcumuladoConsumoCero, y = PromedioActiva6CN, text = texto)) +
          geom_point(color = "#0070ba", size = 1) + theme_bw() +
          ylab("Consumo promedio 6 meses anteriores [kWh]") +
          xlab("Períodos consecutivos en cero")
        
        # Manejo de selección en gráfica
        obj <- data.grafica()$sel
        if(nrow(obj)!=0) {
          p <- p + geom_point(data=obj,color="orange")
        }
        ggplotly(p, source = "master")
      })
    }
    }, ignoreInit = TRUE)
  
  # Seleccionar o deselecionar todos ----------------------------------------
  
  observeEvent(input$selec.tod,{
    tabla.temp <<- hot_to_r(input$datos)    # Tabla temporal para alimentar rhandsontable
    
    if(input$selec.tod == "Todos"){
      tabla.temp[,1] <- TRUE             # Cambia primera columna a seleccionado
    }
    
    if(input$selec.tod == "Ninguno"){
      tabla.temp[,1] <- FALSE               # Cambia primera columna a deseleccionado
    }
    output$datos <- renderRHandsontable({   # Actualiza rhandsontable
    tabla.despliegue(tabla.temp, data.grafica()$sel)
    })
    output$map <- renderGoogle_map({
      mapa.despliegue(tabla.temp, data.grafica()$sel, datos.consulta, TRUE,tabla.datos.valida, input) #, datos.imagen, input)
    })
    
  }, ignoreInit = TRUE)
  
  # Descargar CSV -----------------------------------------------------------
  
  output$Descargar <- downloadHandler(
    
    filename = function() { 
      paste0("Ceros", Sys.Date(), ".csv")
    },
    content = function(file) {

      ordenes <- transf.rhand(input$datos)                      # Transforma los datos tomados del objeto rhandsontable.
      ordenes <- subset(ordenes, ordenes[,1] == TRUE)[,-1]      # Filtra aquellos con checkbox activo y omite primera columna
      write.table(ordenes,file,sep=separador.csv, fileEncoding = "latin1")
    },
    contentType = "csv"
  )
  
  observeEvent(input$MostrarTabla, {
    if (exists("tabla.datos")) {
      if (nrow(data.grafica()$sel) == 0) {
        tabla.temp <- tabla.datos
      }
      if (exists("tabla.temp")){
        tabla.temp[,1] <- TRUE
        output$datos <- renderRHandsontable({   # Actualiza rhandsontable
          tabla.despliegue(tabla.temp, data.grafica()$sel)
        })
      } 
    }
  }, ignoreInit = TRUE)
  
  
  observeEvent(input$MostrarMapa, {
    if ( exists("tabla.datos")) {
      mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta,TRUE,tabla.datos.valida, input) #, datos.imagen, input)
    }
    #  mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta,TRUE,tabla.datos.valida, input)
    # output$map <- renderGoogle_map({
    #   mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta)
    # })
  }, ignoreInit = TRUE)
  
  # Generar órdenes de inspección en BD ---------------------------------------------------
  observeEvent(input$Guardar,{
    
    showModal(modalDialog(
      
      title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("Generar órdenes"),style="color: #0070ba"),style="text-align: center;"),
      
      "Se guardarán los clientes seleccionados para ser incluidos \n en la lista de órdenes de inspección",
      hr(),
      
      selectInput("variable", 
                  "Seleccione campaña:",
                  nom.camp),
      textAreaInput("observ.orden", label = "Observaciones:",
                    height = "100px", rows = 4, 
                    placeholder = "Comentarios para acompañar la órden", 
                    resize = "vertical"),
      footer = list(modalButton("Cancelar", icon = icon("far fa-window-close")),
                    actionButton("Guardar2", "Guardar",icon = icon("fas fa-save"))
      ),
      easyClose =TRUE
    )
    )
  }, ignoreInit = TRUE)
  
  
  observeEvent(input$Guardar2, {                                          # Código para botón diálogo modal
    
    #  Grabar órdenes en BD
    
    ordenes <- transf.rhand(input$datos)                      # Transforma los datos tomados del objeto rhandsontable.
    ordenes <- subset(ordenes, ordenes[,1] == TRUE)[,-1]      # Filtra aquellos con checkbox activo y omite primera columna
    
    ordenes<-cbind(ordenes[,1],                                         # Punto de consumo: 'CodigoPuntoConsumo'
                   rep(as.character(input$variable), nrow(ordenes)),    # Línea para tipo de campaña seleccionada: 'NombreCampana'
                   rep("Sequimiento cortados", nrow(ordenes)),          # Reporte origen de las órdenes: 'ReporteOrigen'
                   rep(as.character(Sys.time()), nrow(ordenes)),        # Fecha y hora de generación de las órdenes: 'FechaGeneracion'
                   rep(analista, nrow(ordenes)),                        # Usuario que genera las órdenes: 'AnalistaSolicitante'
                   rep(0.5, nrow(ordenes)),                             # 'Probabilidad' de detección. ** Se debe incluir probabilidad de la campaña, por ahora es 0.5
                   ordenes[,9],                                         # 'RecuperacionMedia': Se asume promedio anterior
                   rep(as.character(input$observ.orden), nrow(ordenes)) #  Observación que acompaña la orden 'ObservacionOrden'
    )
    
    ordenes<-data.frame(ordenes)
    ordenes[,7]<-as.numeric(as.character(ordenes[,7]))                  # Se convierte a texto el dato tomado de la tabla
    
    #conexion2 <- odbcDriverConnect ("driver={SQL Server};server=WMENERTOLIMA\\SQL2017;database=DWSRBI_ENERGUATE;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" )
    config <- config::get(config=configuracion.conexion)
    config.conexion <- config$conexion
    conexion <- odbcDriverConnect (config.conexion)
    cad.sql<-" INSERT INTO [DWSRBI_ENERGUATE].[Hecho].[OrdenInspeccion]([CodigoPuntoConsumo],[NombreCampana],[ReporteOrigen],[FechaGeneracion],[AnalistaSolicitante],[Probabilidad],[RecuperacionMedia],[ObservacionOrden])"
    cad.sql<-paste (cad.sql,"VALUES (?,?,?,?,?,?,?,?)")
    
    sqlExecute(channel = conexion,
               cad.sql,
               data = ordenes)              # En 'ordenes' se incluyen las órdenes a ser incluidas en la tabla 'OrdenInspeccion'
    odbcClose(conexion)
    
    ord.gen <<- ord.gen + nrow(ordenes)     # Se actualiza el contador de órdenes generadas en la sesión. Variable global
    
    output$MensajeOrdenes <- renderMenu({   # Actualiza mensaje en la barra de menú para órdenes generadas
      
      dropdownMenu(type = "notifications",  # Mensaje en barra de encabezado para indicar generación de órdenes
                   headerText = "Tiene una notificación",
                   icon =icon("fas fa-comments"),
                   notificationItem(
                     text = paste(ord.gen, "órdenes generadas en esta sesión"),
                     icon("fas fa-gavel")
                   )
      )
    })
    
    removeModal()
  })
  

})



# Ejecutar aplicación -----------------------------------------------------


shinyApp(ui = ui, server = server)