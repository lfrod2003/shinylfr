library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
#library(reactlog)
library(shinydashboard)
library(DT)
library(ggplot2)
library(plotly)         # Gráficas dinámicas plotly
library(rhandsontable)  # Visualización tablas
library(RCurl)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers

library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
library(rintrojs)       # Presentación de ayuda en pantalla

# Configuración de bd y código para api google
print("Empezando")
configuracion.conexion <<- Sys.getenv("CONEXIONSHINY") #'windows'
#  'GoogleKey' CodigoParametro api google en [DWSRBI_2].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion

conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "SELECT TOP 1 ValorParametro FROM [DWSRBI_ENERGUATE].[Aux].[Parametros] where EstadoParametro = 1 AND   CodigoParametro = 'GoogleKey'"
api_key <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

api_key <<- api_key[1,1]

# Cargar valores para filtros e índice de llaves válidas
cad.sql<-"EXEC [dbo].[Lista_FiltroZona]"

valores_ZonaOperativa <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

cad.sql <- "EXEC [dbo].[Lista_FiltroGeografia]"
valores_Geografia <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)


# Carga contenido filtros -----------------------------------
seleccion_operativa <<- 'no'
# Datos iniciales para el selector de estrato
x <-  c(unique(valores_ZonaOperativa[c("NombreZona")]))
zonaCom <- x[order(x)]
x  <-  c(unique(valores_ZonaOperativa[c("NombreRegion")]))
regionCom <- x[order(x)]
x <- c(unique(valores_ZonaOperativa[c("NombreOficina")]))
centroCom <- x[order(x)]
x <- c(unique(valores_ZonaOperativa[c("Itinerario")]))
itinerarioCom <- x[order(x)]

seleccion_geografia <<- 'no'
x <-  c(unique(valores_Geografia[c("NombreDepartamentoGeografia")]))
departamentoGeo <- x
x <-  c(unique(valores_Geografia[c("NombreMunicipioGeografia")]))
municipioGeo <- x[order(x)]
x <-  c(unique(valores_Geografia[c("NombreLocalidadZonaGeografia")]))
localidadGeo <- x[order(x)]
#x <-  c(unique(valores_Geografia[c("NombreZona")]))
#zonaGeo <- x[order(x)]



ui = dashboardPage(
  
  dashboardHeader(
    # title = div(tags$a(img(src="Logo cortados.png", height=60)),
    #             style = "position: relative; top: -5px;"), # Navigation bar
    title = "Ceros consecutivos",
    
    titleWidth = 300,
    
    tags$li(class = "dropdown",            # Presenta vínculo para 'Tour'
            tags$li(class = "dropdown", actionLink("ayuda", textOutput("Tour")))),
    
    dropdownMenuOutput("MensajeOrdenes"),  # Presenta mensajes en barra de encabezado
    dropdownMenuOutput("MensajeMapa")      # Presenta mensajes en barra de encabezado    
  ),
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 300,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   #introjsUI(),   # Se habilita presentación de ayuda
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   box(id = "Comandos", width = 12, 
                       status = NULL,  
                       background = "black",
                       fluidRow( column(width = 1,
                                        actionButton("ReiniciarControles", label = icon("fas fa-sync")),
                                        bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                       ),
                       column(width = 1,
                              offset = 1,
                              actionButton("TraerDatos", label = icon("fas fa-play")), 
                              bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                       )
                       )
                       
                   )  ,
                   box(id = "Empresas", width = 12, 
                       status = NULL,  
                       background = "black",
                       fluidRow( column(width = 2,
                                        actionButton("empresaOccidente", label = "Occidente"),
                                        bsTooltip("empresaOccidente"
                                                  , "Datos de Distribuidora de Electricidad de Occidente, S.A.", placement = "bottom", trigger = "hover", options = NULL)
                       ),
                       column(width = 2,
                              offset = 4,
                              actionButton("empresaOriente", label = "Oriente"), 
                              bsTooltip("empresaOriente"
                                        , "Datos de Distribuidora de Electricidad de Oriente, S.A.", placement = "bottom", trigger = "hover", options = NULL)
                       )
                       )
                       
                   ),
                   
                   # box(id = "Contadores", width = 12, status = NULL,  background = "black",
                   #     
                   #     dateInput(inputId="selectorFecha",
                   #               label="Fecha de corte:",
                   #               value=as.Date(fecha.max),
                   #               min=as.Date(fecha.min),
                   #               max =as.Date(fecha.max),
                   #               language = "es"),
                   #     bsTooltip("selectorFecha", "Último mes con consumo cero", placement = "bottom", trigger = "hover", options = NULL),
                   #     sliderInput(inputId="repeticiones",
                   #                 label="Períodos consecutivos en cero",
                   #                 min=1,max=as.numeric(valores.atributos[valores.atributos$Atributo == 'MaxCeros',]$Nombre) ,
                   #                 value=4,
                   #                 step=1,round=TRUE),
                   #     bsTooltip("repeticiones", "Mínimo número de períodos consecutivos en cero", 
                   #               placement = "bottom", trigger = "hover", options = NULL)
                   # ),
                   
                   
                   box( id = "filtros", width = 12, status = NULL,  background = "black",

                        pickerInput("zona_comercial","Zona:",
                                    choices = zonaCom,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Zona comercial"
                                    )),

                       
                        pickerInput("region","Región:",
                                    choices = c(''), #regionCom,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                   #   `live-search`=TRUE,
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Región"
                                    )),
                        
                        pickerInput("centro","Centro:",
                                    choices = centroCom,
                                    # selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Centro"
                                    )),
                        
                        pickerInput("itinerario","Itinerario:",
                                    choices = itinerarioCom,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Itinerario"
                                    ))  #,
                   ),
                   box( id = "filtros", width = 12, status = NULL,  background = "black",
                        

                        pickerInput("departamento","Departamento:",
                                    choices = departamentoGeo,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Seleccionar Circuito"
                                    )),

                        pickerInput("municipio","Municipio:",
                                    choices = c(''), #municipioGeo,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Seleccionar Municipio"
                                    )),

                        pickerInput("localidad","Localidad:",
                                    choices = c(''), #localidadGeo,
                                    multiple=T,
                                    options = list(
                                      #`live-search`=TRUE,
                                      `actions-box` = TRUE,
                                      `deselect-all-text` = "Ninguno",
                                      `select-all-text` = "Todos",
                                      `none-selected-text` = "Seleccionar Transformador"
                                    )) #,
                   #      pickerInput("zona_geo","Zona:",
                   #                  choices = zonaGeo,
                   #                  multiple=T,
                   #                  options = list(
                   #                    `live-search`=TRUE,
                   #                    `actions-box` = TRUE,
                   #                    `deselect-all-text` = "Ninguno",
                   #                    `select-all-text` = "Todos",
                   #                    `none-selected-text` = "Seleccionar Transformador"
                   #                  )),
                   #      
                    )
                   
  ),
  # Body --------------------------------------------------------------------
  
  dashboardBody(    
    tags$head(tags$style(HTML('

                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }

                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #00828F;
                              }

                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }

                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #00828F;
                              # }

                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #00828F;
                              }

                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }'
    )
    )
    ), # Fin estilo
    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel( type = "tabs",
                 useShinyjs()

    )
  )
)

server <-
  shinyServer(function(input, output, session) {
    # Importante iniciar con shinyServer para que funcione la ayuda
    observeEvent(input$ReiniciarControles, {
      print("Hola")
      
    }, ignoreInit = TRUE)
    
    observeEvent(input$zona_comercial, {
      print("en zona_comercial")
      seleccion_operativa <<- "zona_comercial"
      browser()
      lista_seleccion <- input$zona_comercial
      valores_validos <<- valores_ZonaOperativa %>% 
        filter(valores_ZonaOperativa$NombreZona %in% lista_seleccion)

      x <-  c(unique(valores_validos[c("NombreRegion")]))
      updatePickerInput(session,
                        "region",
                        choices = x[order(x)]) #, #c( atr$Nombre)))  ,
      #    selected = valor.seleccionado)
    }, ignoreInit = TRUE)
    
    
    observeEvent(input$region, {
      print("en region")
      seleccion_operativa <<- "region"
      browser()
      lista_seleccion <- input$region
      valores_validos <<- valores_validos %>% 
        filter(valores_validos$NombreRegion %in% lista_seleccion)
      x <-  c(unique(valores_validos[c("NombreOficina")]))
      
      updatePickerInput(session,
                        "centro",
                        choices = x[order(x)]) #, #c( atr$Nombre)))  ,
      #    selected = valor.seleccionado)
    }, ignoreInit = TRUE)
    
    
    # "centro"
    observeEvent(input$centro, {
      print("en centro")
      seleccion_operativa <<- "centro"
      browser()
      lista_seleccion <- input$centro
      valores_validos <<- valores_validos %>% 
        filter(valores_validos$NombreOficina %in% lista_seleccion)
      x <-  c(unique(valores_validos[c("Itinerario")]))
      
      updatePickerInput(session,
                        "itinerario",
                        choices = x[order(x)]) #, #c( atr$Nombre)))  ,
      #    selected = valor.seleccionado)
    }, ignoreInit = TRUE)
    
    # Itinerario
    observeEvent(input$itinerario, {
      print("en itinerario")
      seleccion_operativa <<- "itinerario"
      browser()
      lista_seleccion <- input$itinerario
      valores_validos <<- valores_validos %>% 
        filter(valores_validos$Itinerario %in% lista_seleccion)

      #    selected = valor.seleccionado)
    }, ignoreInit = TRUE)
    
    # departamento
    observeEvent(input$departamento, {
      print("en departamento")
      seleccion_geografia <<- "departamento"
      browser()
      lista_seleccion <- input$departamento
      valores_validos_Geografia <<- valores_Geografia %>% 
        filter(valores_Geografia$NombreDepartamentoGeografia %in% lista_seleccion)
      
      x <-  c(unique(valores_validos_Geografia[c("NombreMunicipioGeografia")]))
      updatePickerInput(session,
                        "municipio",
                        choices = x[order(x)])
    }, ignoreInit = TRUE)
    
    # municipio
    observeEvent(input$municipio, {
      print("en municipio")
      seleccion_geografia <<- "municipio"
      browser()
      lista_seleccion <- input$municipio
      valores_validos_Geografia <<- valores_validos_Geografia %>% 
        filter(valores_validos_Geografia$NombreDepartamentoGeografia %in% lista_seleccion)
      
      x <-  c(unique(valores_validos_Geografia[c("NombreLocalidadZonaGeografia")]))
      updatePickerInput(session,
                        "localidad",
                        choices = x[order(x)])
    }, ignoreInit = TRUE)
    
    # localidad
    observeEvent(input$localidad, {
      print("en localidad")
      seleccion_geografia <<- "localidad"
      browser()
      lista_seleccion <- input$localidad
      valores_validos_Geografia <<- valores_validos_Geografia %>% 
        filter(valores_validos_Geografia$NombreLocalidadZonaGeografia %in% lista_seleccion)
      

    }, ignoreInit = TRUE)
    
    
  })


# Ejecutar aplicación -----------------------------------------------------


shinyApp(ui = ui, server = server)