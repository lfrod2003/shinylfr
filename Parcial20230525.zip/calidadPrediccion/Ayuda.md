
## Modelo de Calidad de predicción

### Contenido

### Controles en los tableros


Para definir el grupo de suministros de interés para el reporte permite la definición de filtros por varios criterios:<br>
-   **Zona operativa**. Define un segmento de suministros por la jerarquía zona comercial - región - centro técnico u oficina - itinerario. Esta secuencia de filtros está relacionada y puede usarse definiendo uno o más elementos en uno o más de los niveles componentes. La selección se hace del nivel superior al inferior de la jerarquía.<br>
-   **Zona geográfica**. Compuesta por departamento, municipio y localidad. Esta secuencia de filtros está relacionada y puede usarse definiendo uno o más elementos en uno o más de los niveles componentes. La selección se hace del nivel superior al inferior de la jerarquía.<br>
-   **SMT**: Permite seleccionar suministros que están conectados a los smt escogidos.<br>
-   **Tensión**: Selecciona servicios por nivel de tensión.<br>
-   **Tarifa**: Selecciona servicios por tarifa.<br>
-   **Mercado**: Selecciona usuarios por tipo de mercado.<br>
-  **CNAE** y **grupo CNAE**. Selección de usuarios por tipo de actividad. Los dos filtros están relacionados. Debe escogerse primero el CNAE y luego el grupo asociado.<br>
-   **Iniciativa**: restringe los suministros mostrados a los que están asociados con una o más iniciativas.<br>
-   **PIMT**: Selecciona usuarios asociados con uno o más PIMT.<br>
-   **Año de normalización**: selecciona suministros por el año en que hayan sido objeto de normalización.<br>
-   **Estado de habitación**: Selecciona suministros con base en reportes recolectados durante lecturas o inspecciones sobre estado de habitación del inmueble.<br>



