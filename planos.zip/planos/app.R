# =============================================================================
#                             Consumos planos
# =============================================================================
# 
# Autor:                Luis Fernando Rodríguez
# Fecha de creación:    14.08.2020
# Versión:              0
# Descripción:
# Reporte para encontrar usuarios con consumos planos. Se definen consumos
# planos como los que tienen un coeficiente de variación inferior al especificado
# en un parámetro de usuario en la ventana de consumo especificada por el usuario
# con una fecha de corte
#
# Tablas de consulta directa: [Aux].[Parametros], [Dimension].[Campaña]
# Tablas en las que escribe: [Hecho].[ConsumoNormalizado]
# Procedimientos almacenados relacionados: [dbo].[Dataset_ConsumosPlanos_shiny] 
# Pendientes:  Ajustar hipervínculos para conectar con hoja de vida
#
# =============================================================================

# Carga de librerías ------------------------------------------------------

library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
library(lubridate)
library(shinydashboard)
library(DT)
library(ggplot2)
library(plotly)         # Gráficas dinámicas plotly
library(rhandsontable)  # Visualización tablas
library(RCurl)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(stringr)
require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
library(rintrojs)       # Presentación de ayuda en pantalla
library(openxlsx)

source("helpers.R")
#reactlog_enable()

# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}



# Retornar tabla para despliegue ---------------------------------------------
tabla.despliegue <- function(tabla.temp, obj) {
  if(nrow(obj)!=0 ) {
    b1 <- tabla.temp %>% filter(CodigoPuntoConsumo %in% obj$CodigoPuntoConsumo)
    if (nrow(obj)== nrow(b1)){
      obj[,1] <- b1[,1]}
    tabla.temp <- obj
  }
  
  tabla.temp$Nombre_corto_SMT <- paste0(tabla.temp$CodigoCircuito, " ",tabla.temp$Nombre_corto_SMT)
  
  rhandsontable(tabla.temp[,1:15],
                rowHeaders = TRUE,
                colHeaders = c(
                  '°',
                  'Código',
                  'Nombre',
                  'Dirección',
                  'Actividad',
                  'Coeficiente de variación',
                  'Prom. 6 mss ant. [kWh]',
                  'Zona',
                  'Región',
                  'Oficina',
                  'Itinerario',
                  'Departamento',
                  'Municipio',
                  'Localidad',
                  'Circuito'
                ),
                height =380,
                search = FALSE,
                readOnly = TRUE,
                selectCallback = TRUE)%>% 
    hot_col(1, halign = "htCenter", readOnly = FALSE) %>% 
    hot_col(2, renderer = "html",halign = "htRight") %>%                # Mostrar como hipervínculo
    hot_col(2, renderer = htmlwidgets::JS("safeHtmlRenderer")) %>%      # Mostrar como hipervínculo
    hot_cols(fixedColumnsLeft=2) %>%  
    hot_col(7,format="#.00", halign="htRight" ) %>% 
    hot_heatmap(7, color_scale =c("#17F556", "#ED6D47")) %>%  # Habilitar escala de color
    hot_cols(columnSorting = TRUE)  %>%   
    hot_context_menu(allowRowEdit = FALSE, allowColEdit = FALSE) %>%    # Bloquea opciones de menú contextual
    hot_table(highlightCol = TRUE, highlightRow = TRUE)                 # Resalta fila y columna seleccionada
  
}

# Retornar mapa para despliegue --------------------------------------------
mapa.despliegue<- function(tabla.temp, obj, datos.consulta, banderaRefresco,tabla.datos.valida, input) { #} datos.imagen, input) { 

  if (tabla.datos.valida) {
    tabla.temp <-  hot_to_r(input$datos)
    ordenes <- subset(tabla.temp, tabla.temp[,1] == TRUE)[,-1]
  } else if(nrow(obj)!=0) {
    ordenes <- obj
  } else {
    ordenes <- subset(tabla.temp, tabla.temp[,1] == TRUE)[,-1]
  }


  for(i in 1:nrow(ordenes)){                                      # Extrae el número de cliente del hipervínculo
    pos.cliente <- gregexpr(">",ordenes$CodigoPuntoConsumo[i])
    pos.cliente <- pos.cliente[[1]][1] + 1
    fin.cad <- nchar(ordenes$CodigoPuntoConsumo[i]) - 4
    ordenes$CodigoPuntoConsumo[i] <- substr(ordenes$CodigoPuntoConsumo[i],pos.cliente,fin.cad)
  }
  ordenes$CodigoPuntoConsumo <- unlist(ordenes$CodigoPuntoConsumo)
  
  datos<-left_join(ordenes,datos.consulta,by = "CodigoPuntoConsumo") # Efectua unión para traer coordenadas
  datos.consulta$PromedioActiva6CN<-as.numeric(as.character(datos.consulta$PromedioActiva6CN))  # Convierte a numérico
  datos.consulta$PromedioActiva6CN[is.na(datos.consulta$PromedioActiva6CN)]=0                  # Ajuste de valores nulos
  datos$LatitudPuntoConsumo <-as.numeric(as.character(datos$LatitudPuntoConsumo))
  datos$LongitudPuntoConsumo <-as.numeric(as.character(datos$LongitudPuntoConsumo))

  
  if (banderaRefresco) {
    google_map_update(map_id = "map") %>%
      clear_markers() %>%
      googleway::add_markers(data = datos,lat = "LatitudPuntoConsumo", lon = "LongitudPuntoConsumo", 
                             info_window = "Texto1",close_info_window = TRUE)
                             #info_window = "texto",close_info_window = TRUE)
  } else {
    google_map(key = api_key, data = datos, style=estilo.map01) %>%
      googleway::add_markers(lat = "LatitudPuntoConsumo", lon = "LongitudPuntoConsumo", 
                             info_window = "Texto1",close_info_window = TRUE)
  #  info_window = "texto",close_info_window = TRUE)
  }
}



# Configurar consulta por datos geografia --------------------------------------------
consulta_geografia <- function (seleccion_geografia, valores_Geografia,input) {
  
  valores_validos_Geografia <- valores_Geografia
  lista_seleccion <- input$departamento
  if (length(lista_seleccion) > 0) {
    valores_validos_Geografia <- valores_Geografia %>% 
      filter(valores_Geografia$NombreDepartamentoGeografia %in% lista_seleccion)	  
    lista_seleccion <- input$municipio
    if (length(lista_seleccion) > 0) {
      valores_validos_Geografia <- valores_validos_Geografia %>% 
        filter(valores_validos_Geografia$NombreMunicipioGeografia %in% lista_seleccion)
      lista_seleccion <- input$localidad
      if (length(lista_seleccion) > 0) {
        valores_validos_Geografia <- valores_validos_Geografia %>% 
          filter(valores_validos_Geografia$NombreLocalidadZonaGeografia %in% lista_seleccion)
      }
    }
  }
  valores_validos_Geografia <<- valores_validos_Geografia 
  valores_validos_Geografia
}

# Configurar consulta por datos Zona --------------------------------------------
consulta_zona <- function (seleccion_operativa, valores_ZonaOperativa,input) {
  
  valores_validos <- valores_ZonaOperativa
  lista_seleccion <- input$zona_comercial
  if (length(lista_seleccion) > 0) { 
    valores_validos <- valores_ZonaOperativa %>% 
      filter(valores_ZonaOperativa$NombreZona %in% lista_seleccion)
    lista_seleccion <- input$region
    if (length(lista_seleccion) > 0) {
      valores_validos <- valores_validos %>% 
        filter(valores_validos$NombreRegion %in% lista_seleccion)
      lista_seleccion <- input$centro
      if (length(lista_seleccion) > 0) {
        valores_validos <- valores_validos %>% 
          filter(valores_validos$NombreOficina %in% lista_seleccion)
        lista_seleccion <- input$itinerario
        if (length(lista_seleccion) > 0) {
          x1 <- strsplit(lista_seleccion, " - ",fixed = T)
          x2 <- do.call(rbind, x1)
          new_dim <- dim(x2)
          x3 <- matrix(x2, nrow = new_dim[1])
          valores_validos <- valores_validos %>% 
            filter(valores_validos$NombreOficina %in% x3[,1] & valores_validos$Itinerario %in% x3[,2])
        }
      }
    }
  }
  valores_validos <<- valores_validos
  valores_validos
}

# Conversión de archivo Rmd a md
#rmdfiles <- c("AyudaConsumosCero.Rmd")
#sapply(rmdfiles, knit, quiet = T)

# Configuración de bd y código para api google --------------------------------------------------------------
configuracion.conexion <<- Sys.getenv("CONEXIONSHINY") #'windows'
#  'GoogleKey' CodigoParametro api google en [DWSRBI_ENERGUATE].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "SELECT TOP 1 ValorParametro FROM [DWSRBI_ENERGUATE].[Aux].[Parametros] where EstadoParametro = 1 AND   CodigoParametro = 'GoogleKey'"
api_key <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)
api_key <<- api_key[1,1]


# Configuración de bd y código para api google
configuracion.conexion <<- Sys.getenv("CONEXIONSHINY") #'windows'
#  'GoogleKey' CodigoParametro api google en [DWSRBI_ENERGUATE].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "SELECT TOP 1 ValorParametro FROM [DWSRBI_ENERGUATE].[Aux].[Parametros] where EstadoParametro = 1 AND   CodigoParametro = 'GoogleKey'"
api_key <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)
api_key <<- api_key[1,1]


# Contadores y llamadas--------------------------------------------------------------
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante
#api_key <- "AIzaSyAYoARt3zU_arrmeiZmMCjXhLEyRoE7Z2Q"  # Solicitar clave a WM y cambiar
Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')
locale <- Sys.getlocale(category="LC_COLLATE")
if (grepl("Spanish", locale, fixed=TRUE)) {
  separador.csv <<- ';'
} else {
  separador.csv <<- ','
}

# Captura de parámetro para URL servidor shiny -------------
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql<- "SELECT [ValorParametro]  FROM [DWSRBI_ENERGUATE].[Aux].[Parametros]  WHERE [CodigoParametro] = 'URLshiny'"
URL.servidor.shiny <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
URL.servidor.shiny <- URL.servidor.shiny [1,1]
str.http <<- paste(URL.servidor.shiny,"hvurl/?Codigo=",sep="") # Cadena de llamada para vínculo a hoja de vida




# Captura de campañas disponibles en BD y valores de filtros -----------------------------------
cad.sql<- "[dbo].[Leer_Campanas]"
nom.camp <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom.camp)<-"Nombre"
nom.camp <- nom.camp  %>% filter(!is.na(Nombre))

cad.sql <- "SELECT DISTINCT [NombreServicio] FROM [Dimension].[Servicio] where codigoservicio > 0  ORDER BY [NombreServicio]"
nom_servicios <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom_servicios) <- "Nombre"
nom_servicios <- nom_servicios   %>% filter(!is.na(Nombre))
nom_servicios <- c("G. clientes", "PIMT", "Masivos", "Consumos fijos", "Autoproductores")

cad.sql<-"EXEC [dbo].[Lista_FiltroZona]"
valores_ZonaOperativa <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

cad.sql <- "EXEC [dbo].[Lista_FiltroGeografia]"
valores_Geografia <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

cad.sql <- "EXEC [dbo].[Lista_FiltroCircuitos]"
valores_Circuitos <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)


cad.sql <- "EXEC [dbo].[Lista_FiltroIniciativa]"
valores_Iniciativa <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

cad.sql <- "EXEC [dbo].[Lista_CNAE]"
valores_CNAE <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

cad.sql <- "EXEC [dbo].[Lista_yyNormalizacion]"
valores_Normalizacion <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

cad.sql <- "EXEC [dbo].[Lista_PIMT]"
valores_PIMT <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)


cad.sql <- "EXEC [dbo].[Lista_FiltroTarifa]"
valores_Tarifa <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)


cad.sql <- "EXEC [dbo].[Lista_FiltroTension]"
valores_Tension <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

cad.sql <- "EXEC [dbo].[Lista_Estados]"
valores_Estados <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)


cad.sql <- "EXEC [dbo].[Lista_Mercado]"
valores_Mercado <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

odbcClose(conexion)

# Carga contenido filtros -----------------------------------

seleccion_operativa <<- 'no'
# Datos iniciales para  selectores de jerarquía
x <-  c(unique(valores_ZonaOperativa[c("NombreZona")]))
zonaCom <- x[order(x)]
zonaComColor <- rep(paste0("color:black;"),length(zonaCom))
x  <-  c(unique(valores_ZonaOperativa[c("NombreRegion")]))
regionCom <- x[order(x)]
regionComColor <- rep(paste0("color:black;"),length(regionCom))
x <- c(unique(valores_ZonaOperativa[c("NombreOficina")]))
centroCom <- x[order(x)]
centroComColor <- rep(paste0("color:black;"),length(centroCom))
#x <- c(unique(valores_ZonaOperativa[c("Itinerario")]))
x <- valores_ZonaOperativa %>% select("NombreOficina", "Itinerario") %>% 
  distinct() %>% arrange(NombreOficina, Itinerario)
x <- paste0(x$NombreOficina, " - ", x$Itinerario)
itinerarioCom <- x
itinerarioComColor <- rep(paste0("color:black;"),length(itinerarioCom))

seleccion_geografia <<- 'no'
x <-  c(unique(valores_Geografia[c("NombreDepartamentoGeografia")]))
departamentoGeo <- x
x <-  c(unique(valores_Geografia[c("NombreMunicipioGeografia")]))
municipioGeo <- x[order(x)]
x <-  c(unique(valores_Geografia[c("NombreLocalidadZonaGeografia")]))
localidadGeo <- x[order(x)]
#x <-  c(unique(valores_Geografia[c("NombreZona")]))
#zonaGeo <- x[order(x)]

seleccion_circuito <<- 'no'
x <-  c(unique(valores_Circuitos[c("CodigoCircuito")]))
codigosCircuito <- x[order(x)]

seleccion_iniciativa <<- 'no'
x <-  c(unique(valores_Iniciativa[c("NombreCampaña")]))
codigosIniciativa <- x[order(x)]

seleccion_CNAE <<- 'no'
x <- c(unique(valores_CNAE[c("Grupo")]))
codigosCNAE <- x[order(x)]

seleccion_grupo <<- 'no'
x <- c(unique(valores_CNAE[c("Seccion")] %>% filter(!is.na(Seccion))))
codigosCNAE_grupos <- x[order(x)]

seleccion_ynormalizacion <<- 'no'
seleccion_yyyyNormalizacion <<- 'no' 
codigosyyyyNormalizacion <- as.integer(valores_Normalizacion[1,1]):as.integer(valores_Normalizacion[1,2])

seleccion_PIMT <<- 'no'
x <-  c(unique(valores_PIMT[c("NombreProyecto")]))
codigosPIMT <- x[order(x)]


seleccion_tarifa <<- 'tarifa'
x <-  c(unique(valores_Tarifa[c("NombreTarifa")]))
codigosTarifa <- x[order(x)]


seleccion_tension <<- 'no'
x <-  c(unique(valores_Tension[c("NombreTension")]))
codigosTension <- x[order(x)]


seleccion_estado <<- 'estado'
x <-  c(unique(valores_Estados[c("NombreEstado")]))
codigosEstado <- x[order(x)]

seleccion_mercado <<- 'mercado'
x <-  c(unique(valores_Mercado[c("NombreMercado")]))
codigosMercado <- x[order(x)]



# UI ----------------------------------------------------------------------
dbHeader <- dashboardHeader()
dbHeader <- dashboardHeader(title = "Consumos planos",
                            tags$li(div(
                              img(src = 'Kronos.png',
                                  title = "Ceros consecutivos", height = "30px"),
                              style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                              class = "dropdown"),
                            dropdownMenuOutput("MensajeOrdenes"))  # Presenta mensajes en barra de encabezado)

ui = dashboardPage(
  # dashboardHeader(
  #    title = "Consumos planos",
  #   
  #   titleWidth = 300,
  #   
  #   # tags$li(class = "dropdown",            # Presenta vínculo para 'Tour'
  #   #         tags$li(class = "dropdown", actionLink("ayuda", textOutput("Tour")))),
  #   
  #   dropdownMenuOutput("MensajeOrdenes"),  # Presenta mensajes en barra de encabezado
  #   dropdownMenuOutput("MensajeMapa")      # Presenta mensajes en barra de encabezado    
  # ),
  dbHeader,
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 500,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   introjsUI(),   # Se habilita presentación de ayuda
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   fluidRow( column(width = 6,offset = 0, style='padding:0px;',
                   box(id = "Comandos", width = 12, 
                        status = NULL,  
                        background = "black",
                        fluidRow( column(width = 2,offset = 1,
                                         actionButton("ReiniciarControles", label = icon("fas fa-sync"),
                                                      style="color: #fff; background-color: #0070ba; border-color: #0070ba"),
                                        bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                        ),
                        column(width = 2,
                               offset = 1,
                               actionButton("TraerDatos", label = icon("fas fa-play"),
                                            style="color: #fff; background-color: #0070ba; border-color: #0070ba"), 
                               bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                        )
                        )
                        
                   ),

                   box(id = "Contadores", width = 12, status = NULL,  background = "black",

                        sliderInput(inputId="mesesRevisar",
                                    label="Meses de historia a revisar",
                                    min=1,max=12 ,
                                    value=6,
                                    step=1,round=TRUE),
                       bsTooltip("mesesRevisar", "Meses de historia a revisar por consumos planos",
                                 placement = "bottom", trigger = "hover", options = NULL),
                       sliderInput(inputId="coefVariacion",
                                   label="Máximo coeficiente de variación",
                                   min=0,max=1 ,
                                   value=0.02,
                                   step=0.02), #,round=TRUE),
                       bsTooltip("coefVariacion", "Máximo índice de variación", 
                                 placement = "bottom", trigger = "hover", options = NULL)
                   ),

                   box( id = "filtros1", width = 12, status = NULL,  background = "black",
                        pickerInput("zona_comercial","Zona:",
                                    choices = sort(zonaCom[[1]]),
                                    selected = NULL,
                                    multiple=T,
                                    choicesOpt = list(
                                      style=rep(paste0("color:black;"),length(zonaCom[[1]]))),
                                    options = list(
                                      #`actions-box` = TRUE,
                                      #`deselect-all-text` = "Ninguno",
                                      #`select-all-text` = "Todos",
                                      `none-selected-text` = "Zona comercial"
                                    )),
                        
                        
                        pickerInput("region","Región:",
                                    choices = c(''), #regionCom,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      # `actions-box` = TRUE,
                                      # `deselect-all-text` = "Ninguno",
                                      # `select-all-text` = "Todos",
                                      `none-selected-text` = "Región"
                                    )),
                        
                        pickerInput("centro","Centro técnico:",
                                    choices = c(''),
                                    # selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      # `actions-box` = TRUE,
                                      # `deselect-all-text` = "Ninguno",
                                      # `select-all-text` = "Todos",
                                      `none-selected-text` = "Centro"
                                    )),
                        
                        pickerInput("itinerario","Control de itinerario:",
                                    choices = c(''),
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = list(
                                      # `actions-box` = TRUE,
                                      # `deselect-all-text` = "Ninguno",
                                      # `select-all-text` = "Todos",
                                      `none-selected-text` = "Itinerario"
                                    ))  #,
                   ),
                   
                   box( id = "filtros2", width = 12, status = NULL,  background = "black",
                        pickerInput("departamento","Departamento:",
                                    choices = sort(departamentoGeo[[1]]),
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    choicesOpt = list(
                                      style=rep(paste0("color:black;"),length(departamentoGeo[[1]]))),
                                    options = pickerOptions(
                                      # `actions-box` = TRUE,
                                      # `deselect-all-text` = "Ninguno",
                                      # `select-all-text` = "Todos",
                                      livesearch = TRUE,
                                      `none-selected-text` = "Seleccionar Departamento"
                                    )),
                        
                        pickerInput("municipio","Municipio:",
                                    choices = c(''), #municipioGeo,
                                    #selected = '-TODOS-',
                                    multiple=T,
                                    options = pickerOptions(
                                      # `actions-box` = TRUE,
                                      # `deselect-all-text` = "Ninguno",
                                      # `select-all-text` = "Todos",
                                      livesearch = TRUE,
                                      `none-selected-text` = "Seleccionar Municipio"
                                    )),
                        
                        pickerInput("localidad","Localidad:",
                                    choices = c(''), #localidadGeo,
                                    multiple=T,
                                    options = pickerOptions(
                                      #`live-search`=TRUE,
                                      # `actions-box` = TRUE,
                                      # `deselect-all-text` = "Ninguno",
                                      # `select-all-text` = "Todos",
                                      livesearch = TRUE,
                                      `none-selected-text` = "Seleccionar localidad"
                                    ))
                        #      
                   )),
                   column(width = 6, offset = 0, style='padding:0px;',
                          box(id = "Empresas", width = 12, 
                              status = NULL,  
                              background = "black",
                              
                              pickerInput("circuitos","SMT:",
                                          choices = sort(codigosCircuito[[1]]),
                                          #selected = '-TODOS-',
                                          multiple=T,
                                          choicesOpt = list(
                                            style=rep(paste0("color:black;"),length(codigosCircuito[[1]]))),
                                          options = list(
                                            # `actions-box` = TRUE,
                                            # `deselect-all-text` = "Ninguno",
                                            # `select-all-text` = "Todos",
                                            `none-selected-text` = "SMT"
                                          )),
                              pickerInput("estado","Estado:",
                                          choices = sort(codigosEstado[[1]]),
                                          selected = c("Situacion correcta"),
                                          multiple=T,
                                          choicesOpt = list(
                                            style=rep(paste0("color:black;"),length(codigosEstado[[1]]))),
                                          options = list(
                                            # `actions-box` = TRUE,
                                            # `deselect-all-text` = "Ninguno",
                                            # `select-all-text` = "Todos",
                                            `none-selected-text` = "Estado"
                                          )),
                              pickerInput("tension","Tensión:",
                                          choices = sort(codigosTension[[1]]),
                                          #selected = '-TODOS-',
                                          multiple=T,
                                          choicesOpt = list(
                                            style=rep(paste0("color:black;"),length(codigosTension[[1]]))),
                                          options = list(
                                            # `actions-box` = TRUE,
                                            # `deselect-all-text` = "Ninguno",
                                            # `select-all-text` = "Todos",
                                            `none-selected-text` = "Tensión"
                                          )),
                              pickerInput("tarifa","Tarifa:",
                                          choices = sort(codigosTarifa[[1]]),
                                          selected = c("BT Simple DC", "BT Simple DR"),
                                          multiple=T,
                                          choicesOpt = list(
                                            style=rep(paste0("color:black;"),length(codigosTarifa[[1]]))),
                                          options = list(
                                            # `actions-box` = TRUE,
                                            # `deselect-all-text` = "Ninguno",
                                            # `select-all-text` = "Todos",
                                            `none-selected-text` = "Tarifa"
                                          )),
                              pickerInput("mercado","Tipo de mercado:",
                                          choices = sort(codigosMercado[[1]]) ,
                                          selected = 'Gestion normal',
                                          multiple=T,
                                          choicesOpt = list(
                                            style=rep(paste0("color:black;"),length(codigosMercado[[1]]))),
                                          options = list(
                                            # `actions-box` = TRUE,
                                            # `deselect-all-text` = "Ninguno",
                                            # `select-all-text` = "Todos",
                                            `none-selected-text` = "Mercado"
                                          )),
                              
                              pickerInput("cnae","CNAE:",
                                          choices = sort(codigosCNAE[[1]]),
                                          #selected = '-TODOS-',
                                          multiple=T,
                                          choicesOpt = list(
                                            style=rep(paste0("color:black;"),length(codigosCNAE[[1]]))),
                                          options = list(
                                            # `actions-box` = TRUE,
                                            # `deselect-all-text` = "Ninguno",
                                            # `select-all-text` = "Todos",
                                            `none-selected-text` = "CNAE"
                                          )),
                              pickerInput("cnaegrupo","CNAE grupo:",
                                          choices = sort(codigosCNAE_grupos[[1]]),
                                          #selected = '-TODOS-',
                                          multiple=T,
                                          choicesOpt = list(
                                            style=rep(paste0("color:black;"),length(codigosCNAE_grupos[[1]]))),
                                          options = list(
                                            # `actions-box` = TRUE,
                                            # `deselect-all-text` = "Ninguno",
                                            # `select-all-text` = "Todos",
                                            `none-selected-text` = "CNAE grupo"
                                          )),
                              pickerInput("iniciativa","Iniciativa:",
                                          choices = sort(codigosIniciativa[[1]]),
                                          #selected = '-TODOS-',
                                          multiple=T,
                                          choicesOpt = list(
                                            style=rep(paste0("color:black;"),length(codigosIniciativa[[1]]))),
                                          options = list(
                                            # `actions-box` = TRUE,
                                            # `deselect-all-text` = "Ninguno",
                                            # `select-all-text` = "Todos",
                                            `none-selected-text` = "Iniciativa"
                                          )),
                              pickerInput("pimt","PIMT:",
                                          choices = sort(codigosPIMT[[1]]),
                                          #selected = '-TODOS-',
                                          multiple=T,
                                          choicesOpt = list(
                                            style=rep(paste0("color:black;"),length(codigosPIMT[[1]]))),
                                          options = list(
                                            # `actions-box` = TRUE,
                                            # `deselect-all-text` = "Ninguno",
                                            # `select-all-text` = "Todos",
                                            `none-selected-text` = "PIMT"
                                          )),
                              pickerInput("ynormalizacion","Año de normalización:",
                                          choices = sort(codigosyyyyNormalizacion[[1]]),
                                          multiple=T,
                                          choicesOpt = list(
                                            style=rep(paste0("color:black;"),length(codigosyyyyNormalizacion[[1]]))),
                                          options = list(
                                            # `actions-box` = TRUE,
                                            # `deselect-all-text` = "Ninguno",
                                            # `select-all-text` = "Todos",
                                            `none-selected-text` = "Año normalización"
                                          )),
                              
                              radioButtons(inputId = "habitacion", 
                                           label = "Estado habitación:", 
                                           choices = c("h", "n/h"),                                  
                                           inline = TRUE
                              )
                              
                              
                          )
                   ))
 
                   
  ),
  
  # Body --------------------------------------------------------------------
  ##00828F;
  dashboardBody(    
    tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }'
    )
    )
    ), # Fin estilo
    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel( type = "tabs", 

                tabPanel("Gráfica" , icon = icon("bar-chart-o"),
                         hr(),
                         box(
                           width = 12,
                           status = "warning",
                           solidHeader = FALSE,
                           title = "Cuentas con consumos planos",
                         fluidRow(column(width = 2,
                                         offset = 10,
                                         materialSwitch('selec.graf', 
                                                        label = "Puntos / Barras", 
                                                        value = FALSE, 
                                                        inline =  FALSE),
                                         bsTooltip("selec.graf", "Presentar en gráfica de puntos / barras", 
                                                   placement = "bottom", trigger = "hover", options = NULL)
                         )),
                         hr(),
                         
                         #withSpinner(                                                        # Incluir spinner de espera
                           plotlyOutput("plot",height = "550px"), # height = "500px"), #,brush = brushOpts("b1")),                 
                         #  color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                         #),
                         
                         useShinyjs(),
                         # code to reset plotlys event_data("plotly_click", source="A") to NULL -> executed upon action button click
                         # note that "A" needs to be replaced with plotly source string if used
                         extendShinyjs(text = "shinyjs.resetGraph = function() { Shiny.onInputChange('.clientValue-plotly_selected-master', 'null'); }",
                                       functions=c("resetGraph")) 
                )),              
                tabPanel("Datos",
                         icon = icon("fas fa-table"),
                         hr(),
                         
                         fluidRow( 
                           box(#height = 420,
                               width = 12,
                               status = "warning",
                               solidHeader = FALSE,
                               title = "Consumos planos",
                               radioButtons(inputId = "selec.tod", 
                                            label = "Seleccionar datos:", 
                                            choices = c("Todos", "Ninguno"),                                  
                                            inline = TRUE
                               ),
                               bsTooltip("selec.tod", "Seleccionar todos / ninguno", 
                                           placement = "bottom", trigger = "hover", options = NULL),
                               
                               
                               br(),
                               withSpinner(rHandsontableOutput("datos", height = "550px"),         # Incluir spinner de espera
                                           color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                               )
                               
                           )),
                         hr(),
                         fluidRow(hr() ,      
                                  column(width = 2,
                                  actionButton("MostrarTabla",   # Se crea el botón deshabilitado para que
                                               "Actualizar tabla" ,   # sea habilitado posteriormente por código
                                               style="color: #fff; background-color: #0070ba; border-color: #0070ba"
                                  )),
                                  column(width = 2,
                                         offset = 6,
                                         shinyjs::disabled(downloadButton('Descargar', 'Descargar excel',
                                                                          style="color: #fff; background-color: #0070ba; border-color: #0070ba"),  # Se crea el botón deshabilitado para que
                                                           bsTooltip("Descargar", "Descargar usuarios seleccionados a archivo excel", 
                                                                     placement = "bottom", trigger = "hover", options = NULL)
                                         )                                           # sea habilitado posteriormente por código
                                         
                                  ),
                                  column(width = 2,
                                         shinyjs::disabled(  # Se crea el botón deshabilitado para que
                                           actionButton("Guardar",   
                                                        "Generar órdenes" ,   
                                                        icon = icon("fas fas fa-save"),
                                                        style="color: #fff; background-color: #0070ba; border-color: #0070ba"
                                         ),
                                         bsTooltip("Guardar", "Crear órdenes de inspección para usuarios seleccionados", 
                                                   placement = "bottom", trigger = "hover", options = NULL)
                                         )
                                  )
                         )                         
                ),
                tabPanel("Ayuda",
                         icon = icon("fas fa-table"),
                         includeMarkdown("AyudaConsumosPlanos.Rmd")
                         
                ),


                # tabPanel("Mapa",icon = icon("fas fa-map-marker-alt"),
                #          hr(),
                #          box(#height = 420,
                #              width = 12,
                #                status = "warning",
                #              solidHeader = FALSE,
                #              title = "Localización de cuentas seleccionadas",
                # 
                #          withSpinner(google_mapOutput("map", width='auto',height="770px"),
                #                      color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                #          ),
                #          hr(),
                #          fluidRow(
                #                   column(width = 2,
                #                          offset = 8,
                #                          actionButton("MostrarMapa",   # Se crea el botón deshabilitado para que
                #                                       "Actualizar mapa"    # sea habilitado posteriormente por código
                #                          )
                #                   )
                #          ) )),  
                
      id="TabsApp"
    )
  )
)

# Server ------------------------------------------------------------------

server <- shinyServer(function(input, output, session) { # Importante iniciar con shinyServer para que funcione la ayuda
  
  consulta.activa <<- FALSE
  datos.consulta <- NA
  tipo.grafica <- 'P'
  tabla.datos.valida <- FALSE
  valores_validos_zona <<- NA
  valores_validos_region <<- NA
  valores_validos_centro <<- NA
  valores_validos_Geografia_departamento  <<- NA
  valores_validos_Geografia_municipio <<- NA
  valores_validos_estado <<- NA
  valores_validos_tarifa <<- NA
  valores_validos_mercado <<- NA
  # tabla.datos <- data.frame( '°'= logical(),
  #                            CodigoPuntoConsumo=character(),
  #                            NombreCliente=character(),
  #                            DireccionPuntoConsumo=character(),
  #                            Zona=character(),
  #                            Municipio=character(),
  #                            Circuito=character(),
  #                            AcumuladoConsumoCeroCN=double(),
  #                            PromedioActiva6CN=double(),
  #                            Ciclo=character(),
  #                            Estrato=character(),
  #                            Actividad=character(),
  #                            Transformador=character(),
  #                            LlaveFechaEjecucion=character(),
  #                            texto=character(),
  #                            stringsAsFactors = FALSE)

  
  # Ocultar Botones auxiliares para sincronizar paneles, paneles
  shinyjs::hide("MostrarTabla")
  shinyjs::hide("MostrarMapa")



  
  # Ayuda -------------------------------------------------------------------
  
  output$Tour <- renderText({"Tour" })  # Presenta acceso de ayuda en la cabecera
  
  steps <- reactive(  # Crea data frame para incluir los temas de ayuda
    data.frame(
      element = c(NA, "#Comandos", "#Contadores", "#filtros", "#Gráfica",
                  "#selec.graf", "#Datos", "#selec.tod", "#Descargar", "#Guardar", "#Mapa"),  # Se incluyen nombres de los objetos
      intro = c(
        "Este reporte muestra las cuentas con consumos planos. Las cuentas se seleccionan por fecha y pueden filtrarse por varios atributos de cada cuenta. La información se muestra de forma gráfica, tabular, y por información geográfica asociada, si está disponible.",
        "El botón izquierdo Reinicializa las listas de valores en los botones de filtro. El botón derecho hace la consulta para traer los datos que corresponden a los filtros seleccionados.",
        "Escoger fecha de último mes con consumos planos que se tiene en cuenta para la selección, y número mínimo de consumos planos consecutivos para las cuentas seleccionadas.",
        "Utilice las listas desplegables para efectuar fitros por categorías.",
        "La gráfica muestra las cuentas seleccionadas. La gráfica de puntos muestra cada usuario como un punto, situado de acuerdo al índice de variación (eje horizontal), y el promedio de consumo en los últimos seis meses (eje vertical). La gráfica de barras muestra el número de usuarios por índice de variación en la muestra. En la parte superior de las gráficas hay  herramientas que le facilitarán la visualización, la navegación y exportación de imágenes.",
        "El selector de tipo de gráfica permite alternar en la presentación de los datos por gráfica de puntos o diagrama de barras",
        "El panel de datos muestra en forma tabular las cuentas seleccionadas y los valores de atributos asociados. La columna de selección indica los datos para descarga a archivo o generación de órdenes de consumo.",
        "El botón de selección en el panel de datos permite marcar todos los datos en la tabla, o desmarcarlos.",
        "El botón de guardar en el panel de datos crea un archivo csv con los datos de las cuentas seleccionadas en la tabla.",
        "El botón de generar órdenes en el panel de datos crea órdenes de consumo para las cuentas seleccionadas en la tabla.",
        "El panel de mapas muestra la ubicación geográfica de las cuentas de interés."
      )
    )
  )
  
  observeEvent(input$ayuda, {
    # alert("Presionó ayuda")
    introjs(session, options = list("nextLabel"="Siguiente",
                                    "prevLabel"="Anterior",
                                    "skipLabel"="Salir",
                                    "doneLabel"="Terminado",
                                    steps=steps())
    )
    
  })
  
  # Cambio de tab ----------------------------------------------------------------------
  observeEvent(input$TabsApp, {

    if (input$TabsApp == "Datos") {
      tabla.datos.valida <<- TRUE
    } else if (input$TabsApp == "Mapa") {
      click("MostrarMapa")
    }
  }, ignoreInit = TRUE)
  
  # Carga de datos a listas desplegables  ---------------------------------------------------
  #
  # Jerarquía de zonas operativas
  
  observeEvent(input$zona_comercial, {
    seleccion_operativa <<- "zona_comercial"
    lista_zona <- input$zona_comercial
    valores_validos_zona <<- valores_ZonaOperativa %>% 
      filter(valores_ZonaOperativa$NombreZona %in% lista_zona)
    
    valores_validos <<- valores_validos_zona
    x <-  c(unique(valores_validos_zona [c("NombreRegion")]))
    xColor <- rep(paste0("color:black;"),length(x[[1]]))
    updatePickerInput(session,
                      "region",
                      choices = sort(x[[1]]),
                      choicesOpt = list(
                        style=rep(paste0("color:black;"),length(x[[1]])))) #c( atr$Nombre)))  ,
    #    selected = valor.seleccionado)
  }, ignoreInit = TRUE)
  
  
  
  observeEvent(input$region, {
    if (!is.na(valores_validos_zona))  {
      seleccion_operativa <<- "region"
      lista_region <- input$region
      valores_validos_region <<- valores_validos_zona %>% 
        filter(valores_validos_zona$NombreRegion %in% lista_region)
      valores_validos <<- valores_validos_region
      x <-  c(unique(valores_validos_region[c("NombreOficina")]))
      
      updatePickerInput(session,
                        "centro",
                        choices = sort(x[[1]]),
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(x[[1]])))) #, #c( atr$Nombre)))  ,
      #    selected = valor.seleccionado)
    }
  }, ignoreInit = TRUE)
  
  
  # "centro"
  observeEvent(input$centro, {
    if (!is.na(valores_validos_region)) {
      seleccion_operativa <<- "centro"
      lista_centro <- input$centro
      valores_validos_centro <<- valores_validos_region %>% 
        filter(valores_validos_region$NombreOficina %in% lista_centro)
      valores_validos <<- valores_validos_centro
      x <- valores_validos_centro %>% select("NombreOficina", "Itinerario") %>% 
        distinct() %>% arrange(NombreOficina, Itinerario)
      x <- paste0(x$NombreOficina, " - ", x$Itinerario)
      
      updatePickerInput(session,
                        "itinerario",
                        choices = sort(x[[1]]),
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(x)))) #, #c( atr$Nombre)))  ,
      #    selected = valor.seleccionado)
    }
  }, ignoreInit = TRUE)
  
  # Itinerario
  observeEvent(input$itinerario, {
    if (!is.na(valores_validos_centro)) {
      seleccion_operativa <<- "itinerario"
      lista_itinerario <- input$itinerario
      x1 <- strsplit(lista_itinerario, " - ",fixed = T)
      x2 <- do.call(rbind, x1)
      new_dim <- dim(x2)
      x3 <- matrix(x2, nrow = new_dim[1])
      valores_validos_itinerario <<- valores_validos_centro %>%
        filter(valores_validos_centro$NombreOficina %in% x3[,1] &
                 valores_validos_centro$Itinerario %in% x3[,2])
      # valores_validos_itinerario <<- valores_validos_centro %>% 
      #   filter(valores_validos_centro$Itinerario %in% lista_itinerario)
      valores_validos <<- valores_validos_itinerario
      #    selected = valor.seleccionado)
    }
  }, ignoreInit = TRUE)
  
  #Jerarquía geográfica
  # departamento
  observeEvent(input$departamento, {
    seleccion_geografia <<- "departamento"
    lista_seleccion <- input$departamento
    valores_validos_Geografia_departamento <<- valores_Geografia %>% 
      filter(valores_Geografia$NombreDepartamentoGeografia %in% lista_seleccion)
    valores_validos_Geografia <<- valores_validos_Geografia_departamento
    
    x <-  c(unique(valores_validos_Geografia_departamento[c("NombreMunicipioGeografia")]))
    updatePickerInput(session,
                      "municipio",
                      choices = x[order(x)])
  }, ignoreInit = TRUE)
  
  # municipio
  observeEvent(input$municipio, {
    if (!is.na(valores_validos_Geografia_departamento)) {
      seleccion_geografia <<- "municipio"
      lista_seleccion <- input$municipio
      valores_validos_Geografia_municipio <<- valores_validos_Geografia_departamento %>% 
        filter(valores_validos_Geografia_departamento$NombreMunicipioGeografia %in% lista_seleccion)
      valores_validos_Geografia <<- valores_validos_Geografia_municipio
      
      x <-  c(unique(valores_validos_Geografia_municipio[c("NombreLocalidadZonaGeografia")]))
      updatePickerInput(session,
                        "localidad",
                        choices = x[order(x)])
    }
  }, ignoreInit = TRUE)
  
  # localidad
  observeEvent(input$localidad, {
    if (!is.na(valores_validos_Geografia_municipio)) {
      seleccion_geografia <<- "localidad"
      
      lista_seleccion <- input$localidad
      valores_validos_Geografia_localidad <<- valores_validos_Geografia_municipio %>% 
        filter(valores_validos_Geografia_municipio$NombreLocalidadZonaGeografia %in% lista_seleccion)
      valores_validos_Geografia <<- valores_validos_Geografia_localidad
    }
  }, ignoreInit = TRUE)
  
  # circuito
  observeEvent(input$circuitos, {
    seleccion_circuito <<- 'circuitos'
    lista_seleccion <- input$circuitos
    valores_validos_circuitos <<- valores_Circuitos %>%
      filter(valores_Circuitos$CodigoCircuito %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  # Iniciativa
  observeEvent(input$iniciativa, {
    seleccion_iniciativa <<- 'iniciativa'
    lista_seleccion <- input$iniciativa
    valores_validos_iniciativa <<- valores_Iniciativa %>%
      filter(valores_Iniciativa$NombreCampaña %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  #Jerarquía CNAE
  # CNAE
  observeEvent(input$cnae, {
    seleccion_CNAE <<- "cnae"
    lista_seleccion <- input$cnae
    valores_validos_cnae_division <<- valores_CNAE %>% 
      filter(valores_CNAE$Grupo %in% lista_seleccion)
    #valores_validos_CNAE <<- valores_validos_cnae_division
    
  }, ignoreInit = TRUE)
  
  # CNAE grupo
  observeEvent(input$cnaegrupo, {
    seleccion_grupo <<- "cnaegrupo"
    lista_seleccion <- input$cnaegrupo
    valores_validos_cnae_seccion <<- valores_CNAE %>% 
      filter(valores_CNAE$Seccion %in% lista_seleccion)
    valores_validos_CNAEgrupo <<- valores_validos_cnae_seccion
    
  }, ignoreInit = TRUE)
  
  # pimt
  observeEvent(input$pimt, {
    seleccion_PIMT<<- "pimt"
    lista_seleccion <- input$pimt
    valores_validos_PIMT <<- valores_PIMT %>% 
      filter(valores_PIMT$NombreProyecto %in% lista_seleccion) 
  }, ignoreInit = TRUE)
  
  # normalizacion  -- no está funcionando todavía (datos en bd, lógica asociada)
  observeEvent(input$ynormalizacion, {
    #seleccion_ynormalizacion<<- "ynormalizacion"
    lista_seleccion <- input$ynormalizacion
    valores_validos_normalizacion <<- lista_seleccion 
  }, ignoreInit = TRUE)
  
  # estado
  observeEvent(input$estado, {
    seleccion_estado<<- "estado"
    lista_seleccion <- input$estado
    valores_validos_estado <<- valores_Estados %>%
      filter(valores_Estados$NombreEstado %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  # tension
  observeEvent(input$tension, {
    seleccion_tension<<- "tension"
    lista_seleccion <- input$tension
    valores_validos_tension <<- valores_Tension %>%
      filter(valores_Tension$NombreTension %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  # tarifa
  observeEvent(input$tarifa, {
    seleccion_tarifa<<- "tarifa"
    lista_seleccion <- input$tarifa
    valores_validos_tarifa <<- valores_Tarifa %>%
      filter(valores_Tarifa$NombreTarifa %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  
  # mercado 
  observeEvent(input$mercado, {
    seleccion_mercado<<- "mercado"
    lista_seleccion <- input$mercado
    valores_validos_mercado <<- valores_Mercado  %>%
      filter(valores_Mercado$NombreMercado %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  
# Hacer consulta basada en valores de filtros  ---------------------------
  observeEvent(input$TraerDatos, {

    noHayValores <- FALSE
    condiciones_coefvar <- input$coefVariacion
    meses_busqueda <- input$mesesRevisar
     fecha_minimo <- today() %m-% months(meses_busqueda)
     fecha_minimo <- paste0(substring(fecha_minimo,1,4),substring(fecha_minimo,6,7),"01")
     condiciones_Periodo  <- substring(fecha_minimo,1,6)
    condiciones_consulta <- " "
    condiciones_Zona <- " "
    condiciones_Geografia <- " "
    condiciones_circuito <- " "
    

    # Construir condiciones de consulta:
    if (seleccion_operativa != "no") {
      if (nrow(valores_validos) == 0) {
        noHayValores <- TRUE
      } else {
        #f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos[c("LlaveZona")]), collapse=",")),1,stop =1000000L)
        valores_validos <- consulta_zona(seleccion_operativa, valores_ZonaOperativa,input)
        f1 <- t(unique(valores_validos[c("LlaveZona")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        #f1 <- paste0(gsub(":",",",unique(valores_validos[c("LlaveZona")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        f1 <- str_replace(f1, "[)]", "")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND Llavezona IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    if (seleccion_geografia != "no") {
      if (nrow(valores_validos_Geografia) == 0) {
        noHayValores <- TRUE
      } else {
        #f1 <- substr(gsub("[\r751:\n]", "",paste0(unique(valores_validos_Geografia[c("LlaveGeografia")]), collapse=",")),1,stop =1000000L)
        valores_validos_Geografia <- consulta_geografia(seleccion_geografia, valores_Geografia,input)
        f1 <- t(unique(valores_validos_Geografia[c("LlaveGeografia")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        #f1 <- paste0(gsub(":",",",unique(valores_validos_Geografia[c("LlaveGeografia")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        f1 <- str_replace(f1, "[)]", "")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND LlaveGeografia IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    if (seleccion_circuito != "no") {
      if (nrow(valores_validos_circuitos) == 0) {
        noHayValores <- TRUE
      } else {
        f1 <- t(unique(valores_validos_circuitos[c("LlaveCircuito")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        #f1 <- paste0(gsub(":",",",unique(valores_validos_circuitos[c("LlaveCircuito")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        f1 <- str_replace(f1, "[)]", "")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND LlaveCircuito IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    if (seleccion_iniciativa  != 'no') {
      if (nrow(valores_validos_iniciativa) == 0 ) {
        noHayValores <- TRUE
      } else {
        # xxx no funciona sin traducir iniciativa a llaveiniciativa, o similar
        # f1 <- t(unique(valores_validos_iniciativa[c("LlaveCampaña")]))
        # f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        # #f1 <- paste0(gsub(":",",",unique(valores_validos_iniciativa[c("LlaveCampaña")])), collapse=",")
        # f1 <- str_replace(f1, "[(]", "")
        # f1 <- str_replace(f1, "[c]", "")
        # f1 <- str_replace(f1, "[)]", "")
        # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
        #                                                  " AND LlaveCampaña IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        
        #        f1 <- paste0(unique(valores_Iniciativa[c("NombreCampaña")]), collapse=",")
      }
    }
    
    c1 <- ''
    c2 <- ''
    if (seleccion_CNAE != 'no') {
      if (nrow(valores_validos_cnae_division) == 0) {
        noHayValores <- TRUE
      } else {
        f1 <- t(unique(valores_validos_cnae_division[c("LlaveActividadEconomica")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        #f1 <- paste0(gsub(":",",",unique(valores_validos_cnae_division[c("LlaveActividadEconomica")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        c1 <- str_replace(f1, "[)]", "")
        
        # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
        #                                                  " AND LlaveActividadEconomica IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    if (seleccion_grupo != 'no') {
      
      if (nrow(valores_validos_CNAEgrupo) == 0) {
        noHayValores <- TRUE
      } else {
        f1 <- t(unique(valores_validos_CNAEgrupo[c("LlaveActividadEconomica")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        f1 <- paste0(gsub(":",",",unique(valores_validos_CNAEgrupo[c("LlaveActividadEconomica")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        c2 <- str_replace(f1, "[)]", "")
        # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
        #                                                  " AND LlaveActividadEconomica IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }   
    
    # Unificar seleccion_CNAE y seleccion_grupo
    if (seleccion_CNAE != 'no' && seleccion_grupo != 'no') {
      condiciones_CNAE <- gsub("[\r\n]", "",substr(c1,1,stop =1000000L),  
                               ",",substr(c2,1,stop =1000000L) )
      condiciones_consulta <- paste0(condiciones_consulta,
                                     " AND LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
    } else if (seleccion_CNAE != 'no' ) {
      condiciones_CNAE <- gsub("[\r\n]", "",substr(c1,1,stop =1000000L) )
      condiciones_consulta <- paste0(condiciones_consulta,
                                     " AND LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
      
      
    } else if (seleccion_grupo != 'no') {
      condiciones_CNAE<- gsub("[\r\n]", "",substr(c2,1,stop =1000000L) )
      condiciones_consulta <- paste0(condiciones_consulta,
                                     " AND LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
    }
    
    if (seleccion_estado != 'no') {
      if (is.na(valores_validos_estado) ) {
        lista_seleccion <- input$estado
        valores_validos_estado <<- valores_Estados %>%
          filter(valores_Estados$NombreEstado %in% lista_seleccion)
      } 
      if (nrow(valores_validos_estado) == 0) {
        noHayValores <- TRUE
      } else {
        # f1 <- t(unique(valores_validos_estado[c("LlaveEstado")]))
        # f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        # #f1 <- paste0(gsub(":",",",unique(valores_validos_tension[c("Llavetension")])), collapse=",")
        # f1 <- str_replace(f1, "[(]", "")
        # f1 <- str_replace(f1, "[c]", "")
        # f1 <- str_replace(f1, "[)]", "")
        # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
        #                                                  " AND LlaveEstrato IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    if (seleccion_tension != 'no') {
      if (nrow(valores_validos_tension) == 0) {
        noHayValores <- TRUE
      } else {
        f1 <- t(unique(valores_validos_tension[c("Llavetension")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        #f1 <- paste0(gsub(":",",",unique(valores_validos_tension[c("Llavetension")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        f1 <- str_replace(f1, "[)]", "")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND LlaveTension IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    if (seleccion_tarifa != 'no') {
      if (is.na(valores_validos_tarifa) ) {
        lista_seleccion <- input$tarifa
        valores_validos_tarifa <<- valores_Tarifa %>%
          filter(valores_Tarifa$NombreTarifa %in% lista_seleccion)
      } 
      if ( nrow(valores_validos_tarifa) == 0) {
        noHayValores <- TRUE
      } else {
        # f1 <- t(unique(valores_validos_tarifa[c("LlaveTarifa")]))
        # f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        # #f1 <- paste0(gsub(":",",",unique(valores_validos_tarifa[c("LlaveTarifa")])), collapse=",")
        # f1 <- str_replace(f1, "[(]", "")
        # f1 <- str_replace(f1, "[c]", "")
        # f1 <- str_replace(f1, "[)]", "")
        # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
        #                                                  " AND LlaveTarifa IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    if (seleccion_mercado != 'no') {
      if (is.na(valores_validos_mercado) ) {
        lista_seleccion <- input$mercado
        valores_validos_mercado <<- valores_Mercado  %>%
          filter(valores_Mercado$NombreMercado %in% lista_seleccion)
      } 
      
      if (nrow(valores_validos_mercado) == 0) {
        noHayValores <- TRUE
      } else {
        f1 <- t(unique(valores_validos_mercado[c("LlaveMercado")]))
        # f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        # #f1 <- paste0(gsub(":",",",unique(valores_validos_mercado[c("LlaveMercado")])), collapse=",")
        # f1 <- str_replace(f1, "[(]", "")
        # f1 <- str_replace(f1, "[c]", "")
        # f1 <- str_replace(f1, "[)]", "")
        # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
        #                                                  " AND LlaveTipoObjeto IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    if (seleccion_PIMT != 'no') {
      if (nrow(valores_validos_PIMT) == 0) {
        noHayValores <- TRUE
      } else {
        f1 <- t(unique(valores_validos_PIMT[c("LlavePIMT")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        #f1 <- paste0(gsub(":",",",unique(valores_validos_PIMT[c("LlavePIMT")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        f1 <- str_replace(f1, "[)]", "")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND LlavePIMT IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
    
    if (seleccion_ynormalizacion != 'no') {
      if (nrow(valores_validos_ynormalizacion) == 0) {
        noHayValores <- TRUE
      } else {
        f1 <- t(unique(valores_validos_ynormalizacion[c("Llaveynormalizacion")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        f1 <- paste0(gsub(":",",",unique(valores_validos_ynormalizacion[c("Llaveynormalizacion")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        f1 <- str_replace(f1, "[)]", "")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND Llaveynormalizacion IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    }
  
    # condiciones_consulta = " "
    # if (nchar(condiciones_Zona) > 17) {
    #   condiciones_consulta <- paste0(condiciones_consulta, " ", condiciones_Zona)
    # }
    # if (nchar(condiciones_Geografia) > 22) {
    #   if (nchar(condiciones_consulta) > 10) {
    #     condiciones_consulta <- paste0(condiciones_consulta, " AND ")
    #   }
    #   condiciones_consulta <- paste0(condiciones_consulta, " ", condiciones_Geografia)
    # }
    # if  (nchar(condiciones_circuito) > 22 ) {
    #   if (nchar(condiciones_consulta) > 10) {
    #     condiciones_consulta <- paste0(condiciones_consulta, " AND ")
    #   }
    #   condiciones_consulta <- paste0(condiciones_consulta, " ", condiciones_circuito)
    # }
    
    if (nchar(condiciones_consulta) > 1) {
      condiciones_consulta <- substr(condiciones_consulta, 6, nchar(condiciones_consulta))
    }

    
    # traer valores de consumos planos
    if (noHayValores) {
      showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        
        "La consulta no genera resultados",
        footer = list(tags$div(id="modal1",modalButton("Cancelar", icon = icon("fas fa-table")))
        ),
        easyClose =TRUE
      )
      )
    }  else {
      disable("ReiniciarControles")  
      disable("TraerDatos")
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      parametros<- data.frame(c(condiciones_coefvar), c(as.numeric(condiciones_Periodo)), condiciones_consulta)
    
      cad.sql<-"EXEC [dbo].[Dataset_ConsumosPlanos_shiny]"
      cad.sql<-paste (cad.sql," @COEFVARIACION = ?, @PERIODO = ?, @CONDICION = ? ")
      datos.consulta <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
      
      odbcClose(conexion)

      
      if (nrow(datos.consulta ) > 0) {
        tabla.datos.valida <<- FALSE
        datos.consulta <- as.data.frame(datos.consulta,stringsAsFactors=FALSE)
        datos.consulta$PromedioActiva6CN<-as.numeric(as.character(datos.consulta$PromedioActiva6CN))  # Convierte a numérico
        datos.consulta$PromedioActiva6CN[is.na(datos.consulta$PromedioActiva6CN)]=0                  # Ajuste de valores nulos
        
        
        shinyjs::enable("Guardar")                                   # Habilita el botón para guardar
        shinyjs::enable("Descargar")
        # Armar tabla de datos para despliegue
        datos.consulta$texto <- paste0("NIS: ",                                           # Campo de texto a presentar en tooltip de los puntos
                                       datos.consulta$CodigoPuntoConsumo,
                                       " \n ",                                                 # Se incluye salto de línea
                                       "Cliente: ",
                                       datos.consulta$NombreCliente,
                                       " \n ",
                                       "Dir: ",
                                       datos.consulta$DireccionPuntoConsumo #,
                                       # " \n " ,
                                       # "Ultima inspeccion: ",
                                       # datos.consulta$LlaveFechaEjecucion
        )
        
        #datos.imagen$image <- lapply(datos.imagen$image, aCode64)
        
        consumos.numericos <-sapply(datos.consulta$Consumo12,function(x) sapply(strsplit(x,','), as.numeric))
        # for (i in 1:nrow(datos.consulta)) {
        #   datos.consulta$Consumo12[i] <- texto.popup(unlist(consumos.numericos[i]))
        # }
        
        datos.consulta$Texto1 <- paste0(
          "<p></p>",
          "<table border= '0' style= 'height: 120px; width: 100%; border-collapse: collapse;'>",
          "<tbody>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px; background-color: #f0f2f2;'><strong><span style='color: #0070ba;'>Cliente:&nbsp;</span></strong></td>",
          
          "<td style='width: 65%; height: 20px; background-color: #f0f2f2; text-align: right;'><strong><span style='color: #0070ba;'>",
          "<a href='",paste(str.http,datos.consulta$CodigoPuntoConsumo, sep=""),
          "' target='_blank' rel='noopener'>",datos.consulta$CodigoPuntoConsumo,"</a>",
          "</span></strong></td>",
          "</tr>",
          
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px; vertical-align: top;'>Nombre:</td>",
          "<td style='width: 65%; height: 20px;'>",datos.consulta$NombreCliente,"</td>",
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px; vertical-align: top;'>Actividad:</td>",
          "<td style='width: 65%; height: 20px;'>",datos.consulta$Seccion,"</td>",
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px;'>Cons. Prom.:</td>",
          "<td style='width: 65%; height: 20px; text-align: right;'>",round(as.numeric(datos.consulta$PromedioActiva6CN), digits = 2),
          " [kWh]</td>",
          "</tr>",
          # "<tr style='height: 20px;'>",
          # "<td style='width: 35%; height: 20px;'>Transformador:</td>",
          # "<td style='width: 65%; height: 20px; text-align: right;'>",datos.consulta$Transformador,"</td>",
          # "</tr>",
          # "<tr style='height: 20px;'>",
          # "<td style='width: 35%; height: 20px;'>Ultima inspección:</td>",
          # "<td style='width: 65%; height: 20px; text-align: right;'>",datos.consulta$LlaveFechaEjecucion,"</td>",
          # "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px;'>Perfil de consumo:</td>",
          "<td style='width: 65%; text-align: right; height: 20px;'>",
          "<svg xmlns='http://www.w3.org/2000/svg'",
          "xmlns:xlink='http://www.w3.org/1999/xlink' width='100' height='50' viewBox='0 0 100 50'>",
          datos.consulta$Consumo12,
          "</svg>",
          "</td>",
          "</tr>",
          "</tbody>",
          "</table>"             
        )
        
        
        
        tabla.datos<- datos.consulta  %>% select(CodigoPuntoConsumo, NombreCliente
                                                 ,DireccionPuntoConsumo, Seccion
                                                 , coefvar   ,PromedioActiva6CN
                                                 , NombreZona, NombreRegion, NombreOficina, Itinerario
                                                 ,NombreDepartamentoGeografia, NombreMunicipioGeografia, NombreLocalidadZonaGeografia
                                                 ,Nombre_corto_SMT , CodigoCircuito
                                                 ,  texto)
        tabla.datos$coefvar <- round(as.numeric(datos.consulta$coefvar), digits = 2)
        
        datos.consulta <<- datos.consulta
        #datos.imagen <<- datos.imagen
        
        # for (i in 1:nrow(tabla.datos)){      # Crea los tags para el hipervínculo de num. de cliente
        #   tabla.datos$CodigoPuntoConsumo[i] <- tagList(as.character(a(as.character(tabla.datos$CodigoPuntoConsumo[i]), 
        #                                                               href = paste(str.http,tabla.datos$CodigoPuntoConsumo[i], sep=""))))
        # }
      
        tabla.datos <- cbind("°" = TRUE, tabla.datos)
        tabla.datos <<- tabla.datos
        
        
        # Cargar datos gráfico de puntos
        updateMaterialSwitch(session, 'selec.graf', value = FALSE)
        output$plot <- renderPlotly({
          p <-
            ggplot(tabla.datos,
                   mapping = aes(x = coefvar, y = PromedioActiva6CN, text = texto)) +
            geom_point(color = "#0070ba", size = 1) + theme_bw() +
            ylab("Consumo promedio 6 meses anteriores [kWh]") +
            xlab("Indice de variación")
          
          # Manejo de selección en gráfica
          obj <- data.grafica()$sel
          #      if (exists("obj")) {
          if(nrow(obj)!=0 ) {
            p <- p + geom_point(data=obj,color="orange")
          }
          #      }
          ggplotly(p, source = "master")
        })
        
        showTab("Gráfica", "Datos", select = FALSE,  session = getDefaultReactiveDomain())
        showTab("Gráfica", "Mapa", select = FALSE,  session = getDefaultReactiveDomain())
        output$datos <- renderRHandsontable({
          tabla.despliegue(tabla.datos, data.grafica()$sel)
        })
        # output$map <- renderGoogle_map({
        #   mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta, FALSE, tabla.datos.valida, input) #, datos.imagen, input)
        # })
        
      } else{
        disable("Guardar")                                  # Deshabilita el botón para guardar
        disable("Descargar")
        showModal(modalDialog(
          title = "La consulta no encuentra datos que cumplan.",
          footer = tags$div(id="modal1",modalButton("Cerrar")),
          easyClose = TRUE
        ))
      }
      shinyjs::enable("ReiniciarControles")  
      shinyjs::enable("TraerDatos")
    }

  }, ignoreInit = TRUE)
  
  # Cargar datos a tabla
  output$datos <-
    renderRHandsontable({
      if (exists("tabla.datos")){
      obj <- data.grafica()$sel
      if(nrow(obj) >0) {
        p <- p <- tryCatch(tabla.datos[(selected()$pointNumber+1),,drop=FALSE] , error=function(e){NULL})
      } else if (exists("tabla.datos")) {
        p <- tabla.datos
      }
        if (nrow(p ) > 0) {
      # Actualiza rhandsontable
          tabla.despliegue(p, data.grafica()$sel)

        }
      }
    })
  
  # Puntos seleccionados
  selected<-reactive({

    event_data("plotly_selected", source = "master")
  })
  
  data.grafica<-reactive({
 
    if (exists("tabla.datos")){
      tabla.datos.valida <<- FALSE
      tmp<-tabla.datos
      sel<-tryCatch(tabla.datos[(selected()$pointNumber+1),,drop=FALSE] , error=function(e){NULL})
      if (nrow(sel) > 0 & tipo.grafica == 'B') {
        secuencia.sel <- selected()$pointNumber + 1
        valores.planos <- sort(unique(tabla.datos$coefvar))[secuencia.sel]
        sel <-  tabla.datos %>% filter(coefvar %in% valores.planos)
        list(data=tmp,sel=sel)
      } else {
        click('MostrarTabla')
        list(data=tmp,sel=sel)
      }
      
    }
    
   # list(data=tmp,sel=sel)
    
  })
 
  # Presentación del mapa --------------------------------------------------- 
  output$map <- renderGoogle_map({
    if (exists("tabla.datos")) {
      mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta, FALSE, tabla.datos.valida, input) #, datos.imagen, input)
    }
  })
  
 
  
  # Reinicial controles ----------------------------------------------
  observeEvent(input$ReiniciarControles, {
    
    seleccion_operativa <<- 'no'
    
    # Datos iniciales para  selectores de jerarquía
    x <-  c(unique(valores_ZonaOperativa[c("NombreZona")]))
    zonaCom <- x[order(x)]
    valores_validos_zona <<- NA
    valores_validos_region <<- NA
    valores_validos_centro <<- NA
    
    isolate(
      
      updatePickerInput(session,
                        "zona_comercial", choices = sort(zonaCom[[1]]),
                        selected = '',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(zonaCom[[1]])))))
    isolate(
      updatePickerInput(session,
                        "region", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "centro", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "itinerario", choices = c('')))
    
    
    
    seleccion_geografia <<- 'no'
    x <-  c(unique(valores_Geografia[c("NombreDepartamentoGeografia")]))
    departamentoGeo <- x
    valores_validos_Geografia_departamento  <<- NA
    valores_validos_Geografia_municipio <<- NA
    isolate(
      updatePickerInput(session,
                        "departamento", choices = sort(departamentoGeo[[1]]),
                        selected = '',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(departamentoGeo[[1]])))))
    isolate(
      updatePickerInput(session,
                        "municipio", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "localidad", choices = c('')))
    isolate(
      updatePickerInput(session,
                        "zona_geo", choices = c('')))
    
    
    
    seleccion_circuito <<- 'no'
    x <-  c(unique(valores_Circuitos[c("CodigoCircuito")]))
    codigosCircuito <- x
    isolate(
      updatePickerInput(session,
                        "circuitos", choices = sort(codigosCircuito[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosCircuito[[1]])))))
    
    seleccion_iniciativa <<- 'no'
    codigosIniciativa <-  c(unique(valores_Iniciativa[c("Iniciativa")]))
    isolate(
      updatePickerInput(session,
                        "iniciativa", choices = sort(codigosIniciativa[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosIniciativa[[1]])))))
    
    
    seleccion_CNAE <<- 'no'
    codigosCNAE <- c(unique(valores_CNAE[c("Grupo")]))
    isolate(
      updatePickerInput(session,
                        "cnae", choices = sort(codigosCNAE[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosCNAE[[1]])))))
    
    seleccion_grupo <<- "no"
    
    codigosCNAE_grupos <- c(unique(valores_CNAE[c("Seccion")]))
    isolate(
      updatePickerInput(session,
                        "cnaegrupo", choices = sort(codigosCNAE_grupos[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosCNAE_grupos[[1]])))))
    
    seleccion_PIMT <<- 'no'
    codigosPIMT <-  c(unique(valores_PIMT[c("NombreProyecto")]))
    isolate(
      updatePickerInput(session,
                        "pimt", choices = sort(codigosPIMT[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosPIMT[[1]])))))
    
    seleccion_yyyyNormalizacion <<- 'no'
    isolate(
      updatePickerInput(session,
                        "ynormalizacion", choices = sort(codigosyyyyNormalizacion[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosyyyyNormalizacion[[1]])))))
    
    
    seleccion_tarifa <<- 'tarifa'
    isolate(
      updatePickerInput(session,
                        "tarifa", choices = sort(codigosTarifa[[1]]),
                        selected = c("BT Simple DC", "BT Simple DR"),
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosTarifa[[1]])))))
    
    seleccion_Estado <<- 'estado'
    isolate(
      updatePickerInput(session,
                        "estado", choices = sort(codigosEstado[[1]]),
                        selected = c("Situacion correcta"),
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosEstado[[1]])))))
    
    seleccion_tension <<- 'no'
    isolate(
      updatePickerInput(session,
                        "tension", choices = sort(codigosTension[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosTension[[1]])))))
    
    seleccion_mercado <<- 'mercado'
    isolate(
      updatePickerInput(session,
                        "mercado" , choices = sort(codigosMercado[[1]]),
                        selected = 'Gestion normal',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosMercado[[1]])))))
    
  }, ignoreInit = TRUE)
  
  # Cambiar tipo de gráfica  ----------------------------------------
  observeEvent(input$selec.graf,{

    valorSwitch <- input$selec.graf
    if (valorSwitch == TRUE) {
      tipo.grafica <<- 'B'
      output$plot <- renderPlotly({
        p <- ggplot(tabla.datos, mapping = aes(x = coefvar)) +
          geom_bar(color ="#0070ba",fill= "#0070ba",size =1) + theme_bw()+
          ylab("Conteo") +
          xlab("ïndice de variación")
        # Manejo de selección en gráfica
        obj <- data.grafica()$sel
        if(nrow(obj)!=0) {
          p <- p + geom_bar(data=obj,color="orange",fill="orange")
        }
        ggplotly(p,source="master")
      })
    } else {
      tipo.grafica <<- 'P'
      output$plot <- renderPlotly({
        p <-
          ggplot(tabla.datos,
                 mapping = aes(x = coefvar, y = PromedioActiva6CN, text = texto)) +
          geom_point(color = "#0070ba", size = 1) + theme_bw() +
          ylab("Consumo promedio 6 meses anteriores [kWh]") +
          xlab("Indice de variación")
        
        # Manejo de selección en gráfica
        obj <- data.grafica()$sel
        if(nrow(obj)!=0) {
          p <- p + geom_point(data=obj,color="orange")
        }
        ggplotly(p, source = "master")
      })
    }
    }, ignoreInit = TRUE)
  
  # Seleccionar o deselecionar todos ----------------------------------------
  
  observeEvent(input$selec.tod,{
    tabla.temp <<- hot_to_r(input$datos)    # Tabla temporal para alimentar rhandsontable
    
    if(input$selec.tod == "Todos"){
      tabla.temp[,1] <- TRUE             # Cambia primera columna a seleccionado
    }
    
    if(input$selec.tod == "Ninguno"){
      tabla.temp[,1] <- FALSE               # Cambia primera columna a deseleccionado
    }
    output$datos <- renderRHandsontable({   # Actualiza rhandsontable
    tabla.despliegue(tabla.temp, data.grafica()$sel)
    })
    output$map <- renderGoogle_map({
      mapa.despliegue(tabla.temp, data.grafica()$sel, datos.consulta, TRUE,tabla.datos.valida, input) #, datos.imagen, input)
    })
    
  }, ignoreInit = TRUE)
  
  # Descargar excel -----------------------------------------------------------
  # Ver https://www.r-bloggers.com/2019/07/excel-report-generation-with-shiny/
  output$Descargar <- downloadHandler(
    
    filename = function() { 
      #paste0("Planos", Sys.Date(), ".csv")
      paste0("Planos", Sys.Date(), ".xlsx")
    },
    content = function(file) {

      ordenes <- transf.rhand(input$datos)                      # Transforma los datos tomados del objeto rhandsontable.
      ordenes <- subset(ordenes, ordenes[,1] == TRUE)[,-1]      # Filtra aquellos con checkbox activo y omite primera columna
      wbk <- createWorkbook()
      addWorksheet( wb = wbk,  sheetName = "Data" )
      setColWidths(wbk,1,cols = 1:14,
                   widths = c(4,15,15,15,4,4,10,10,10,4,10,10,10,15))
      addStyle(wbk,sheet = 1, style = createStyle( fontSize = 12, textDecoration = "bold" ), rows = 1:1, cols = 1:ncol(ordenes) )
      
      writeData(wbk,sheet = 1,ordenes,startRow = 1,startCol = 1 )
      saveWorkbook(wbk, file)
      #write.table(ordenes,file,
      
      #write.table(ordenes,file,sep=separador.csv, fileEncoding = "latin1")
    },
    contentType = "csv"
  )
  
  observeEvent(input$MostrarTabla, {

    if (exists("tabla.datos")) {
      if (nrow(data.grafica()$sel) == 0) {
        tabla.temp <- tabla.datos
      }
      if (exists("tabla.temp")){
        tabla.temp[,1] <- TRUE
        output$datos <- renderRHandsontable({   # Actualiza rhandsontable
          tabla.despliegue(tabla.temp, data.grafica()$sel)
        })
      } 
    }
  }, ignoreInit = TRUE)
  
  
  observeEvent(input$MostrarMapa, {
    if ( exists("tabla.datos")) {
      mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta,TRUE,tabla.datos.valida, input) #, datos.imagen, input)
    }
    #  mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta,TRUE,tabla.datos.valida, input)
    # output$map <- renderGoogle_map({
    #   mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta)
    # })
  }, ignoreInit = TRUE)
  
  # Generar órdenes de inspección en BD ---------------------------------------------------
  observeEvent(input$Guardar,{
    
    showModal(modalDialog(
      
      title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("Generar órdenes"),style="color: #0070ba"),style="text-align: center;"),
      
      "Se guardarán los clientes seleccionados para ser incluidos \n en la lista de órdenes de inspección",
      hr(),
      
      selectInput("variable", 
                  "Seleccione campaña:",
                  nom.camp),
      textAreaInput("observ.orden", label = "Observaciones:",
                    height = "100px", rows = 4, 
                    placeholder = "Comentarios para acompañar la órden", 
                    resize = "vertical"),

      footer = fluidRow(column(width=2, offset=7,tags$div(id="modal1", 
                                                          modalButton("Cancelar", icon = icon("fas fa-table")))),
                        column(width=2,actionButton("Guardar2", "Guardar",icon = icon("fas fa-table"),
                                                    style="color: #fff; background-color: #0070ba; border-color: #0070ba"))
      ),
      easyClose =TRUE
    )
    )
  }, ignoreInit = TRUE)
  
  
  observeEvent(input$Guardar2, {                                          # Código para botón diálogo modal
    
    #  Grabar órdenes en BD
    
    ordenes <- transf.rhand(input$datos)                      # Transforma los datos tomados del objeto rhandsontable.
    ordenes <- subset(ordenes, ordenes[,1] == TRUE)[,-1]      # Filtra aquellos con checkbox activo y omite primera columna
    
    if (nrow(ordenes) > 0) {
      ordenes<-cbind(ordenes[,1],                                         # Punto de consumo: 'CodigoPuntoConsumo'
                     rep(as.character(input$variable), nrow(ordenes)),    # Línea para tipo de campaña seleccionada: 'NombreCampana'
                     rep("Sequimiento cortados", nrow(ordenes)),          # Reporte origen de las órdenes: 'ReporteOrigen'
                     rep(as.character(Sys.time()), nrow(ordenes)),        # Fecha y hora de generación de las órdenes: 'FechaGeneracion'
                     rep(analista, nrow(ordenes)),                        # Usuario que genera las órdenes: 'AnalistaSolicitante'
                     rep(0.5, nrow(ordenes)),                             # 'Probabilidad' de detección. ** Se debe incluir probabilidad de la campaña, por ahora es 0.5
                     ordenes[,9],                                         # 'RecuperacionMedia': Se asume promedio anterior
                     rep(as.character(input$observ.orden), nrow(ordenes)) #  Observación que acompaña la orden 'ObservacionOrden'
      )
      
      ordenes<-data.frame(ordenes)
      ordenes[,7]<-as.numeric(as.character(ordenes[,7]))                  # Se convierte a texto el dato tomado de la tabla
      
      #conexion2 <- odbcDriverConnect ("driver={SQL Server};server=WMENERTOLIMA\\SQL2017;database=DWSRBI_ENERGUATE;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" )
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      cad.sql<-" INSERT INTO [DWSRBI_ENERGUATE].[Hecho].[OrdenInspeccion]([CodigoPuntoConsumo],[NombreCampana],[ReporteOrigen],[FechaGeneracion],[AnalistaSolicitante],[Probabilidad],[RecuperacionMedia],[ObservacionOrden])"
      cad.sql<-paste (cad.sql,"VALUES (?,?,?,?,?,?,?,?)")
      
      sqlExecute(channel = conexion,
                 cad.sql,
                 data = ordenes)              # En 'ordenes' se incluyen las órdenes a ser incluidas en la tabla 'OrdenInspeccion'
      odbcClose(conexion)
      
      ord.gen <<- ord.gen + nrow(ordenes)     # Se actualiza el contador de órdenes generadas en la sesión. Variable global
      
      output$MensajeOrdenes <- renderMenu({   # Actualiza mensaje en la barra de menú para órdenes generadas
        
        dropdownMenu(type = "notifications",  # Mensaje en barra de encabezado para indicar generación de órdenes
                     headerText = "Tiene una notificación",
                     #icon =icon("fas fa-comments"),
                     notificationItem(
                       text = paste(ord.gen, "órdenes generadas en esta sesión")#,
                       #icon("fas fa-gavel")
                     )
        )
      })
    }
    
    removeModal()
  })
  

})



# Ejecutar aplicación -----------------------------------------------------


shinyApp(ui = ui, server = server)