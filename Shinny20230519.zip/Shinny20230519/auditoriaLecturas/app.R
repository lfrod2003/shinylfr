# =============================================================================
#                         Modelo de auditoria Lecturas
# =============================================================================

# Carga de librerías ------------------------------------------------------
options(useFancyQuotes = FALSE)
library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
library(rhandsontable)  # Visualización tablas
library(htmlwidgets)
library(scales)
library(lubridate)
library(shinydashboard)
library(DT)
library(ggplot2)
library(plotly)         # Graficas dinámicas plotly
library(RCurl)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
#library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(stringr)
require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
#library(rintrojs)       # Presentación de ayuda en pantalla
library(openxlsx)




source("helpers.R")
source("../_shared/_filtros.R")
#reactlog_enable()

# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}

# Retornar tabla para despliegue ---------------------------------------------
tabla.despliegue <- function(tabla.temp, obj) {
  
  if(is.null(tabla.temp)){
  }else{
    rhandsontable(tabla.temp[,3:8],
                  rowHeaders = TRUE,
                  colHeaders = c(
                    'Nombre Lecturista',
                    'Código Lecturista',
                    'Periodo',
                    'Conteo sospechoso',
                    'Total lecturas',
                    '% sospechoso'
                  ),
                  height =380,
                  search = FALSE,
                  readOnly = TRUE
                  ,selectCallback = TRUE)%>% 
      #hot_col(1, halign = "htCenter", readOnly = FALSE) %>% 
      hot_col(6,format="#.00%", halign="htRight" ) %>% 
      hot_heatmap(6, color_scale =c("#ffffff", "#ffffff")) %>%  # Habilitar escala de color
      hot_cols(columnSorting = TRUE)  %>%   
      hot_context_menu(allowRowEdit = FALSE, allowColEdit = FALSE) %>%    # Bloquea opciones de menú contextual
      hot_table(highlightCol = TRUE, highlightRow = TRUE                 # Resalta fila y columna seleccionada
      )
  }
  
 
}

tablaLector.despliegue <- function(tabla.temp) {
  
  tablaexportar <<- tabla.temp
  
  rhandsontable(tabla.temp,
                rowHeaders = TRUE,
                height =380,
                search = FALSE,
                readOnly = TRUE
                ,selectCallback = TRUE)%>% 
    #hot_col(5,format="dd-MM-yyyy" ) %>% 
    hot_cols(columnSorting = TRUE)  %>%   
    hot_context_menu(allowRowEdit = FALSE, allowColEdit = FALSE) %>%    # Bloquea opciones de menú contextual
    hot_table(highlightCol = TRUE, highlightRow = TRUE                 # Resalta fila y columna seleccionada
    )
}

# Retornar mapa para despliegue --------------------------------------------
mapa.despliegue <- function(tabla.temp, obj, datos.consulta, banderaRefresco,tabla.datos.valida, input) { #} datos.imagen, input) { 

  # if (tabla.datos.valida) {
  #   tabla.temp <-  hot_to_r(input$datos)
  #   ordenes <- subset(tabla.temp, tabla.temp[,1] == TRUE)[,-1]
  # } else if(nrow(obj)!=0) {
  #   ordenes <- obj
  # } else {
  #   ordenes <- subset(tabla.temp, tabla.temp[,1] == TRUE)[,-1]
  # }
  # 
  # 
  # for(i in 1:nrow(ordenes)){                                      # Extrae el número de cliente del hipervínculo
  #   pos.cliente <- gregexpr(">",ordenes$CodigoPuntoConsumo[i])
  #   pos.cliente <- pos.cliente[[1]][1] + 1
  #   fin.cad <- nchar(ordenes$CodigoPuntoConsumo[i]) - 4
  #   ordenes$CodigoPuntoConsumo[i] <- substr(ordenes$CodigoPuntoConsumo[i],pos.cliente,fin.cad)
  # }
  # ordenes$CodigoPuntoConsumo <- unlist(ordenes$CodigoPuntoConsumo)
  # 
  # datos<-left_join(ordenes,datos.consulta,by = "CodigoPuntoConsumo") # Efectua unión para traer coordenadas
  # datos.consulta$PromedioActiva6CN<-as.numeric(as.character(datos.consulta$PromedioActiva6CN))  # Convierte a numérico
  # datos.consulta$PromedioActiva6CN[is.na(datos.consulta$PromedioActiva6CN)]=0                  # Ajuste de valores nulos
  # datos$LatitudPuntoConsumo <-as.numeric(as.character(datos$LatitudPuntoConsumo))
  # datos$LongitudPuntoConsumo <-as.numeric(as.character(datos$LongitudPuntoConsumo))

  
  # if (banderaRefresco) {
  #   google_map_update(map_id = "map") %>%
  #     clear_markers() %>%
  #     googleway::add_markers(data = datos,lat = "LatitudPuntoConsumo", lon = "LongitudPuntoConsumo", 
  #                            info_window = "Texto1",close_info_window = TRUE)
  #                            #info_window = "texto",close_info_window = TRUE)
  # } else {
  #   google_map(key = api_key, data = datos, style=estilo.map01) %>%
  #     googleway::add_markers(lat = "LatitudPuntoConsumo", lon = "LongitudPuntoConsumo", 
  #                            info_window = "Texto1",close_info_window = TRUE)
  # #  info_window = "texto",close_info_window = TRUE)
  # }
}


# Configuración de bd y código para api google --------------------------------------------------------------
configuracion.conexion <<- 'externalENERG' # Sys.getenv("CONEXIONSHINY") #'windows', 'externalENERG' para energuate
#  'GoogleKey' CodigoParametro api google en [DWSRBI_ENERGUATE].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "SELECT TOP 1 ValorParametro FROM [DWSRBI_ENERGUATE].[Aux].[Parametros] where EstadoParametro = 1 AND   CodigoParametro = 'GoogleKey'"
api_key <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)
api_key <<- api_key[1,1]


# Contadores y llamadas --------------------------------------------------------------
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante
#api_key <- "AIzaSyAYoARt3zU_arrmeiZmMCjXhLEyRoE7Z2Q"  # Solicitar clave a WM y cambiar
Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')
locale <- Sys.getlocale(category="LC_COLLATE")
if (grepl("Spanish", locale, fixed=TRUE)) {
  separador.csv <<- ';'
} else {
  separador.csv <<- ','
}

# Captura de parámetro para URL servidor shiny -------------
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql<- "SELECT [ValorParametro]  FROM [DWSRBI_ENERGUATE].[Aux].[Parametros]  WHERE [CodigoParametro] = 'URLshiny'"
URL.servidor.shiny <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
URL.servidor.shiny <- URL.servidor.shiny [1,1]
str.http <<- paste(URL.servidor.shiny,"hvurl/?Codigo=",sep="") # Cadena de llamada para vinculo a hoja de vida




# Captura de campañas disponibles en BD -----------------------------------
cad.sql<- "[dbo].[Leer_Campanas1]"
nom.camp <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom.camp)<-"Nombre"
nom.camp <- nom.camp  %>% filter(!is.na(Nombre))

# Consultar datos de filtros
consultarDatosFiltros(conexion)

# Carga contenido filtros
cargarFiltrosIniciales()

odbcClose(conexion)

# font negro para pickerinput
col_list2 <- c("black")
colorspi <- paste0("color:",rep(c('black'),each=10),";")
periodoLista = format(seq(as.Date("2022-06-01"), today(), by = "months"),"%Y%m")


ui = dashboardPage(
  dashboardHeader(title = "Auditoria de lecturas",
                  tags$li(div(
                    img(src = 'Kronos.png',
                        title = "Auditoria de lecturas", height = "30px"),
                    style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                    class = "dropdown"),
                  dropdownMenuOutput("MensajeOrdenes")),
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 500,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   fluidRow( column(width = 6,offset = 0, style='padding:0px;',
                                    box(id = "Comandos", width = 12, 
                                        status = NULL,  
                                        background = "black",
                                        fluidRow( 
                                              column(width = 2,offset = 1,
                                                         actionButton("ReiniciarControles", label = icon("fas fa-sync"),
                                                                      style="color: #fff; background-color: #0070ba; border-color: #0070ba"),
                                                         bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                                              ),
                                              column(width = 2,
                                                     offset = 1,
                                                     actionButton("TraerDatos", label = icon("fas fa-play"),
                                                                  style="color: #fff; background-color: #0070ba; border-color: #0070ba"), 
                                                     bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                                              )
                                        )
                                        
                                    ),
                                    
                                    # box(id = "Contadores", width = 12, status = NULL,  background = "black",
                                    # 
                                    #     pickerInput("periodo","Periodo:",
                                    #                 choices = periodoLista,
                                    #                 selected = NULL,
                                    #                 multiple=F,
                                    #                 choicesOpt = list(
                                    #                   style=rep(paste0("color:black;"),length(periodoLista))),
                                    #                 options = list(
                                    #                   `none-selected-text` = "Periodo"
                                    #                 )),
                                    #     
                                    # ),
                                    
                                    obtenerFiltrosZona(),
                                    obtenerFiltrosDepartamento()
                              ),
                             column(width = 6, offset = 0, style='padding:0px;',
                                    obtenerFiltrosEmpresa()
                             ))
  ),
  
  # Body --------------------------------------------------------------------
  ##00828F;
  dashboardBody(   
    useShinyjs(), 
    tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }'
                              
    )
    )
    ), # Fin estilo

    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel( type = "tabs", 
                 
                 tabPanel("Datos",
                          icon = icon("fas fa-table"),
                          hr(),
                          
                          fluidRow( 
                            box(#height = 420,
                              width = 12,
                              status = "warning",
                              solidHeader = FALSE,
                              title = "Modelo de auditoria de lecturas",
                              div(class = 'col-sm-4',
                                  strong("Total lectores: "), span(id = "TotalLectores", "0")
                              ),
                              div(class = 'col-sm-4',
                                  strong("Total lecturas: "), span(id = "TotalLecturas", "0")
                              ),
                              div(class = 'col-sm-4',
                                  strong("Total sospechas: "), span(id = "TotalAnomalas", "0")
                              ),
                              br(),
                              fluidRow(column(width=12, plotOutput("grafico",height = "250px") )),
                              br(),
                              #withSpinner(
                                rHandsontableOutput("datos", height = "600px")
                                #, color = getOption("spinner.color", default = "#0070ba"),
                                #  id = "contenedorTabla1"
                              #)
                              
                            )),
                          fluidRow(hr() ,      
                                   column(width = 3,
                                          offset = 9,
                                          shinyjs::disabled(downloadButton('Descargar', 'Descargar excel',
                                                                           style="color: #fff; background-color: #0070ba; border-color: #0070ba"),  # Se crea el botón deshabilitado para que
                                                            bsTooltip("Descargar", "Descargar seleccionados a excel",
                                                                      placement = "bottom", trigger = "hover", options = NULL)
                                          ) 
                                   )
                          ),
                          textOutput("LlavePC"),
                          tags$head(tags$style("#LlavePC{color: white;
                                 font-size: 20px;
                                 font-style: italic;
                                 }"
                          )
                          )                         
                 ),
                 
                 tabPanel("Detalle",
                          icon = icon("fas fa-table"),
                          hr(),
                          
                          fluidRow( 
                            box(#height = 420,
                              width = 12,
                              status = "warning",
                              solidHeader = FALSE,
                              title = "Detalle",
                              br(),
                              withSpinner(rHandsontableOutput("datosLector", height = "600px"),
                                          color = getOption("spinner.color", default = "#0070ba"),
                                          id = "contenedorTabla2"
                              )
                            )),
                          fluidRow(
                                   column(width = 3,
                                          offset = 9,
                                          shinyjs::disabled(downloadButton('DescargarLector', 'Descargar detalle excel',
                                                                           style="color: #fff; background-color: #0070ba; border-color: #0070ba"),  # Se crea el botón deshabilitado para que
                                                            bsTooltip("Descargar", "Descargar registros a excel",
                                                                      placement = "bottom", trigger = "hover", options = NULL)
                                          )
                                   )
                          )
                 ),
                 tabPanel("Ayuda",
                          icon = icon("fas fa-table"),
                          includeMarkdown("Ayuda.md")
                          
                 ),
                 
                 id="TabsApp"
    )
  )
)

# Server ------------------------------------------------------------------

server <- shinyServer(function(input, output, session) { # Importante iniciar con shinyServer para que funcione la ayuda
  
  consulta.activa <<- FALSE
  datos.consulta <- NA
  tipo.grafica <- 'P'
  tabla.datos.valida <- FALSE
  valores_validos_zona <<- NA
  valores_validos_region <<- NA
  valores_validos_centro <<- NA
  valores_validos_Geografia_departamento  <<- NA
  valores_validos_Geografia_municipio <<- NA

  valores_validos_estado <<- NA
  valores_validos_tarifa <<- NA
  valores_validos_mercado <<- NA
  
  # Ocultar Botones auxiliares para sincronizar paneles, paneles
  shinyjs::hide("MostrarTabla")
  shinyjs::hide("MostrarMapa")
  
  tabla.temp <<- hot_to_r(NULL)    # Tabla temporal para alimentar rhandsontable
  
  output$datos <- renderRHandsontable({   # Actualiza rhandsontable
    tabla.despliegue(tabla.temp, data.grafica()$sel)
  })
  
  # Ayuda -------------------------------------------------------------------
  
  
  # Cambio de tab ----------------------------------------------------------------------
  observeEvent(input$TabsApp, {
    if (input$TabsApp == "Datos") {
      tabla.datos.valida <<- TRUE
    }else if (input$TabsApp == "Detalle") {
      # Se valida si se seleccionó Lecturista
      codigo = input$datos_select$data[[input$datos_select$select$r]][[2]]

      # Si no se ha seleccionado entonces muestra modal y cambia de pestaña
      if (is.null(codigo)) {
        showModal(
          modalDialog(
            title = "¡Información!",
            "Para ver Detalle por favor seleccione un 'Nombre Lecturista' en la pestaña Datos",
            easyClose = TRUE,
            footer = tagList(
              modalButton("Cerrar")
            )
          )
        )
        updateTabsetPanel(session, "TabsApp", selected = "Datos")
      }
    }else if (input$TabsApp == "Mapa") {
      click("MostrarMapa")
    }
  }, ignoreInit = TRUE)
  
  
  # Seleccion de fila en tabla de datos --------------------------------------------------
  observeEvent(
    input$datos_sort
    ,{

      xyz <<- input$datos_sort$data
    }
  )
  
  output$LlavePC <- renderPrint({
    
    codigo = input$datos_select$data[[input$datos_select$select$r]][[2]]
    periodoEmp = input$datos_select$data[[input$datos_select$select$r]][[3]]
    
    if (!is.null(codigo)) {
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      
      cad.sql <- paste0("Select 
            a.NombreContratistaActor 'Nombre Lecturista', 
            nis_rad 'Servicio', 
            c.NombreCliente 'Cliente', 
            pc.DireccionPuntoConsumo 'Direccion', 
        	  llaveFecha 'Fecha', 
        	  LecturaActualActivaLectura 'Lectura',
        	  ConsumoNormalizadoActivaCN 'Consumo',
        	  CONCAT(ae.Seccion,': ', ae.Grupo) Actividad,
        	  z.NombreZona Zona,
        	  z.NombreRegion Region,
        	  z.NombreOficina Oficina,
        	  z.Itinerario Itinerario,
        	  g.NombreDepartamentoGeografia Departamento,
        	  g.NombreMunicipioGeografia Municipio,
        	  g.NombreLocalidadZonaGeografia Localidad,
        	  c2.Nombrecircuito Circuito 
          	from sgc.SGCPRO.benfordV bv 
        	inner join Dimension.Actor a on bv.cod_emp = a.CodigoContratistaActor and ProcesoCuadrilla = 'Lectura'
        	inner join Hecho.Llaves l on bv.nis_rad = l.codigoPuntoConsumo 
        	inner join Dimension.PuntoConsumo pc on pc.LlavePuntoConsumo = l.llavePuntoConsumo 
        	inner join Dimension.Cliente c on c.LlaveCliente = l.llaveCliente
        	inner join Dimension.ActividadEconomica ae on l.llaveActividadEconomica = ae.LlaveActividadEconomica
        	inner join Dimension.Geografia g on l.llaveGeografia = g.LlaveGeografia 
        	inner join Dimension.Zona z on l.llaveZona = z.LlaveZona 
        	inner join Dimension.Circuito c2 on l.llaveCircuito = c2.LlaveCircuito  
        where bv.periodo = ",periodoEmp," and bv.cod_emp = "
        ,"'",codigo,"'"
        ,condiciones_consultaGlobal)
      
      datos.consultaLector <-sqlExecute(channel = conexion, query = cad.sql, fetch= T, as.is=T)
      
      odbcClose(conexion)
      
      output$datosLector <- renderRHandsontable({
        tablaLector.despliegue(datos.consultaLector)
      })
      
      updateTabsetPanel(session, "TabsApp", selected = "Detalle")
      
    }
  })
  
  # Carga de datos a listas desplegables
  manejarEventosFiltros(input, output, session)
  
  # Reinicial controles
  manejarReinicioFiltros(input, output, session)
  
  # Hacer consulta basada en valores de filtros  ---------------------------
  observeEvent(input$TraerDatos, {
    noHayValores <- FALSE
    #meses_busqueda <<- input$mesesRevisar
    condiciones_consulta = ''
    
    # Construir condiciones de consulta:
    if(!is.null(input$zona_comercial)){
    
        #f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos[c("LlaveZona")]), collapse=",")),1,stop =1000000L)
        valores_validos <- consulta_zona(seleccion_operativa, valores_ZonaOperativa,input)
        
        f1 <- t(unique(valores_validos[c("LlaveZona")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        #f1 <- paste0(gsub(":",",",unique(valores_validos[c("LlaveZona")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        f1 <- str_replace(f1, "[)]", "")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND l.Llavezona IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    
    if(!is.null(input$region)){
        #f1 <- substr(gsub("[\r751:\n]", "",paste0(unique(valores_validos_Geografia[c("LlaveGeografia")]), collapse=",")),1,stop =1000000L)
        valores_validos_Geografia <- consulta_geografia(seleccion_geografia, valores_Geografia,input)
        f1 <- t(unique(valores_validos_Geografia[c("LlaveGeografia")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        #f1 <- paste0(gsub(":",",",unique(valores_validos_Geografia[c("LlaveGeografia")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        f1 <- str_replace(f1, "[)]", "")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND l.LlaveGeografia IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    
    if(!is.null(input$circuitos)){
        f1 <- t(unique(valores_validos_circuitos[c("LlaveCircuito")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        #f1 <- paste0(gsub(":",",",unique(valores_validos_circuitos[c("LlaveCircuito")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        f1 <- str_replace(f1, "[)]", "")
        condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                         " AND l.LlaveCircuito IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    
    if (seleccion_iniciativa  != 'no') {
      if (nrow(valores_validos_iniciativa) == 0 ) {
        noHayValores <- TRUE
      }
    }
    
    c1 <- ''
    c2 <- ''
    if(!is.null(input$cnae)){
        f1 <- t(unique(valores_validos_cnae_division[c("LlaveActividadEconomica")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        #f1 <- paste0(gsub(":",",",unique(valores_validos_cnae_division[c("LlaveActividadEconomica")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        c1 <- str_replace(f1, "[)]", "")
        
        # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
        #                                                  " AND l.LlaveActividadEconomica IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    
    if(!is.null(input$cnaegrupo)){
        f1 <- t(unique(valores_validos_CNAEgrupo[c("LlaveActividadEconomica")]))
        f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
        f1 <- paste0(gsub(":",",",unique(valores_validos_CNAEgrupo[c("LlaveActividadEconomica")])), collapse=",")
        f1 <- str_replace(f1, "[(]", "")
        f1 <- str_replace(f1, "[c]", "")
        c2 <- str_replace(f1, "[)]", "")
        # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
        #                                                  " AND LlaveActividadEconomica IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      }
    
    # Unificar seleccion_CNAE y seleccion_grupo
    if(!is.null(input$cnaegrupo)){
      if (seleccion_CNAE != 'no' && seleccion_grupo != 'no') {
        condiciones_CNAE <- gsub("[\r\n]", "",substr(c1,1,stop =1000000L),  
                                                         ",",substr(c2,1,stop =1000000L) )
        condiciones_consulta <- paste0(condiciones_consulta,
                                       " AND l.LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
      } else if (seleccion_CNAE != 'no' ) {
        condiciones_CNAE <- gsub("[\r\n]", "",substr(c1,1,stop =1000000L) )
        condiciones_consulta <- paste0(condiciones_consulta,
                                       " AND l.LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
                                                         
        
      } else if (seleccion_grupo != 'no') {
        condiciones_CNAE<- gsub("[\r\n]", "",substr(c2,1,stop =1000000L) )
        condiciones_consulta <- paste0(condiciones_consulta,
                                       " AND l.LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
      }
    }

    if(!is.null(input$estado)){
      if (seleccion_estado != 'no') {
        ifelse (is.na(valores_validos_estado),
                {
                  lista_seleccion <- input$estado
                  valores_validos_estado <<- valores_Estados %>%
                    filter(valores_Estados$NombreEstado %in% lista_seleccion)
                },NA)  
        if (nrow(valores_validos_estado) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_estado[c("LlaveEstado")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tension[c("Llavetension")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND LlaveEstrato IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    
    if(!is.null(input$tension)){
      if (seleccion_tension != 'no') {
        if (nrow(valores_validos_tension) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_tension[c("Llavetension")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tension[c("Llavetension")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveTension IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$tarifa)){
      if (seleccion_tarifa != 'no') {
        ifelse (is.na(valores_validos_tarifa),
                {
                  lista_seleccion <- input$tarifa
                  valores_validos_tarifa <<- valores_Tarifa %>%
                    filter(valores_Tarifa$NombreTarifa %in% lista_seleccion)
                } , NA) 
        if (nrow(valores_validos_tarifa) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_tarifa[c("LlaveTarifa")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tarifa[c("LlaveTarifa")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveTarifa IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$mercado)){
      if (seleccion_mercado != 'no') {
        ifelse (is.na(valores_validos_mercado),
                {
                  lista_seleccion <- input$mercado
                  valores_validos_mercado <<- valores_Mercado  %>%
                    filter(valores_Mercado$NombreMercado %in% lista_seleccion)
                } , NA) 
        if (nrow(valores_validos_mercado) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_mercado[c("LlaveMercado")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_mercado[c("LlaveMercado")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlaveTipoObjeto IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$pimt)){
      if (seleccion_PIMT != 'no') {
  
        if (nrow(valores_validos_PIMT) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_PIMT[c("LlavePIMT")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_PIMT[c("LlavePIMT")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND l.LlavePIMT IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$ynormalizacion)){
      if (seleccion_ynormalizacion != 'no') {
        if (nrow(valores_validos_ynormalizacion) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_ynormalizacion[c("Llaveynormalizacion")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          f1 <- paste0(gsub(":",",",unique(valores_validos_ynormalizacion[c("Llaveynormalizacion")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND Llaveynormalizacion IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$habitacion)){
      if(input$habitacion == 'Habitado'){
        condiciones_consulta <- paste0(condiciones_consulta," AND l.Habitado = 1 ")
      }
      if(input$habitacion == 'No habitado'){      
        condiciones_consulta <- paste0(condiciones_consulta," AND l.Habitado = 0 ")
      }
      if(input$habitacion == 'Sin definir'){
        condiciones_consulta <- paste0(condiciones_consulta," AND l.Habitado is NULL ")
      }
    }
    
    # traer valores de Auditoria de lecturas

    if (1==0){#noHayValores) {
      showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        
        "La consulta no genera resultados",
        footer = list(modalButton("Cancelar", icon = icon("fas fa-table"))
        ),
        easyClose =TRUE
      )
      )
    }  else {

      disable("ReiniciarControles")  
      disable("TraerDatos")
      
      condiciones_consultaGlobal <<- condiciones_consulta
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      
      consultaPeriodo <- sqlExecute(
              channel = conexion, 
              query = "select max(bf.Periodo) from sgc.SGCPRO.benfordV bf", 
              fetch= T, as.is=T)
      
      periodo <- consultaPeriodo[1]
      
      cad.sql <- paste0(
        "select
                  a.LlaveActor,
                  a.NombreContratistaActor,
                  anomalas.cod_emp,
                  anomalas.periodo,
                  anomalas.totalAnomalas,
                  total.total,
                  cast(anomalas.totalAnomalas as float)/total.total porcentaje
                FROM
                    (select count(*) totalAnomalas, bf.cod_emp, bf.periodo
                    from sgc.SGCPRO.benfordV bf
                        inner join Hecho.Llaves l on bf.nis_rad = l.codigoPuntoConsumo
                        where bf.periodo = ",periodo," and
                            l.llavePuntoConsumo >0 AND bf.ConsumoNormalizadoActivaCN > 0"
        ,condiciones_consulta,
        "group by bf.cod_emp, bf.periodo) anomalas
                    inner join
                    (SELECT count(*) total, le.cod_emp
                        FROM sgc.SGCPRO.apmedida_co",periodo," lc
                        LEFT JOIN sgc.SGCPRO.DXES_SERVICIOS ds on lc.nis_rad = ds.id_servicio
                        LEFT JOIN sgc.Excel.LectoresEnerguateUnique le on ds.ID_LECTURA_CENTRO = le.COD_UNICOM and ds.ID_LECTURA_RUTA = le.Ruta and ds.ID_LECTURA_ITINERARIO = le.NUM_ITIN
                        inner join Hecho.Llaves l on lc.nis_rad = l.codigoPuntoConsumo
                        where l.llavePuntoConsumo > 0"
        ,condiciones_consulta,
        "
                      group by le.cod_emp) total
                  on anomalas.cod_emp = total.cod_emp
                  inner join
                  Dimension.Actor a
                      on total.cod_emp = a.CodigoContratistaActor and ProcesoCuadrilla = 'Lectura'")
      
      datos.consulta <- sqlExecute(channel = conexion, query = cad.sql, fetch= T, as.is=T)
        
      
      odbcClose(conexion)
      
      if (nrow(datos.consulta) > 0) {
        
        html("TotalLectores", nrow(datos.consulta))
        html("TotalLecturas", sum(datos.consulta$total))
        html("TotalAnomalas", sum(datos.consulta$totalAnomalas))
        
        tabla.datos.valida <<- FALSE
        shinyjs::enable("Guardar")
        shinyjs::enable("Descargar")
        shinyjs::enable("DescargarLector")
        
        tabla.datos<- datos.consulta
        
        tabla.datos <- cbind("°" = TRUE, tabla.datos)
        tabla.datos <<- tabla.datos
        
        output$grafico <- renderPlot({hist(
                             as.numeric(datos.consulta$porcentaje),
                             col = "#0070ba",
                             xlab = "Porcentaje",
                             ylab = "Frecuencia",
                             main = "Histograma")})
        
        output$datos <- renderRHandsontable({
          tabla.despliegue(tabla.datos, data.grafica()$sel)
        })
        
      } else{
        disable("Guardar")
        disable("Descargar")
        disable("DescargarLector")
        showModal(modalDialog(
          title = "La consulta no encuentra datos que cumplan.",
          footer = tags$div(id="modal1",modalButton("Cerrar")),
          easyClose = TRUE
        ))
      }
      
      shinyjs::enable("ReiniciarControles")
      shinyjs::enable("TraerDatos")
    }

  }, ignoreInit = TRUE)
  
  data.grafica<-reactive({
    if (exists("tabla.datos")){
      tabla.datos.valida <<- FALSE
      tmp<-tabla.datos
      sel<-tryCatch(tabla.datos[(selected()$pointNumber+1),,drop=FALSE] , error=function(e){NULL})
      if (nrow(sel) > 0 & tipo.grafica == 'B') {
        secuencia.sel <- selected()$pointNumber + 1
        valores.ceros <- sort(unique(tabla.datos$AcumuladoConsumoCero))[secuencia.sel]
        sel <-  tabla.datos %>% filter(AcumuladoConsumoCero %in% valores.ceros)
        list(data=tmp,sel=sel)
      } else {
        click('MostrarTabla')
        list(data=tmp,sel=sel)
      }
      
    }
    
   # list(data=tmp,sel=sel)
    
  })
 
  # Presentación del mapa --------------------------------------------------- 
  # output$map <- renderGoogle_map({
  #   if (exists("tabla.datos")) {
  #     mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta, FALSE, tabla.datos.valida, input) #, datos.imagen, input)
  #   }
  # })
  
  # Cambiar tipo de gráfica  ----------------------------------------
  observeEvent(input$selec.graf,{

    valorSwitch <- input$selec.graf
    if (valorSwitch == TRUE) {
      tipo.grafica <<- 'B'
      output$plot <- renderPlotly({
        p <- ggplot(tabla.datos, mapping = aes(x = AcumuladoConsumoCero)) +
          geom_bar(color ="#0070ba",fill= "#0070ba",size =1) + theme_bw()+
          ylab("Conteo") +
          xlab("Períodos consecutivos en cero")
        # Manejo de selección en gráfica
        obj <- data.grafica()$sel
        if(nrow(obj)!=0) {
          p <- p + geom_bar(data=obj,color="orange",fill="orange")
        }
        ggplotly(p,source="master")
      })
    } else {
      tipo.grafica <<- 'P'
      output$plot <- renderPlotly({
        p <-
          ggplot(tabla.datos,
                 mapping = aes(x = AcumuladoConsumoCero, y = PromedioActiva6CN, text = texto)) +
          geom_point(color = "#0070ba", size = 1) + theme_bw() +
          ylab("Consumo promedio 6 meses anteriores [kWh]") +
          xlab("Períodos consecutivos en cero")
        
        # Manejo de selección en gráfica
        obj <- data.grafica()$sel
        if(nrow(obj)!=0) {
          p <- p + geom_point(data=obj,color="orange")
        }
        ggplotly(p, source = "master")
      })
    }
    }, ignoreInit = TRUE)
  
  # Seleccionar o deselecionar todos ----------------------------------------
  
  observeEvent(input$selec.tod,{
    tabla.temp <<- hot_to_r(input$datos)    # Tabla temporal para alimentar rhandsontable
    
    if(input$selec.tod == "Todos"){
      tabla.temp[,1] <- TRUE             # Cambia primera columna a seleccionado
    }
    
    if(input$selec.tod == "Ninguno"){
      tabla.temp[,1] <- FALSE               # Cambia primera columna a deseleccionado
    }
    output$datos <- renderRHandsontable({   # Actualiza rhandsontable
    tabla.despliegue(tabla.temp, data.grafica()$sel)
    })
    # output$map <- renderGoogle_map({
    #   mapa.despliegue(tabla.temp, data.grafica()$sel, datos.consulta, TRUE,tabla.datos.valida, input) #, datos.imagen, input)
    # })
    
  }, ignoreInit = TRUE)
  
  # Descargar excel -----------------------------------------------------------
  
  output$Descargar <- downloadHandler(
    
    filename = function() {
      paste0("AuditoriaLecturas", Sys.Date(), ".xlsx")
    },
    content = function(file) {
      ordenes<-hot_to_r(input$datos)
      wbk <- createWorkbook()
      addWorksheet( wb = wbk,  sheetName = "Data" )
      # setColWidths(wbk,1,cols = 1:2,
      #              widths = c(6,10))
      # Ver https://www.r-bloggers.com/2019/07/excel-report-generation-with-shiny/
      # writeData(wbk,sheet = 1,
      #           c("CodigoPuntoConsumo" ,"NombreCliente","DireccionPuntoConsumo","Seccion","AcumuladoConsumoCero"         ,"PromedioActiva6CN"   ,"NombreZona" ,"NombreRegion","NombreOficina"
      #             ,"NombreDepartamentoGeografia","NombreMunicipioGeografia","NombreLocalidadZonaGeografia","Nombre_corto_SMT"),
      #           startRow = 1,startCol = 1)
      
      addStyle(wbk,sheet = 1, style = createStyle( fontSize = 12, textDecoration = "bold" ), rows = 1:1, cols = 1:ncol(ordenes) )
      writeData(wbk,sheet = 1,ordenes,startRow = 1,startCol = 1 )
      saveWorkbook(wbk, file)
    }
  )
  
  output$DescargarLector <- downloadHandler(
    
    filename = function() {
      paste0("AuditoriaLecturasDetalle", Sys.Date(), ".xlsx")
    },
    content = function(file) {
      ordenes<-hot_to_r(input$datosLector)
      wbk <- createWorkbook()
      addWorksheet( wb = wbk,  sheetName = "Data" )
      # setColWidths(wbk,1,cols = 1:2,
      #              widths = c(6,10))
      # Ver https://www.r-bloggers.com/2019/07/excel-report-generation-with-shiny/
      # writeData(wbk,sheet = 1,
      #           c("CodigoPuntoConsumo" ,"NombreCliente","DireccionPuntoConsumo","Seccion","AcumuladoConsumoCero"         ,"PromedioActiva6CN"   ,"NombreZona" ,"NombreRegion","NombreOficina"
      #             ,"NombreDepartamentoGeografia","NombreMunicipioGeografia","NombreLocalidadZonaGeografia","Nombre_corto_SMT"),
      #           startRow = 1,startCol = 1)
      
      addStyle(wbk,sheet = 1, style = createStyle( fontSize = 12, textDecoration = "bold" ), rows = 1:1, cols = 1:ncol(ordenes) )
      writeData(wbk,sheet = 1,ordenes,startRow = 1,startCol = 1 )
      saveWorkbook(wbk, file)
    }
  )
  
  observeEvent(input$MostrarTabla, {
    if (exists("tabla.datos")) {
      if (nrow(data.grafica()$sel) == 0) {
        tabla.temp <- tabla.datos
      }
      if (exists("tabla.temp")){
        tabla.temp[,1] <- TRUE
        output$datos <- renderRHandsontable({   # Actualiza rhandsontable
          tabla.despliegue(tabla.temp, data.grafica()$sel)
        })
      } 
    }
  }, ignoreInit = TRUE)  
  
  # observeEvent(input$MostrarMapa, {
  #   if ( exists("tabla.datos")) {
  #     mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta,TRUE,tabla.datos.valida, input) #, datos.imagen, input)
  #   }
  #   #  mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta,TRUE,tabla.datos.valida, input)
  #   # output$map <- renderGoogle_map({
  #   #   mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta)
  #   # })
  # }, ignoreInit = TRUE)
  
  # Generar órdenes de inspección en BD ---------------------------------------------------
  observeEvent(input$Guardar,{
 
    showModal(modalDialog(
      
      title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("Generar órdenes"),style="color: #0070ba"),style="text-align: center;"),
      
      "Se guardarán los clientes seleccionados para ser incluidos \n en la lista de órdenes de inspección",
      hr(),
      
      selectInput("variable", 
                  "Seleccione campaña:",
                  nom.camp),
      textAreaInput("observ.orden", label = "Observaciones:",
                    height = "100px", rows = 4, 
                    placeholder = "Comentarios para acompañar la órden", 
                    resize = "vertical"),
      # footer = list(tags$div(id="modal1",modalButton("Cancelar", icon = icon("fas fa-table"))),
      #               actionButton("Guardar2", "Guardar",icon = icon("fas fa-table"),
      #                            style="color: #fff; background-color: #0070ba; border-color: #0070ba")
      # ),
      footer = fluidRow(column(width=2, offset=7,tags$div(id="modal1", 
                                                          modalButton("Cancelar", icon = icon("fas fa-table")))),
                        column(width=2,actionButton("Guardar2", "Guardar",icon = icon("fas fa-table"),
                                                    style="color: #fff; background-color: #0070ba; border-color: #0070ba"))
      ),
      easyClose =TRUE
    )
    )
  }, ignoreInit = TRUE)
  
  
  observeEvent(input$Guardar2, {                                          # Código para botón diálogo modal
    
    #  Grabar órdenes en BD
    
    ordenes <- transf.rhand(input$datos)                      # Transforma los datos tomados del objeto rhandsontable.
    ordenes <- subset(ordenes, ordenes[,1] == TRUE)[,-1]      # Filtra aquellos con checkbox activo y omite primera columna
    
    if (nrow(ordenes) > 0) {
      ordenes<-cbind(ordenes[,1],                                         # Punto de consumo: 'CodigoPuntoConsumo'
                     rep(as.character(input$variable), nrow(ordenes)),    # Línea para tipo de campaña seleccionada: 'NombreCampana'
                     rep("Auditoria de Lecturas", nrow(ordenes)),          # Reporte origen de las órdenes: 'ReporteOrigen'
                     rep(as.character(Sys.time()), nrow(ordenes)),        # Fecha y hora de generación de las órdenes: 'FechaGeneracion'
                     rep(analista, nrow(ordenes)),                        # Usuario que genera las órdenes: 'AnalistaSolicitante'
                     rep(0.5, nrow(ordenes)),                             # 'Probabilidad' de detección. ** Se debe incluir probabilidad de la campaña, por ahora es 0.5
                     ordenes[,9],                                         # 'RecuperacionMedia': Se asume promedio anterior
                     rep(as.character(input$observ.orden), nrow(ordenes)) #  Observación que acompaña la orden 'ObservacionOrden'
      )
      
      ordenes<-data.frame(ordenes)
      ordenes[,7]<-as.numeric(as.character(ordenes[,7]))                  # Se convierte a texto el dato tomado de la tabla
      
      #conexion2 <- odbcDriverConnect ("driver={SQL Server};server=WMENERTOLIMA\\SQL2017;database=DWSRBI_ENERGUATE;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" )
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      cad.sql<-" INSERT INTO [DWSRBI_ENERGUATE].[Hecho].[OrdenInspeccion]([CodigoPuntoConsumo],[NombreCampana],[ReporteOrigen],[FechaGeneracion],[AnalistaSolicitante],[Probabilidad],[RecuperacionMedia],[ObservacionOrden])"
      cad.sql<-paste (cad.sql,"VALUES (?,?,?,?,?,?,?,?)")
      
      sqlExecute(channel = conexion,
                 cad.sql,
                 data = ordenes)              # En 'ordenes' se incluyen las órdenes a ser incluidas en la tabla 'OrdenInspeccion'
      odbcClose(conexion)
      
      ord.gen <<- ord.gen + nrow(ordenes)     # Se actualiza el contador de órdenes generadas en la sesión. Variable global
      
      output$MensajeOrdenes <- renderMenu({   # Actualiza mensaje en la barra de menú para órdenes generadas
        
        dropdownMenu(type = "notifications",  # Mensaje en barra de encabezado para indicar generación de órdenes
                     headerText = "Tiene una notificación",
                     icon =icon("fas fa-comments"),
                     notificationItem(
                       text = paste(ord.gen, "órdenes generadas en esta sesión"),
                       icon("fas fa-gavel")
                     )
        )
      })
    }
    removeModal()
  })
  
})



# Ejecutar aplicación -----------------------------------------------------


shinyApp(ui = ui, server = server)