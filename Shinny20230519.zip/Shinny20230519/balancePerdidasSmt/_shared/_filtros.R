# FuncionAux Configurar consulta por datos geografia
consulta_geografia <- function (seleccion_geografia, valores_Geografia,input) {
  
  valores_validos_Geografia <- valores_Geografia
  lista_seleccion <- input$departamento
  if (length(lista_seleccion) > 0) {
    valores_validos_Geografia <- valores_Geografia %>% 
      filter(valores_Geografia$NombreDepartamentoGeografia %in% lista_seleccion)	  
    lista_seleccion <- input$municipio
    if (length(lista_seleccion) > 0) {
      valores_validos_Geografia <- valores_validos_Geografia %>% 
        filter(valores_validos_Geografia$NombreMunicipioGeografia %in% lista_seleccion)
      lista_seleccion <- input$localidad
      if (length(lista_seleccion) > 0) {
        valores_validos_Geografia <- valores_validos_Geografia %>% 
          filter(valores_validos_Geografia$NombreLocalidadZonaGeografia %in% lista_seleccion)
      }
    }
  }
  valores_validos_Geografia <<- valores_validos_Geografia 
  valores_validos_Geografia
}

# FuncionAux Configurar consulta por datos Zona
consulta_zona <- function (seleccion_operativa, valores_ZonaOperativa,input) {
  
  valores_validos <- valores_ZonaOperativa
  lista_seleccion <- input$zona_comercial
  if (length(lista_seleccion) > 0) { 
    valores_validos <- valores_ZonaOperativa %>% 
      filter(valores_ZonaOperativa$NombreZona %in% lista_seleccion)
    lista_seleccion <- input$region
    if (length(lista_seleccion) > 0) {
      valores_validos <- valores_validos %>% 
        filter(valores_validos$NombreRegion %in% lista_seleccion)
      lista_seleccion <- input$centro
      if (length(lista_seleccion) > 0) { 
        valores_validos <- valores_validos %>% 
          filter(valores_validos$NombreOficina %in% lista_seleccion)
        lista_seleccion <- input$itinerario  
        if (length(lista_seleccion) > 0) {
          x1 <- strsplit(lista_seleccion, " - ",fixed = T)
          valores_validos<- valores_validos %>% filter(Itinerario %in% x1)
        }
      }
    }
  }
  valores_validos <<- valores_validos
  valores_validos
}

# FuncionAux Configurar consulta por datos CNAE
consulta_CNAE <- function (seleccion_CNAE, valores_CNAE,input) {
  # No probado todavía...
  
  valores_validos <- valores_CNAE
  lista_seleccion <- input$cnae
  if (length(lista_seleccion) > 0) { 
    valores_validos <- valores_CNAE %>% 
      filter(valores_CNAE$Grupo %in% lista_seleccion)
    lista_seleccion <- input$cnaegrupo
    if (length(lista_seleccion) > 0) {
      valores_validos <- valores_validos %>% 
        filter(valores_validos$Seccion %in% lista_seleccion)
    }
  }
  valores_validos <<- valores_validos
  valores_validos
}


# Consulta de los datos a usar en los filtros
consultarDatosFiltros <- function (conexion) {
  cad.sql<-"EXEC [dbo].[Lista_FiltroZona]"
  valores_ZonaOperativa <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroGeografia]"
  valores_Geografia <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroCircuitos]"
  valores_Circuitos <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroIniciativa1]"
  valores_Iniciativa <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_CNAE]"
  valores_CNAE <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_yyNormalizacion]"
  valores_Normalizacion <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_PIMT]"
  valores_PIMT <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroTarifa]"
  valores_Tarifa <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroTension]"
  valores_Tension <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_Estados]"
  valores_Estados <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_Mercado]"
  valores_Mercado <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  cad.sql <- "EXEC [dbo].[Lista_FiltroPuntoFrontera]"
  valores_PuntoFrontera <<- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
}

# Carga de filtros con valores iniciales
cargarFiltrosIniciales <- function() {
  
  seleccion_operativa <<- 'no'
  # Datos iniciales para  selectores de jerarquía
  x <-  c(unique(valores_ZonaOperativa[c("NombreZona")]))
  zonaCom <<- x[order(x)]
  zonaComColor <<- rep(paste0("color:black;"),length(zonaCom))
  
  seleccion_geografia <<- 'no'
  x  <-  c(unique(valores_ZonaOperativa[c("NombreRegion")]))
  regionCom <<- x[order(x)]
  regionComColor <<- rep(paste0("color:black;"),length(regionCom))
  x <- c(unique(valores_ZonaOperativa[c("NombreOficina")]))
  centroCom <<- x[order(x)]
  centroComColor <<- rep(paste0("color:black;"),length(centroCom))
  #x <- c(unique(valores_ZonaOperativa[c("Itinerario")]))
  x <- valores_ZonaOperativa %>% select("NombreOficina", "Itinerario") %>% 
    distinct() %>% arrange(NombreOficina, Itinerario)
  x <- paste0(x$NombreOficina, " - ", x$Itinerario)
  itinerarioCom <<- x
  itinerarioComColor <<- rep(paste0("color:black;"),length(itinerarioCom))
  
  seleccion_geografia <<- 'no'
  x <-  c(unique(valores_Geografia[c("NombreDepartamentoGeografia")]))
  departamentoGeo <<- x
  x <-  c(unique(valores_Geografia[c("NombreMunicipioGeografia")]))
  municipioGeo <<- x[order(x)]
  x <-  c(unique(valores_Geografia[c("NombreLocalidadZonaGeografia")]))
  localidadGeo <<- x[order(x)]
  
  seleccion_circuito <<- 'no'
  x <-  c(unique(valores_Circuitos[c("CodigoCircuito")]))
  codigosCircuito <<- x[order(x)]
  
  seleccion_puntofrontera <<- 'no'
  x <-  c(unique(valores_PuntoFrontera[c("Nombre_PuntoFrontera")]))
  codigosPuntoFrontera <<- x[order(x)]
  
}

# Capturar y manejar eventos de los filtros dependientes
manejarEventosFiltros <- function(input, output, session){
  
  # Jerarquía de zonas operativas
  observeEvent(input$zona_comercial, {
    seleccion_operativa <<- "zona_comercial"
    lista_zona <- input$zona_comercial
    valores_validos_zona <<- valores_ZonaOperativa %>% 
      filter(valores_ZonaOperativa$NombreZona %in% lista_zona)
    
    # valores_validos <<- valores_validos_zona
    # x <-  c(unique(valores_validos_zona [c("NombreRegion")]))
    # xColor <- rep(paste0("color:black;"),length(x[[1]]))
    # updatePickerInput(session,
    #                   "region",
    #                   choices = sort(x[[1]]),
    #                   choicesOpt = list(
    #                     style=rep(paste0("color:black;"),length(x[[1]])))) #c( atr$Nombre)))  ,
    #    selected = valor.seleccionado)
  }, ignoreInit = TRUE, ignoreNULL = F)
  
  
  
  observeEvent(input$region, {
    seleccion_operativa <<- "region"
    lista_region <- input$region
    
    valores_validos_region <<- valores_ZonaOperativa %>%
      filter(valores_ZonaOperativa$NombreRegion %in% lista_region)
    # CodigosRegion <- unique(
    #   filter(valores_ZonaOperativa, 
    #          valores_ZonaOperativa$NombreRegion %in% lista_region
    #   )[["CodigoRegion"]]
    # )
    

    

    
    # SE: Actualizar SMT
    # valores_filtro <- valores_Circuitos %>% 
    #   filter(valores_Circuitos$NombreRegion %in% lista_region)
    # x <-  c(unique(valores_filtro[c("CodigoCircuito")]))
    # chlist <- list(style=rep(c("color:black;"),length(x[[1]]))) 
    # updatePickerInput(session,
    #                   "circuitos",
    #                   choices = sort(x[[1]]),
    #                   choicesOpt = chlist)
    
  }, ignoreInit = TRUE, ignoreNULL = F)
  
  
  # circuito
  observeEvent(input$circuitos, {
    #browser()
    seleccion_circuito <<- 'circuitos'
    lista_seleccion <- input$circuitos
    valores_validos_circuitos <<- valores_Circuitos %>%
      filter(valores_Circuitos$CodigoCircuito %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  # PF
  observeEvent(input$puntofrontera, {
    #browser()
    seleccion_puntofrontera <<- 'puntofrontera'
    lista_seleccion <- input$puntofrontera
    valores_validos_puntofrontera <<- valores_PuntoFrontera %>%
      filter(valores_PuntoFrontera$Nombre_PuntoFrontera %in% lista_seleccion)
  }, ignoreInit = TRUE)
  
  
}

# Capturar y manejar reinicio de filtros
manejarReinicioFiltros <- function(input, output, session){
  observeEvent(input$ReiniciarControles, {
    
    seleccion_operativa <<- 'no'
    
    # Datos iniciales para  selectores de jerarquía
    x <-  c(unique(valores_ZonaOperativa[c("NombreZona")]))
    zonaCom <- x[order(x)]
    valores_validos_zona <<- NA
    valores_validos_region <<- NA
    valores_validos_centro <<- NA
    
    # isolate(
    #   
    #   updatePickerInput(session,
    #                     "zona_comercial", choices = sort(zonaCom[[1]]),
    #                     selected = '',
    #                     choicesOpt = list(
    #                       style=rep(paste0("color:black;"),length(zonaCom[[1]])))))
    isolate(
      updatePickerInput(session,
                        "region",selected=''))
    
    seleccion_circuito <<- 'no'
    x <-  c(unique(valores_Circuitos[c("CodigoCircuito")]))
    codigosCircuito <- x
    isolate(
      updatePickerInput(session,
                        "circuitos", # sort(codigosCircuito[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosCircuito[[1]])))))
    
    seleccion_puntofrontera <<- 'no'
    x <-  c(unique(valores_PuntoFrontera[c("Codigo_Punto_Frontera")]))
    codigosPuntoFrontera <- x
    isolate(
      updatePickerInput(session,
                        "puntofrontera", 
                        #choices = c(''), # sort(codigosCircuito[[1]]),
                        selected='',
                        choicesOpt = list(
                          style=rep(paste0("color:black;"),length(codigosPuntoFrontera[[1]])))))
    
    isolate(
      updatePickerInput(session,
                        "periodo_ini",selected=''))

    
  }, ignoreInit = TRUE)
}

# Obtener box con filtros de zona
obtenerFiltrosZona <- function() {
  valores_validos <<- valores_ZonaOperativa
  x <-  c(unique(valores_ZonaOperativa[c("NombreRegion")]))
  
  return (box( id = "filtros1", width = 12, status = NULL,  background = "black",
               #colorspi <- paste0("color:",rep(c('black'),each=10),";"),
               # pickerInput("zona_comercial","Zona:",
               #             choices = sort(zonaCom[[1]]),
               #             selected = NULL,
               #             multiple=T,
               #             choicesOpt = list(
               #               style=rep(paste0("color:black;"),length(zonaCom[[1]]))),
               #             options = list(
               #               #`actions-box` = TRUE,
               #               #`deselect-all-text` = "Ninguno",
               #               #`select-all-text` = "Todos",
               #               `none-selected-text` = "Zona comercial"
               #             )),
               # 
               
               

               pickerInput("region","Región:",
                           choices = sort(x[[1]]), #regionCom,
                          choicesOpt = list(style=rep(paste0("color:black;"),length(x[[1]]))),
                           #selected = '-TODOS-',
                           multiple=T,
                           options = list(
                             # `actions-box` = TRUE,
                             # `deselect-all-text` = "Ninguno",
                             # `select-all-text` = "Todos",
                             `none-selected-text` = "Región"
                           ))
               
  ))
}


# Obtener box con filtros de empresa
obtenerFiltrosEmpresa <- function() {
  
  valores_filtro <- valores_Circuitos 
  x <-  c(unique(valores_filtro[c("CodigoCircuito")]))
  
  return( box(id = "Empresas", width = 12, 
              status = NULL,  
              background = "black",
              
              pickerInput("puntofrontera","Punto Frontera:",
                          choices = sort(codigosPuntoFrontera[[1]]), #codigosCircuito[[1]]), codigosPuntoFrontera
                          selected = NULL,
                          multiple=T,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),length(codigosPuntoFrontera[[1]]))),
                          options = list(
                            # `actions-box` = TRUE,
                            # `deselect-all-text` = "Ninguno",
                            # `select-all-text` = "Todos",
                            `none-selected-text` = "PF"
                          )),
              pickerInput("circuitos","SMT:",
                          choices = sort(x[[1]]), #codigosCircuito[[1]]),
                          #selected = '-TODOS-',
                          multiple=T,
                          choicesOpt = list(
                            style=rep(paste0("color:black;"),length(x[[1]]))),
                          options = list(
                            # `actions-box` = TRUE,
                            # `deselect-all-text` = "Ninguno",
                            # `select-all-text` = "Todos",
                            `none-selected-text` = "SMT"
                          ))
              
              
  )
  )
}
