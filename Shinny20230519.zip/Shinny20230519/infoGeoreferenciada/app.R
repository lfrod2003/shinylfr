# =============================================================================
#                             Datos Georeferenciados (puntos de consumo)
# =============================================================================
# 
# 
# Autor:                Nelson Beltrán Celis - F Rodríguez
# Fecha de creación:    06.10.2020
# Versión:              1.0
# Descripción:
# Reporte para seleccionar dinámicamente datos de clientes
# sobre un mapa, con capacidad de definir geocercas, guardar lista de seleccionados a csv
# y generar datos de órdenes de inspeccion a una tabla en base de datos.
#
# Tablas de consulta directa: [Aux].[Parametros]
# Tablas en las que escribe: [Hecho].[OrdenInspeccion]
# Procedimientos almacenados relacionados: [dbo].[Lista_DatosMapas_Prueba] 
#                                            dbo.Dataset_MapaConsumo_shiny
#
# =============================================================================

# Carga de librerías ------------------------------------------------------
options(useFancyQuotes = FALSE)
library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
library(rhandsontable)  # Visualización tablas
library(htmlwidgets)
library(scales)
library(lubridate)
library(shinydashboard)
library(DT)
library(ggplot2)
library(plotly)         # Graficas dinámicas plotly
library(RCurl)
library(leaflet)
library(leaflet.extras)
library(sp)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
#library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
library(tidyr)
#library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(stringr)
require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
#library(rintrojs)       # Presentación de ayuda en pantalla
library(openxlsx)





source("helpers.R")
source("../_shared/_filtros.R")
#reactlog_enable()

# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}

# Calcular promedio de consumo últimos 6 meses a partir de vector consumos -----
promedio_consumo_6m <- function(csm) {
  lz <- length(csm)
  if (lz >= 6  ) {
    return (mean(csm[-1:-(lz-6)]))
  } else {
    return (NA)
  }
}

# extraer vector consumos últimos 12 meses -----------------------------------
consumo_12m <- function(csm) {
  lz <- length(csm)
  if (lz >= 12  ) {
    return (paste0(csm[-1:-(lz-12)],collapse = ','))
  } else {
    return (csm)
  }
}

# Retornar tabla para despliegue ---------------------------------------------
tabla.despliegue <- function(tabla.temp, obj) {

  if(nrow(obj)!=0 ) {
    b1 <- tabla.temp %>% filter(CodigoPuntoConsumo %in% obj$CodigoPuntoConsumo)
    if (nrow(obj)== nrow(b1)){
      obj[,1] <- b1[,1]}
    tabla.temp <- obj
  }
  
  tabla.temp$Nombre_corto_SMT <- paste0(tabla.temp$CodigoCircuito, " ",tabla.temp$Nombre_corto_SMT)
  #tabla.temp[is.na(tabla.temp$Nombre_corto_SMT),]$NombreCircuito <- "N/A"

  renderDT(
    valores_tabla$Data,
    server = TRUE,
    #filter = 'top',
    class="compact",
    extensions = list("Buttons" = TRUE,
                      "ColReorder" = NULL,
                      "FixedColumns" = list(leftColumns=3)),
    #colnames = c('Código'= 2, 'Nombre'= 19),
    selection = 'multiple',
    options = list(
      scrollX = TRUE,
      scrollY = 460,
      scroller = TRUE,
      fixedColumns = list(leftColumns = 3),
      buttons = c('excel')
    ),
    escape = F
  )
  # rhandsontable(tabla.temp[,1:15],
  #               rowHeaders = TRUE,
  #               colHeaders = c(
  #                 '°',
  #                 'Código',
  #                 'Nombre',
  #                 'Dirección',
  #                 'Actividad',
  #                 'Ceros consecutivos',
  #                 'Prom. 6 mss ant. [kWh]',
  #                 'Zona',
  #                 'Región',
  #                 'Oficina',
  #                 'Itinerario',
  #                 'Departamento',
  #                 'Municipio',
  #                 'Localidad',
  #                 'Circuito'
  #               ),
  #               height =380,
  #               search = FALSE,
  #               readOnly = TRUE,
  #               selectCallback = TRUE)%>%
  #   hot_col(1, halign = "htCenter", readOnly = FALSE) %>%
  #   hot_col(2, renderer = "html",halign = "htRight") %>%                # Mostrar como hipervínculo
  #   hot_col(2, renderer = htmlwidgets::JS("safeHtmlRenderer")) %>%      # Mostrar como hipervínculo
  #   hot_cols(fixedColumnsLeft=2) %>%
  #   hot_col(7,format="#.00", halign="htRight" ) %>%
  #   hot_heatmap(7, color_scale =c("#17F556", "#ED6D47")) %>%  # Habilitar escala de color
  #   hot_cols(columnSorting = TRUE)  %>%
  #   hot_context_menu(allowRowEdit = FALSE, allowColEdit = FALSE) %>%    # Bloquea opciones de menú contextual
  #   hot_table(highlightCol = TRUE, highlightRow = TRUE)                 # Resalta fila y columna seleccionada
  
}

# Retornar mapa para despliegue --------------------------------------------
# mapa.despliegue<- function(tabla.temp, obj, datos.consulta, banderaRefresco,tabla.datos.valida, input) { #} datos.imagen, input) { 
#   
#   if (tabla.datos.valida) {
#     tabla.temp <-  hot_to_r(input$datos)
#     ordenes <- subset(tabla.temp, tabla.temp[,1] == TRUE)[,-1]
#   } else if(nrow(obj)!=0) {
#     ordenes <- obj
#   } else {
#     ordenes <- subset(tabla.temp, tabla.temp[,1] == TRUE)[,-1]
#   }
#   
#   
#   for(i in 1:nrow(ordenes)){                                      # Extrae el número de cliente del hipervínculo
#     pos.cliente <- gregexpr(">",ordenes$CodigoPuntoConsumo[i])
#     pos.cliente <- pos.cliente[[1]][1] + 1
#     fin.cad <- nchar(ordenes$CodigoPuntoConsumo[i]) - 4
#     ordenes$CodigoPuntoConsumo[i] <- substr(ordenes$CodigoPuntoConsumo[i],pos.cliente,fin.cad)
#   }
#   ordenes$CodigoPuntoConsumo <- unlist(ordenes$CodigoPuntoConsumo)
#   
#   datos<-left_join(ordenes,datos.consulta,by = "CodigoPuntoConsumo") # Efectua unión para traer coordenadas
#   datos.consulta$PromedioActiva6CN<-as.numeric(as.character(datos.consulta$PromedioActiva6CN))  # Convierte a numérico
#   datos.consulta$PromedioActiva6CN[is.na(datos.consulta$PromedioActiva6CN)]=0                  # Ajuste de valores nulos
#   datos$LatitudPuntoConsumo <-as.numeric(as.character(datos$LatitudPuntoConsumo))
#   datos$LongitudPuntoConsumo <-as.numeric(as.character(datos$LongitudPuntoConsumo))
#   
#   
#   if (banderaRefresco) {
#     google_map_update(map_id = "map") %>%
#       clear_markers() %>%
#       googleway::add_markers(data = datos,lat = "LatitudPuntoConsumo", lon = "LongitudPuntoConsumo", 
#                              info_window = "Texto1",close_info_window = TRUE)
#     #info_window = "texto",close_info_window = TRUE)
#   } else {
#     google_map(key = api_key, data = datos, style=estilo.map01) %>%
#       googleway::add_markers(lat = "LatitudPuntoConsumo", lon = "LongitudPuntoConsumo", 
#                              info_window = "Texto1",close_info_window = TRUE)
#     #  info_window = "texto",close_info_window = TRUE)
#   }
# }


# Configuración de bd y código para api google --------------------------------------------------------------
configuracion.conexion <<- 'externalENERG' # Sys.getenv("CONEXIONSHINY") #'windows', 'externalENERG' para energuate
#  'GoogleKey' CodigoParametro api google en [DWSRBI_ENERGUATE].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "SELECT TOP 1 ValorParametro FROM [DWSRBI_ENERGUATE].[Aux].[Parametros] where EstadoParametro = 1 AND   CodigoParametro = 'GoogleKey'"
api_key <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)
api_key <<- api_key[1,1]


# Contadores y llamadas --------------------------------------------------------------
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante
#api_key <- "AIzaSyAYoARt3zU_arrmeiZmMCjXhLEyRoE7Z2Q"  # Solicitar clave a WM y cambiar
Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')
locale <- Sys.getlocale(category="LC_COLLATE")
if (grepl("Spanish", locale, fixed=TRUE)) {
  separador.csv <<- ';'
} else {
  separador.csv <<- ','
}

# Captura de parámetro para URL servidor shiny -------------
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql<- "SELECT [ValorParametro]  FROM [DWSRBI_ENERGUATE].[Aux].[Parametros]  WHERE [CodigoParametro] = 'URLshiny'"
URL.servidor.shiny <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
URL.servidor.shiny <- URL.servidor.shiny [1,1]
str.http <<- paste(URL.servidor.shiny,"hvurl/?Codigo=",sep="") # Cadena de llamada para vinculo a hoja de vida




# Captura de campañas disponibles en BD -----------------------------------
cad.sql<- "[dbo].[Leer_Campanas1]"
nom.camp <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom.camp)<-"Nombre"
nom.camp <- nom.camp  %>% filter(!is.na(Nombre))

cad.sql<- "[dbo].[Lista_extremos_geografia]"
datos.geo <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)


datos.geo <- data.frame(LongitudPuntoConsumo=as.numeric(datos.geo$avgLong),
                        LatitudPuntoConsumo=as.numeric(datos.geo$avgLat))
coordinates <- SpatialPointsDataFrame(datos.geo[,c("LongitudPuntoConsumo","LatitudPuntoConsumo")],datos.geo)

# cad.sql <- "SELECT DISTINCT [NombreServicio] FROM [Dimension].[Servicio] where codigoservicio <> 0  ORDER BY [NombreServicio]"
# nom_servicios <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
# colnames(nom_servicios) <- "Nombre"
# nom_servicios <- nom_servicios   %>% filter(!is.na(Nombre))
# nom_servicios <- c("G. clientes", "PIMT", "Masivos", "Consumos fijos", "Autoproductores")

# Consultar datos de filtros
consultarDatosFiltros(conexion)

# Carga contenido filtros
cargarFiltrosIniciales()

odbcClose(conexion)

# UI ----------------------------------------------------------------------
# ref https://stackoverflow.com/questions/31440564/adding-a-company-logo-to-shinydashboard-header

# font negro para pickerinput
col_list2 <- c("black")
colorspi <- paste0("color:",rep(c('black'),each=10),";")

dbHeader <- dashboardHeader()
dbHeader <- dashboardHeader(title = "Consumo georeferenciado",
                            tags$li(div(
                              img(src = 'Kronos.png',
                                  title = "Consumo georeferenciado", height = "30px"),
                              style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                              class = "dropdown"),
                            dropdownMenuOutput("MensajeOrdenes"),  # Presenta mensajes en barra de encabezado)
                            dropdownMenuOutput("MensajeCarga"),  # Presenta mensajes de carga externa en barra de encabezado
                            dropdownMenuOutput("MensajeMapa") )     # Presenta mensajes en barra de encabezado  

ui = dashboardPage(
  # evento para capturar uso de column sort en tabla
  # url: https://stackoverflow.com/questions/36176298/preserve-row-order-of-rhandsontable-in-shiny-app
  

  dbHeader,
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 500,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   #introjsUI(),   # Se habilita presentación de ayuda
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   fluidRow( column(width = 6,offset = 0, style='padding:0px;',
                                    box(id = "Comandos", width = 12, 
                                        status = NULL,  
                                        background = "black",
                                        fluidRow( 
                                          column(width = 2,offset = 1,
                                                 actionButton("ReiniciarControles", label = icon("fas fa-sync"),
                                                              style="color: #fff; background-color: #0070ba; border-color: #0070ba"),
                                                 bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                                          ),
                                          column(width = 2,
                                                 offset = 1,
                                                 actionButton("TraerDatos", label = icon("fas fa-play"),
                                                              style="color: #fff; background-color: #0070ba; border-color: #0070ba"), 
                                                 bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                                          ),
                                          # Botón usado para manejar evento de borrado de geocerca. 
                                          # Invisible en interfaz de usuarios (escondido al comenzar server).
                                          # No borrar.
                                          column(width = 1, offset = 2,  
                                                 actionButton("Consulta", "Activado automáticamente"),
                                                 style="color: #fff; background-color: #00828f; border-color: #00828f")
                                        
                                        )
                                        
                                    ),
                                    
                                    # box(id = "Contadores", width = 12, status = NULL,  background = "black",
                                    #     
                                    #     sliderInput(inputId="mesesRevisar",
                                    #                 label="Meses de historia a revisar",
                                    #                 min=1,max=8 ,
                                    #                 value=2,
                                    #                 step=1,round=TRUE),
                                    #     bsTooltip("mesesRevisar", "Meses de historia a revisar por consumos cero",
                                    #               placement = "bottom", trigger = "hover", options = NULL)
                                    # ),
                                    
                                    obtenerFiltrosZona(),
                                    obtenerFiltrosDepartamento()
                   ),
                   column(width = 6, offset = 0, style='padding:0px;',
                          obtenerFiltrosEmpresa()
                   ))
  ),
  
  # Body --------------------------------------------------------------------
  ##00828F;
  dashboardBody(    
    tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }
                              .dataTables_wrapper .dataTables_scroll div.dataTables_scrollBody>table>tbody>tr>td {
                                white-space: nowrap;
                              }'
                              
    )
    )
    ), # Fin estilo
    
    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel( type = "tabs", 
                 tabPanel("Mapa",
                          icon = icon("fas fa-map-marker-alt"), #icon = icon("fas fa-map-marker-alt"),
                          hr(),
                          fluidRow(column(width = 2,
                                          offset = 10,
                                          materialSwitch(inputId = "switch.calor", 
                                                         label = "Mapa de calor", 
                                                         status = "danger", 
                                                         inline =  FALSE)
                          )),
                          hr(),
                          leafletOutput("mymap",  height = 600),
                                      
                         useShinyjs()),
                 
                 # tabPanel("Gráfica", icon = icon("fas fa-chart-line"),
                 #          hr(),
                 #          box(
                 #            width = 12,
                 #            status = "warning",
                 #            solidHeader = FALSE,
                 #            title = "Consumos georeferenciados",
                 #            fluidRow(column(width = 2,
                 #                            offset = 10,
                 #                            materialSwitch('selec.graf', 
                 #                                           label = "Puntos / Barras", 
                 #                                           value = FALSE, 
                 #                                           inline =  FALSE),
                 #                            bsTooltip("selec.graf", "Presentar en gráfica de puntos / barras", 
                 #                                      placement = "bottom", trigger = "hover", options = NULL)
                 #            )),
                 #            hr(),
                 #            
                 #            #withSpinner(                                                        # Incluir spinner de espera
                 #            plotlyOutput("plot",height = "550px"), # height = "500px"), #,brush = brushOpts("b1")),                 
                 #            #  color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                 #            #),
                 #            
                 #            useShinyjs(),
                 #            # code to reset plotlys event_data("plotly_click", source="A") to NULL -> executed upon action button click
                 #            # note that "A" needs to be replaced with plotly source string if used
                 #            extendShinyjs(text = "shinyjs.resetGraph = function() { Shiny.onInputChange('.clientValue-plotly_selected-master', 'null'); }",
                 #                          functions=c("resetGraph"))   
                 #          )),              
                 tabPanel("Datos",
                          icon = icon("fas fa-table"),
                          hr(),
                          
                          fluidRow( 
                            box(#height = 420,
                              width = 12,
                              status = "warning",
                              solidHeader = FALSE,
                              title = "Consumos georeferenciados",
                              # radioButtons(inputId = "selec.tod", 
                              #              label = "Seleccionar datos:", 
                              #              choices = c("Todos", "Ninguno"),                                  
                              #              inline = TRUE
                              # ),
                              # bsTooltip("selec.tod", "Seleccionar todos / ninguno", 
                              #           placement = "bottom", trigger = "hover", options = NULL),
                              
                              
                              br(),
                              withSpinner(DT::dataTableOutput("tbl", height = "200px"))
                              # withSpinner(rHandsontableOutput("datos", height = "600px"),         # Incluir spinner de espera
                              #             color = getOption("spinner.color", default = "#0070ba") # Se definen colores del spinner
                              #)
                              
                            )),
                          hr(),
                          fluidRow(column(width=12,
                                          plotlyOutput("plotSeries", height = "200px"))),
                          fluidRow(hr() ,      
                                   
                                   column(width = 2,
                                          actionButton("MostrarTabla",   # Se crea el botón deshabilitado para que
                                                       "Actualizar tabla"    # sea habilitado posteriormente por código
                                          )),
                                   column(width = 2,
                                          offset = 6,
                                          shinyjs::disabled(downloadButton('Descargar', 'Descargar excel',
                                                                           style="color: #fff; background-color: #0070ba; border-color: #0070ba"),  # Se crea el botón deshabilitado para que
                                                            bsTooltip("Descargar", "Descargar registros en archivo excel", 
                                                                      placement = "bottom", trigger = "hover", options = NULL)
                                          )                                           # sea habilitado posteriormente por código
                                          
                                   ),
                                   column(width = 2,
                                          shinyjs::disabled(  # Se crea el botón deshabilitado para que
                                            actionButton("Guardar",   
                                                         "Generar órdenes",   
                                                         icon = icon("fas fa-save"),
                                                         style="color: #fff; background-color: #0070ba; border-color: #0070ba"
                                            ),
                                            bsTooltip("Guardar", "Crear órdenes de inspección para usuarios seleccionados", 
                                                      placement = "bottom", trigger = "hover", options = NULL)
                                          )
                                   )
                          ),
                          textOutput("LlavePC"),
                          tags$head(tags$style("#LlavePC{color: white;
                                 font-size: 20px;
                                 font-style: italic;
                                 }"
                          )
                          )                         
                 ),
                 tabPanel("Ayuda",
                          icon = icon("fas fa-table"),
                          includeMarkdown("AyudaGeoreferenciados.Rmd")
                          
                 ),
                 
                 
                 
                 id="TabsApp"
    )
  )
 
  
)

# Server ------------------------------------------------------------------

server <- shinyServer(function(input, output, session) { # Importante iniciar con shinyServer para que funcione la ayuda
  
  consulta.activa <<- FALSE
  datos.consulta <- NA
  tipo.grafica <- 'P'
  tabla.datos.valida <- FALSE
  valores_validos_zona <<- NA
  valores_validos_region <<- NA
  valores_validos_centro <<- NA
  valores_validos_Geografia_departamento  <<- NA
  valores_validos_Geografia_municipio <<- NA
  
  valores_validos_estado <<- NA
  valores_validos_tarifa <<- NA
  valores_validos_mercado <<- NA
  
  valores_tabla<-reactiveValues()
  valores_tabla$Data<-NA
  puntos_seleccionados <- reactiveValues()
  puntos_seleccionados$Datos <- NA
  
  # Ocultar Botones auxiliares para sincronizar paneles, paneles
  shinyjs::hide("Consulta")
  shinyjs::hide("MostrarTabla")
  shinyjs::hide("MostrarMapa")
  
  
  
  
  # Ayuda -------------------------------------------------------------------
  
  
  # Cambio de tab ----------------------------------------------------------------------
  observeEvent(input$TabsApp, {
    
    if (input$TabsApp == "Datos") {
      tabla.datos.valida <<- TRUE
    } else if (input$TabsApp == "Mapa") {
      click("MostrarMapa")
    }
  }, ignoreInit = TRUE)
  
  
  # Seleccion de fila en tabla de datos --------------------------------------------------
  observeEvent(
    input$datos_sort
    ,{
      
      xyz <<- input$datos_sort$data
    }
  )
  
  output$LlavePC <- renderPrint({
    observeEvent(input$btnDetalleTabla, {
      # probar si valor de fila seleccionada está disponible
      ttable <- hot_to_r(input$datos) 
      # obtener código de usuario en la fila seleccionada
      codigo = input$btnDetalleTabla
      codigo.usuario <- codigo
      datos.usuario <- datos.consulta[datos.consulta$CodigoPuntoConsumo == codigo.usuario,]
      
      #Obtener llavePuntoConsumo para el código, y traer datos de serie
      
      conexion <- odbcDriverConnect (config.conexion)
      cad.sql <- paste0( "EXEC [dbo].[Dataset_ConsumoNormalizado_shiny] @CodigoServicio = ", codigo.usuario)
      datos_consumo <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      odbcClose(conexion)
      datos_consumo$ConsumoNormalizado <- gsub('-1','',datos_consumo$ConsumoNormalizado)
      
      zz <- data.frame(strsplit(datos_consumo$ConsumoNormalizado,','))
      tryCatch({
        names(zz) <- c('col1')
        yy <- as.numeric(zz$col1)
        anno <- 2018
        periodo <- 201801
        mes <- 1
        seqdate <- seq(1,length(yy))
        for (i in 1:length(yy)) {
          if (mes %% 13 == 0) {
            mes <- 1
            anno <- anno + 1
            periodo = (anno * 100) + 1
          }
          seqdate[[i]] <- periodo + mes - 1
          mes <- mes + 1
        }
        
        
        vc_consumo <- round(yy, digits = 2)
        vc_meses <-  as.Date(paste0(seqdate,"01"),"%Y%m%d" )
        df_consumo <- data.frame(vc_meses, vc_consumo)
        nfiles <- nrow(df_consumo)
        sf <- seq.Date(from = df_consumo$vc_meses[1], by = "months", length.out = nfiles)
        df_consumo$vc_meses <- sf
        
        p <- plot_ly()
        
        p <- p %>% add_trace(x = df_consumo[["vc_meses"]], y = df_consumo[["vc_consumo"]], name = "Consumo",
                            type = 'scatter',
                            mode = 'lines',
                            line = list(color = 'rgb(0, 112, 186)', width = 3))%>%
          layout(#title = "Consumo",
            title = paste0("Punto de consumo ", codigo.usuario),
            xaxis = list(title = "Periodo", dtick = "M1",tickangle = 270),
            yaxis = list (title = "Consumo kWh"),
            font = list(color = "#0070ba"))
        
        
        p <- p %>% layout(showlegend = FALSE)
        output$plotSeries <- renderPlotly({p})
      }, error = function(e) {
        showModal(modalDialog(
          title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
          "No se encontraron datos para generar la gráfica",
          footer = list(modalButton("OK", icon = icon("fas fa-check"))
          ),
          easyClose =TRUE
        ))
      })
      
    })  
  })
  
  # Carga de datos a listas desplegables
  manejarEventosFiltros(input, output, session)
  
  # Reinicial controles
  manejarReinicioFiltros(input, output, session)
  
  # Hacer consulta basada en valores de filtros  ---------------------------
  observeEvent(input$TraerDatos, {
    noHayValores <- FALSE
    # meses_busqueda <- input$mesesRevisar
    # fecha_minimo <- today() %m-% months(meses_busqueda)
    # fecha_minimo <- paste0(substring(fecha_minimo,1,4),substring(fecha_minimo,6,7),"01")
    # condiciones_consulta = paste0(" LlaveFecha >= ", fecha_minimo, " ")
    condiciones_consulta = ""
    
    # Construir condiciones de consulta:
    if(!is.null(input$zona_comercial)){
      # if (seleccion_operativa != "no") {
      #   if (nrow(valores_validos) == 0) {
      #     noHayValores <- TRUE
      #   } else { 
          
          #f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos[c("LlaveZona")]), collapse=",")),1,stop =1000000L)
          valores_validos <- consulta_zona(seleccion_operativa, valores_ZonaOperativa,input)
          
          f1 <- t(unique(valores_validos[c("LlaveZona")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos[c("LlaveZona")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " Llavezona IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      #   }
      # }
    }

    if(!is.null(input$region)){
      # if (seleccion_geografia != "no") {
      #   if (nrow(valores_validos_Geografia) == 0) {
      #     noHayValores <- TRUE
      #   } else {
          #f1 <- substr(gsub("[\r751:\n]", "",paste0(unique(valores_validos_Geografia[c("LlaveGeografia")]), collapse=",")),1,stop =1000000L)
          valores_validos_Geografia <- consulta_geografia(seleccion_geografia, valores_Geografia,input)
          f1 <- t(unique(valores_validos_Geografia[c("LlaveGeografia")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_Geografia[c("LlaveGeografia")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          conector <- " "
          if (nchar(condiciones_consulta) > 1)  {
            conector <- " AND "
          }
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta, conector,
                                                           " LlaveGeografia IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      #   }
      # }
    }
    
    if(!is.null(input$circuitos)){
      # if (seleccion_circuito != "no") {
      #   if (nrow(valores_validos_circuitos) == 0) {
      #     noHayValores <- TRUE
      #   } else {
          f1 <- t(unique(valores_validos_circuitos[c("LlaveCircuito")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_circuitos[c("LlaveCircuito")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          conector <- " "
          if (nchar(condiciones_consulta) > 1)  {
            conector <- " AND "
          }
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " LlaveCircuito IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      #   }
      # }
    }
    
    if (seleccion_iniciativa  != 'no') {
      if (nrow(valores_validos_iniciativa) == 0 ) {
        noHayValores <- TRUE
      }
    }
    
    c1 <- ''
    c2 <- ''
    
    if(!is.null(input$cnae)){
      # if (seleccion_CNAE != 'no') {
      #   if (nrow(valores_validos_cnae_division) == 0) {
      #     noHayValores <- TRUE
      #   } else {
          f1 <- t(unique(valores_validos_cnae_division[c("LlaveActividadEconomica")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_cnae_division[c("LlaveActividadEconomica")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          c1 <- str_replace(f1, "[)]", "")

          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND LlaveActividadEconomica IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      #   }
      # }
    }
    
    if(!is.null(input$cnaegrupo)){
      # if (seleccion_grupo != 'no') {
      #   if (nrow(valores_validos_CNAEgrupo) == 0) {
      #     noHayValores <- TRUE
      #   } else {
          f1 <- t(unique(valores_validos_CNAEgrupo[c("LlaveActividadEconomica")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          f1 <- paste0(gsub(":",",",unique(valores_validos_CNAEgrupo[c("LlaveActividadEconomica")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          c2 <- str_replace(f1, "[)]", "")
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND LlaveActividadEconomica IN ( ",substr(f1,1,stop =1000000L)," ) ") )
      #   }
      # }
    }
    
    if(!is.null(input$cnaegrupo)){
      # Unificar seleccion_CNAE y seleccion_grupo
      if (seleccion_CNAE != 'no' && seleccion_grupo != 'no') {
        condiciones_CNAE <- gsub("[\r\n]", "",substr(c1,1,stop =1000000L),  
                                 ",",substr(c2,1,stop =1000000L) )
        condiciones_consulta <- paste0(condiciones_consulta,
                                       " AND LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
      } else if (seleccion_CNAE != 'no' ) {
        condiciones_CNAE <- gsub("[\r\n]", "",substr(c1,1,stop =1000000L) )
        conector <- " "
        if (nchar(condiciones_consulta) > 1)  {
          conector <- " AND "
        }
        condiciones_consulta <- paste0(condiciones_consulta, conector,
                                       " LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
        
        
      } else if (seleccion_grupo != 'no') {
        condiciones_CNAE<- gsub("[\r\n]", "",substr(c2,1,stop =1000000L) )
        conector <- " "
        if (nchar(condiciones_consulta) > 1)  {
          conector <- " AND "
        }
        condiciones_consulta <- paste0(condiciones_consulta, conector,
                                       " LlaveActividadEconomica IN ( ",condiciones_CNAE," ) ")
      }
    }
    
    if(!is.null(input$estado)){
      if (seleccion_estado != 'no') {
        ifelse (is.na(valores_validos_estado),
                {
                  lista_seleccion <- input$estado
                  valores_validos_estado <<- valores_Estados %>%
                    filter(valores_Estados$NombreEstado %in% lista_seleccion)
                },NA)
        if (nrow(valores_validos_estado) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_estado[c("LlaveEstado")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tension[c("Llavetension")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          conector <- " "
          if (nchar(condiciones_consulta) > 1)  {
            conector <- " AND "
          }
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta, conector,
          #                                                  " LlaveEstrato IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$tension)){
      if (seleccion_tension != 'no') {
        if (nrow(valores_validos_tension) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_tension[c("Llavetension")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tension[c("Llavetension")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          conector <- " "
          if (nchar(condiciones_consulta) > 1)  {
            conector <- " AND "
          }
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta, conector, 
                                                           " LlaveTension IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$tarifa)){
      if (seleccion_tarifa != 'no') {
        ifelse (is.na(valores_validos_tarifa),
                {
                  lista_seleccion <- input$tarifa
                  valores_validos_tarifa <<- valores_Tarifa %>%
                    filter(valores_Tarifa$NombreTarifa %in% lista_seleccion)
                } , NA) 
        if (nrow(valores_validos_tarifa) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_tarifa[c("LlaveTarifa")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_tarifa[c("LlaveTarifa")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          conector <- " "
          if (nchar(condiciones_consulta) > 1)  {
            conector <- " AND "
          }
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta, conector, 
                                                           " LlaveTarifa IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$mercado)){
      if (seleccion_mercado != 'no') {
        ifelse (is.na(valores_validos_mercado),
                {
                  lista_seleccion <- input$mercado
                  valores_validos_mercado <<- valores_Mercado  %>%
                    filter(valores_Mercado$NombreMercado %in% lista_seleccion)
                } , NA) 
        if (nrow(valores_validos_mercado) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_mercado[c("LlaveMercado")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_mercado[c("LlaveMercado")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          conector <- " "
          if (nchar(condiciones_consulta) > 1)  {
            conector <- " AND "
          }
           condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta, conector,
                                                            "  LlaveTipoObjeto IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$pimt)){
      if (seleccion_PIMT != 'no') {
        if (nrow(valores_validos_PIMT) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_PIMT[c("LlavePIMT")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos_PIMT[c("LlavePIMT")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          conector <- " "
          if (nchar(condiciones_consulta) > 1)  {
            conector <- " AND "
          }
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta, conector,
                                                           "  LlavePIMT IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    if(!is.null(input$ynormalizacion)){
      if (seleccion_ynormalizacion != 'no') {
        if (nrow(valores_validos_ynormalizacion) == 0) {
          noHayValores <- TRUE
        } else {
          f1 <- t(unique(valores_validos_ynormalizacion[c("Llaveynormalizacion")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          f1 <- paste0(gsub(":",",",unique(valores_validos_ynormalizacion[c("Llaveynormalizacion")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          conector <- " "
          if (nchar(condiciones_consulta) > 1)  {
            conector <- " AND "
          }
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta, conector,
                                                           " Llaveynormalizacion IN ( ",substr(f1,1,stop =1000000L)," ) ") )
        }
      }
    }
    
    # traer valores de ceros
    ####
    ####
    ####
    ####  llaveestrato está bloqueado (no hay valores en hecho.llaves)
    
    if (noHayValores) {
      showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        
        "La consulta no genera resultados",
        footer = list(modalButton("Cancelar", icon = icon("fas fa-table"))
        ),
        easyClose =TRUE
      )
      )
    }  else { 
    
      disable("ReiniciarControles")  
      disable("TraerDatos")
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      cad.sql<-"EXEC [dbo].[Dataset_MapaConsumo_shiny]"
      cad.sql<-paste (cad.sql,"  @CONDICION = ? ")
      parametros<- data.frame( condiciones_consulta)
      datos.consulta <-sqlExecute(channel = conexion, query = cad.sql, data = parametros,fetch= T,as.is=T)
      
      odbcClose(conexion)

      if (nrow(datos.consulta ) > 0) {
        tabla.datos.valida <<- FALSE
        csm <- datos.consulta$ConsumoNormalizado
        x1 <- strsplit(csm,',')
        x2 <-  lapply(x1, consumo_12m)
        xn <- lapply(x1, as.numeric)
        z1 <- lapply(xn,promedio_consumo_6m)
        datos.consulta$PromedioActiva6CN <- z1
        datos.consulta$Consumo12 <- x2
        
        datos.consulta <- as.data.frame(datos.consulta,stringsAsFactors=FALSE)
        #datos.consulta$PromedioActiva6CN<-as.numeric(as.character(datos.consulta$PromedioActiva6CN))  # Convierte a numérico
        datos.consulta$PromedioActiva6CN[is.na(datos.consulta$PromedioActiva6CN)]=0                  # Ajuste de valores nulos
        
        #valores_tabla<-reactiveValues()
        valores_tabla$Data<-data.frame(
          Grafica= paste0("<button class='btn btn-default action-button btn-light action_button' id='",datos.consulta$CodigoPuntoConsumo,"' type='button' onmousedown='event.preventDefault(); event.stopPropagation(); return false;' onclick='Shiny.onInputChange(\"btnDetalleTabla\", this.id)'><i class='fas fa-chart-line'></i></button>"),
          Código=datos.consulta$CodigoPuntoConsumo,
          Nombre=datos.consulta$NombreCliente,
          Dirección=datos.consulta$DireccionPuntoConsumo,
          Actividad=paste0(datos.consulta$Seccion," ",datos.consulta$grupo),
          PromedioActiva6CN = round(as.numeric(datos.consulta$PromedioActiva6CN), digits = 2),
          Zona= datos.consulta$NombreZona,
          Región = datos.consulta$NombreRegion,
          Oficina = datos.consulta$NombreOficina,
          Itinerario = datos.consulta$Itinerario,
          Departamento = datos.consulta$NombreDepartamentoGeografia,
          Municipio = datos.consulta$NombreMunicipioGeografia,
          Localidad = datos.consulta$NombreLocalidadZonaGeografia,
          Circuito = paste0(datos.consulta$CodigoCircuito," ",datos.consulta$Nombre_corto_SMT)
        )
        
        shinyjs::enable("Guardar")                                   # Habilita el botón para guardar
        shinyjs::enable("Descargar")
        # Armar tabla de datos para despliegue
        datos.consulta$texto <- paste0(" Codigo : ",                                           # Campo de texto a presentar en tooltip de los puntos
                                       datos.consulta$CodigoPuntoConsumo,
                                       " \n ",                                                 # Se incluye salto de línea
                                       "NIS: ",
                                       datos.consulta$NombreCliente,
                                       " \n ",
                                       "Dir: ",
                                       datos.consulta$DireccionPuntoConsumo #,
                                       # " \n " ,
                                       # "Ultima inspeccion: ",
                                       # datos.consulta$LlaveFechaEjecucion
        )
        
        #datos.consulta$DetalleGrafica <- paste0("<button class='btn btn-default action-button btn-light action_button' id='",datos.consulta$CodigoPuntoConsumo,"' type='button' onmousedown='event.preventDefault(); event.stopPropagation(); return false;' onclick='Shiny.onInputChange(\"btnDetalleTabla\", this.id)'><i class='fas fa-chart-line'></i></button>")
        
        #datos.imagen$image <- lapply(datos.imagen$image, aCode64)
        
        consumos.numericos <-sapply(datos.consulta$Consumo12,function(x) sapply(strsplit(x,','), as.numeric))
        for (i in 1:nrow(datos.consulta)) {
          datos.consulta$Consumo12[i] <- texto.popup(unlist(consumos.numericos[i]))
        }
        
        output$tbl = renderDT(
          valores_tabla$Data,
          server = TRUE,
          #filter = 'top',
          class="compact",
          extensions = list("Buttons" = TRUE,
                            "ColReorder" = NULL,
                            "FixedColumns" = list(leftColumns=3)),
          #colnames = c('Código'= 2, 'Nombre'= 19),
          selection = 'multiple',
          options = list(
            scrollX = TRUE,
            scrollY = 460,
            scroller = TRUE,
            fixedColumns = list(leftColumns = 3),
            buttons = c('excel')
          ),
          escape = F
        )
        

        tabla.datos<- datos.consulta  %>% select(CodigoPuntoConsumo, NombreCliente
                                                 ,DireccionPuntoConsumo, Seccion
                                                 , PromedioActiva6CN
                                                 , NombreZona, NombreRegion, NombreOficina,Itinerario
                                                 ,NombreDepartamentoGeografia, NombreMunicipioGeografia, NombreLocalidadZonaGeografia
                                                 ,Nombre_corto_SMT,  CodigoCircuito
                                                 ,  texto)
        
        datos.consulta <<- datos.consulta
        #datos.imagen <<- datos.imagen
        
        # for (i in 1:nrow(tabla.datos)){      # Crea los tags para el hipervínculo de num. de cliente
        #   tabla.datos$CodigoPuntoConsumo[i] <- tagList(as.character(a(as.character(tabla.datos$CodigoPuntoConsumo[i]), 
        #                                                               href = paste(str.http,tabla.datos$CodigoPuntoConsumo[i], sep=""))))
        # }
        
        tabla.datos <- cbind("°" = TRUE, tabla.datos)
        tabla.datos <<- tabla.datos
  
        # Cargar datos mapa
        output$mymap <- renderLeaflet({
        
        # Mensaje con conteo de datos sin geografía
        datos.recibidos <- nrow(datos.consulta)
        datos.sin.geografia <- 
          nrow(datos.consulta[is.na(datos.consulta$LatitudPuntoConsumo)  | is.na(datos.consulta$LongitudPuntoConsumo),])
        output$MensajeCarga <- renderMenu({   # Actualiza mensaje en la barra de menú para registros cargados
          
          dropdownMenu(type = "notifications",  # Mensaje en barra de encabezado para indicar registros sin geografia
                       headerText = "Tiene una notificación",
                       icon =icon("fas fa-comments"), 
                       notificationItem(
                         text = paste(datos.recibidos, "líneas traídas. ", 
                                      datos.sin.geografia, "sin información geográfica."),
                         icon("fas fa-gavel") 
                       )
          )
        })
        
        
        # Preparar datos para mapa
        
        datos.consulta <- datos.consulta[!is.na(datos.consulta$LatitudPuntoConsumo) & !is.na(datos.consulta$LongitudPuntoConsumo),]
        datos.consulta$LatitudPuntoConsumo <- as.numeric(as.character(datos.consulta$LatitudPuntoConsumo))
        datos.consulta$LongitudPuntoConsumo <- as.numeric(as.character(datos.consulta$LongitudPuntoConsumo))
        datos.consulta$fechaUltimaInspeccion <- lapply(datos.consulta$fechaUltimaInspeccion, fLlaveFecha)
        datos.consulta$PromedioActiva6CN<- lapply(datos.consulta$PromedioActiva6CN,
                                                     function(x) {trunc(as.numeric(x)*10)/10})
        #
        # html para popup de mapa
        datos.consulta$Texto <- paste0(
          "<p></p>",
          "<table border= '0' style= 'height: 120px; width: 100%; border-collapse: collapse;'>",
          "<tbody>",
          "<tr style='height: 20px;'>",
          
          "<td style='width: 35%; height: 20px; background-color: #f0f2f2;'><strong><span style='color: #00828F;'>Cliente:&nbsp;",
          #"<td style='width: 65%; height: 20px; background-color: #f0f2f2; text-align: right;'><strong><span style='color: #00828F;'>",
          # "<a href='",paste(str.http,datos.consulta$CodigoPuntoConsumo, sep=""),
          # "' target='_blank' rel='noopener'>",datos.consulta$CodigoPuntoConsumo,"</a>",
          # "</span></strong></td>",
          "<td style='width: 65%; height: 20px;'>",datos.consulta$CodigoPuntoConsumo,"</td>",
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px; vertical-align: top;'>Nombre:</td>",
          "<td style='width: 65%; height: 20px;'>",datos.consulta$NombreCliente,"</td>",
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px; vertical-align: top;'>Actividad:</td>",
          "<td style='width: 65%; height: 20px;'>",datos.consulta$Seccion,"</td>",
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px;'>Cons. Prom.:</td>",
          "<td style='width: 65%; height: 20px; text-align: right;'>",datos.consulta$PromedioActiva6CN," [kWh]</td>",
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px;'>Ultima inspección:</td>",
          "<td style='width: 65%; height: 20px; text-align: right;'>",datos.consulta$fechaUltimaInspeccion,"</td>",
          "</tr>",
          "<tr style='height: 20px;'>",
          "<td style='width: 35%; height: 20px;'>Perfil de consumo:</td>",
          "<td style='width: 65%; text-align: right; height: 20px;'>",
          "<svg xmlns='http://www.w3.org/2000/svg'",
          "xmlns:xlink='http://www.w3.org/1999/xlink' width='100' height='50' viewBox='0 0 100 50'>",
          datos.consulta$Consumo12,
          "</svg>",
          "</td>",
          "</tr>",
          "</tbody>",
          "</table>"             # Ajuste valores cero
        )
       
        datos.consulta$COD_CLIE2 <- paste0(as.character(datos.consulta$CodigoPuntoConsumo),"_selectedLayer")
        datos.consulta <- datos.consulta %>% replace_na(list(Nombrecliente = '-', DireccionPuntoConsumo = '-',
                                                           NombreCircuito = '-', NombreEstrato = '-',
                                                           Actividad = '-',PromedioActiva6CN = '0', fechaUltimaInspeccion = '-'))
        datos.geo <<- datos.consulta[complete.cases(datos.consulta[,16.17]),]
        # modificación por el error de cruce long <-> lag
        #coordinates <<- SpatialPointsDataFrame(datos.geo[,c("LongitudPuntoConsumo","LatitudPuntoConsumo")],datos.geo)
        coordinates <<- SpatialPointsDataFrame(datos.geo[,c("LatitudPuntoConsumo","LongitudPuntoConsumo")],datos.geo)
        color.ico <<- colorBin("Blues",as.numeric(datos.consulta$PromedioActiva6CN),pretty = FALSE)  # Colores iconos
        iconos <<-awesomeIcons(icon= 'ios-close',
                               iconColor='black',
                               library= 'ion',
                               markerColor= colorNumeric(palette="Blues", 
                                                         domain=as.numeric(datos.consulta$PromedioActiva6CN)))
        
        datos.mapa <<- datos.consulta[complete.cases(datos.consulta[,13.14]),]
        minLat <- min(datos.consulta$LatitudPuntoConsumo)
        maxLat <- max(datos.consulta$LatitudPuntoConsumo)
        centerLat <- minLat + (maxLat - minLat) / 2.
        minLong <- min(datos.consulta$LongitudPuntoConsumo)
        maxLong <- max(datos.consulta$LongitudPuntoConsumo)
        centerLong <- minLong + (maxLong - minLong) / 2.
        
        # Problema: en dimension.puntoconsumo columnas de latitud y longitud están invertidas...
        # mapa <- leaflet() %>%
        #   setView(centerLong, centerLat, zoom = 14) %>%
        #   #addTiles() %>%
        #   #addTiles(urlTemplate='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png') %>%
        #   addTiles(urlTemplate='https://190.115.12.247/wms/{z}/{x}/{y}.png') %>%
        #   addCircles(data = datos.mapa[datos.mapa$NombreEstrato == "NO RESIDENCIAL",],
        #              group = "NO RESIDENCIAL",
        #              radius = 3,
        #              lat = as.numeric(datos.mapa$LatitudPuntoConsumo),
        #              lng = as.numeric(datos.mapa$LongitudPuntoConsumo),
        #              fillColor = "#00828F",
        #              fillOpacity = 0.6,
        #              color = "blue",
        #              weight = 2,
        #              stroke = TRUE,
        #              popup = datos.mapa$Texto,
        #              layerId = as.character(datos.mapa$CodigoPuntoConsumo),
        #              highlightOptions = highlightOptions(color = "mediumseagreen",
        #                                                  opacity = 0.9,
        #                                                  weight = 2,
        #                                                  bringToFront = TRUE)) %>%
        mapa <- leaflet() %>%
          setView(lat=centerLong, lng=centerLat, zoom = 14) %>%
          addWMSTiles(baseUrl="http://190.115.12.247/wms/services/service?",
                      layers= "osm",
                      options = WMSTileOptions(format = "image/png", 
                                               srs = "EPSG:3857",
                                               transparent = TRUE),
                      attribution="") %>%
          addCircles(data = datos.mapa[datos.mapa$NombreEstrato == "NO RESIDENCIAL",],
                     group = "NO RESIDENCIAL",
                     radius = 3,
                     lng = as.numeric(datos.mapa$LatitudPuntoConsumo),
                     lat = as.numeric(datos.mapa$LongitudPuntoConsumo),
                     fillColor = "#00828F",
                     fillOpacity = 0.6,
                     color = "blue",
                     weight = 2,
                     stroke = TRUE,
                     popup = datos.mapa$Texto,
                     layerId = as.character(datos.mapa$CodigoPuntoConsumo),
                     highlightOptions = highlightOptions(color = "mediumseagreen",
                                                         opacity = 0.9,
                                                         weight = 2,
                                                         bringToFront = TRUE)) %>%
          addMiniMap()  %>% 
          addMeasure(position = "bottomleft",
                     primaryLengthUnit = "kilometers",
                     secondaryLengthUnit = "meters",
                     primaryAreaUnit = "hectares",
                     secondaryAreaUni = "sqmeterst"
          )  %>%
          addDrawToolbar(
            targetGroup='Selected',
            polylineOptions=FALSE,
            markerOptions = FALSE,
            polygonOptions = drawPolygonOptions(shapeOptions=drawShapeOptions(fillOpacity = 0
                                                                              ,color = 'orange'
                                                                              ,weight = 2)),
            rectangleOptions = drawRectangleOptions(shapeOptions=drawShapeOptions(fillOpacity = 0
                                                                                  ,color = 'orange'
                                                                                  ,weight = 2)),
            circleOptions = drawCircleOptions(shapeOptions = drawShapeOptions(fillOpacity = 0
                                                                              ,color = 'orange'
                                                                              ,weight = 2)),
            editOptions = editToolbarOptions(edit = FALSE,
                                             selectedPathOptions = selectedPathOptions()
            )
          ) %>%
          addEasyButton(
            easyButton(
              title = "Zoom todo",
              icon = 'fa-globe', #htmltools::span(class = "star", htmltools::HTML("&starf;")),
              onClick = JS("function(btn, map){ map.setZoom(10);}")
            )
          )
        
        if(input$switch.calor == TRUE) {
          # lat y lng cambiados, para compensar error de columnas invertidas en dimension.puntoconsumo
          # mapa <- mapa %>% addHeatmap(lng = as.numeric(datos.mapa$LongitudPuntoConsumo),
          #                             lat = as.numeric(datos.mapa$LatitudPuntoConsumo),
          #                             intensity = as.numeric(datos.mapa$PromedioActiva6CN),
          #                             blur = 20,
          #                             max = 0.05, 
          #                             radius = 15
          # )
          mapa <- mapa %>% addHeatmap(lat = as.numeric(datos.mapa$LongitudPuntoConsumo),
                                      lng = as.numeric(datos.mapa$LatitudPuntoConsumo),
                                      intensity = as.numeric(datos.mapa$PromedioActiva6CN),
                                      blur = 20,
                                      max = 0.05, 
                                      radius = 15
          )
          mapa
        }
        else {mapa}
        
        # } else
        #   mapa.vacio()
      })
        
        
        
        
        # Cargar datos gráfico de puntos
        # https://stackoverflow.com/questions/15622001/how-to-display-only-integer-values-on-an-axis-using-ggplot2
        # updateMaterialSwitch(session, 'selec.graf', value = FALSE)
        # output$plot <- renderPlotly({
        #   p <-
        #     ggplot(tabla.datos,
        #            mapping = aes(x = AcumuladoConsumoCero, y = PromedioActiva6CN, text = texto)) +
        #     geom_point(color = "#0070ba", size = 1) + theme_bw() +
        #     scale_x_continuous(breaks= function(x) unique(floor(pretty(seq(0, (max(x) + 1) * 1.1))))) +
        #     ylab("Consumo promedio 6 meses anteriores [kWh]") +
        #     xlab("Períodos consecutivos en cero")
        #   
        #   # Manejo de selección en gráfica
        #   obj <- data.grafica()$sel
        #   #      if (exists("obj")) {
        #   if(nrow(obj)!=0 ) {
        #     p <- p + geom_point(data=obj,color="orange")
        #   }
        #   #      }
        #   ggplotly(p, source = "master")
        # })
        
        #showTab("Gráfica", "Datos", select = FALSE,  session = getDefaultReactiveDomain())
        #showTab("Gráfica", "Mapa", select = FALSE,  session = getDefaultReactiveDomain())
        # output$datos <- renderRHandsontable({
        #   tabla.despliegue(tabla.datos, data.grafica()$sel)
        # })

        
      } else{
        disable("Guardar")                                  # Deshabilita el botón para guardar
        disable("Descargar")
        showModal(modalDialog(
          title = "La consulta no encuentra datos que cumplan.",
          footer = tags$div(id="modal1",modalButton("Cerrar")),
          easyClose = TRUE
        ))
      }
      shinyjs::enable("ReiniciarControles")
      shinyjs::enable("TraerDatos")
    }
    
  }, ignoreInit = TRUE)
  
  # Lista de puntos seleccionados -------------------------------------------
  
  data_of_click <- reactiveValues(clickedMarker = list())
  
  observeEvent(
    input$mymap_draw_new_feature,
    {

      found_in_bounds <-
        findLocations(
          shape = input$mymap_draw_new_feature
          ,
          location_coordinates = coordinates
          ,
          location_id_colname = "CodigoPuntoConsumo"
        )
      
      for (id in found_in_bounds) {
        if (id %in% data_of_click$clickedMarker) {
          # don't add id
        } else {
          # add id
          data_of_click$clickedMarker <-
            append(data_of_click$clickedMarker, id, 0)
        }
      }
      
      # Datos seleccionados
      selected <-
        subset(datos.mapa,
               datos.mapa$CodigoPuntoConsumo %in% data_of_click$clickedMarker)
      
      #output$tbl <- renderDT({
        
        puntos_seleccionados$Datos <-  data.frame(
          Grafica= paste0("<button class='btn btn-default action-button btn-light action_button' id='",selected$CodigoPuntoConsumo,"' type='button' onmousedown='event.preventDefault(); event.stopPropagation(); return false;' onclick='Shiny.onInputChange(\"btnDetalleTabla\", this.id)'><i class='fas fa-chart-line'></i></button>"),
          Código=selected$CodigoPuntoConsumo,
          Nombre=selected$NombreCliente,
          Dirección=selected$DireccionPuntoConsumo,
          Actividad=paste0(selected$Seccion," ",selected$grupo),
          PromedioActiva6CN = round(as.numeric(selected$PromedioActiva6CN), digits = 2),
          Zona= selected$NombreZona,
          Región = selected$NombreRegion,
          Oficina = selected$NombreOficina,
          Itinerario = selected$Itinerario,
          Departamento = selected$NombreDepartamentoGeografia,
          Municipio = selected$NombreMunicipioGeografia,
          Localidad = selected$NombreLocalidadZonaGeografia,
          Circuito = paste0(selected$CodigoCircuito," ",selected$Nombre_corto_SMT)
        )	
          # selected[c(
          #   "CodigoPuntoConsumo",
          #   "NombreCliente",
          # 
          #   "NombreCircuito",
          # 
          #   "PromedioActiva6CN",
          # 
          #   "fechaUltimaInspeccion"
          # )]
        
        # puntos.seleccionados$PromedioActiva6CN <-
        #   lapply(puntos.seleccionados$PromedioActiva6CN,
        #          function(x) {
        #            trunc(as.numeric(x) * 10) / 10
        #          })
        # puntos.seleccionados$DevStdActiva6CN <-
        #   lapply(puntos.seleccionados$DevStdActiva6CN,
        #          function(x) {
        #            trunc(as.numeric(x)) / 100
        #          })
        
        # administrar botones
        cant.seleccionados <- nrow(puntos_seleccionados$Datos)
        
        if (cant.seleccionados > 0) {
          shinyjs::enable("Guardar")                                   # Habilita el botón para guardar
          shinyjs::enable("Descargar")
          #shinyjs::enable("selec.tod")
        }
        else{
          shinyjs::disable("Guardar")                                  # Deshabilita el botón para guardar
          shinyjs::disable("Descargar")
         # shinyjs::disable("selec.tod")
        }
        
        # Presentar datos
        #puntos.mostrables <- cbind(seq.int(nrow(puntos.seleccionados)),`°` = TRUE, puntos.seleccionados)
        #puntos.en.geocerca(puntos.mostrables)
        
        output$tbl <- renderDT(
          #puntos.mostrables,
          puntos_seleccionados$Datos ,
          #valores_tabla$Data,
          server = TRUE,
          #filter = 'top',
          class="compact",
          extensions = list("Buttons" = TRUE,
                            "ColReorder" = NULL,
                            "FixedColumns" = list(leftColumns=3)),
          #colnames = c('Código'= 2, 'Nombre'= 19),
          selection = 'multiple',
          options = list(
            scrollX = TRUE,
            scrollY = 460,
            scroller = TRUE,
            fixedColumns = list(leftColumns = 3),
            buttons = c('excel')
          ),
          escape = F
        )
        
     # })
      selected <<- selected
      proxy <- leafletProxy("mymap")
      proxy %>% addCircles(data = selected,
                           radius = 5,
                           #lat = selected$LatitudPuntoConsumo,
                           #lng = selected$LongitudPuntoConsumo,
                           lat = selected$LongitudPuntoConsumo,
                           lng = selected$LatitudPuntoConsumo,
                           fillColor = "orange",
                           fillOpacity = 1,
                           color = "red",
                           weight = 3,
                           stroke = TRUE,
                           layerId = as.character(selected$COD_CLIE2),
                           #popup = datos.mapa$Texto,
                           highlightOptions = highlightOptions(color = "hotpink",
                                                               opacity = 0.8,
                                                               weight = 2,
                                                               bringToFront = TRUE))
    })
  
  # Editar tabla de seleccionados en mapa (borrar) ----------------------------------------------
  
  observeEvent(input$mymap_draw_deleted_features,{

    puntos.eliminados <<- NA
    for(feature in input$mymap_draw_deleted_features$features){
      
      # get ids for locations within the bounding shape
      bounded_layer_ids <- findLocations(shape = feature
                                         , location_coordinates = coordinates
                                         , location_id_colname = "COD_CLIE2")
      
      # remove second layer representing selected locations
      proxy <- leafletProxy("mymap")
      proxy %>% removeShape(layerId = as.character(bounded_layer_ids))
      
      first_layer_ids <- subset(datos.mapa, COD_CLIE2 %in% bounded_layer_ids)$CodigoPuntoConsumo
      
      data_of_click$clickedMarker <- data_of_click$clickedMarker[!data_of_click$clickedMarker
                                                                 %in% first_layer_ids]
      
      # Adquirir y filtrar tabla de seleccionados
      puntos.eliminados <<- append(puntos.eliminados, first_layer_ids)
      
    }
    #s <- transf.rhand(input$Seleccionados)
    
    s1 <<- subset(selected, !(selected$CodigoPuntoConsumo %in% puntos.eliminados))
    
    click("Consulta")
  })
  
  observeEvent(input$Consulta,{

    puntos.seleccionados <<- s1
    
      # Adquirir y filtrar tabla de seleccionados
      
      # administrar botones
      cant.seleccionados <- nrow(puntos.seleccionados)
      
      if (cant.seleccionados > 0) {
        shinyjs::enable("Guardar")                                   # Habilita el botón para guardar
        shinyjs::enable("Descargar")
       # shinyjs::enable("selec.tod")
      }
      else{
        #shinyjs::disable("Guardar")                                  # Deshabilita el botón para guardar
        #shinyjs::disable("Descargar")
       # shinyjs::disable("selec.tod")
      
        puntos_seleccionados$Datos <-  data.frame(
          Grafica= paste0("<button class='btn btn-default action-button btn-light action_button' id='",datos.mapa$CodigoPuntoConsumo,"' type='button' onmousedown='event.preventDefault(); event.stopPropagation(); return false;' onclick='Shiny.onInputChange(\"btnDetalleTabla\", this.id)'><i class='fas fa-chart-line'></i></button>"),
          Código=datos.mapa$CodigoPuntoConsumo,
          Nombre=datos.mapa$NombreCliente,
          Dirección=datos.mapa$DireccionPuntoConsumo,
          Actividad=paste0(datos.mapa$Seccion," ",datos.mapa$grupo),
          PromedioActiva6CN = round(as.numeric(datos.mapa$PromedioActiva6CN), digits = 2),
          Zona= datos.mapa$NombreZona,
          Región = datos.mapa$NombreRegion,
          Oficina = datos.mapa$NombreOficina,
          Itinerario = datos.mapa$Itinerario,
          Departamento = datos.mapa$NombreDepartamentoGeografia,
          Municipio = datos.mapa$NombreMunicipioGeografia,
          Localidad = datos.mapa$NombreLocalidadZonaGeografia,
          Circuito = paste0(datos.mapa$CodigoCircuito," ",datos.mapa$Nombre_corto_SMT)
        )
      # Presentar datos
      puntos.en.geocerca(puntos.seleccionados)
      output$tbl <- renderDT(
        #puntos.mostrables,
        puntos_seleccionados$Datos,
        #valores_tabla$Data,
        server = TRUE,
        #filter = 'top',
        class="compact",
        extensions = list("Buttons" = TRUE,
                          "ColReorder" = NULL,
                          "FixedColumns" = list(leftColumns=3)),
        #colnames = c('Código'= 2, 'Nombre'= 19),
        selection = 'multiple',
        options = list(
          scrollX = TRUE,
          scrollY = 460,
          scroller = TRUE,
          fixedColumns = list(leftColumns = 3),
          buttons = c('excel')
        ),
        escape = F
      )
      }
      

  }, ignoreInit = TRUE)
  
  # Cargar datos a tabla
  # output$datos <-
  #   renderRHandsontable({
  #     if (exists("tabla.datos")){
  #       obj <- data.grafica()$sel
  #       if(nrow(obj) >0) {
  #         p <- p <- tryCatch(tabla.datos[(selected()$pointNumber+1),,drop=FALSE] , error=function(e){NULL})
  #       } else if (exists("tabla.datos")) {
  #         p <- tabla.datos
  #       }
  #       if (nrow(p ) > 0) {
  #         # Actualiza rhandsontable
  #         tabla.despliegue(p, data.grafica()$sel)
  #         
  #       }
  #     }
  #   })
  
  # Puntos seleccionados
  # selected<-reactive({
  #   
  #   event_data("plotly_selected", source = "master")
  # })
  
  # data.grafica<-reactive({
  #   if (exists("tabla.datos")){
  #     tabla.datos.valida <<- FALSE
  #     tmp<-tabla.datos
  #     sel<-tryCatch(tabla.datos[(selected()$pointNumber+1),,drop=FALSE] , error=function(e){NULL})
  #     if (nrow(sel) > 0 & tipo.grafica == 'B') {
  #       secuencia.sel <- selected()$pointNumber + 1
  #       valores.ceros <- sort(unique(tabla.datos$AcumuladoConsumoCero))[secuencia.sel]
  #       sel <-  tabla.datos %>% filter(AcumuladoConsumoCero %in% valores.ceros)
  #       list(data=tmp,sel=sel)
  #     } else {
  #       click('MostrarTabla')
  #       list(data=tmp,sel=sel)
  #     }
  #     
  #   }
  #   
  #   # list(data=tmp,sel=sel)
  #   
  # })

  
  # # Cambiar tipo de gráfica  ----------------------------------------
  # observeEvent(input$selec.graf,{
  #   
  #   valorSwitch <- input$selec.graf
  #   if (valorSwitch == TRUE) {
  #     tipo.grafica <<- 'B'
  #     output$plot <- renderPlotly({
  #       p <- ggplot(tabla.datos, mapping = aes(x = AcumuladoConsumoCero)) +
  #         geom_bar(color ="#0070ba",fill= "#0070ba",size =1) + theme_bw()+
  #         ylab("Conteo") +
  #         xlab("Períodos consecutivos en cero")
  #       # Manejo de selección en gráfica
  #       obj <- data.grafica()$sel
  #       if(nrow(obj)!=0) {
  #         p <- p + geom_bar(data=obj,color="orange",fill="orange")
  #       }
  #       ggplotly(p,source="master")
  #     })
  #   } else {
  #     tipo.grafica <<- 'P'
  #     output$plot <- renderPlotly({
  #       p <-
  #         ggplot(tabla.datos,
  #                mapping = aes(x = AcumuladoConsumoCero, y = PromedioActiva6CN, text = texto)) +
  #         geom_point(color = "#0070ba", size = 1) + theme_bw() +
  #         ylab("Consumo promedio 6 meses anteriores [kWh]") +
  #         xlab("Períodos consecutivos en cero")
  #       
  #       # Manejo de selección en gráfica
  #       obj <- data.grafica()$sel
  #       if(nrow(obj)!=0) {
  #         p <- p + geom_point(data=obj,color="orange")
  #       }
  #       ggplotly(p, source = "master")
  #     })
  #   }
  # }, ignoreInit = TRUE)
  
  # Seleccionar o deselecionar todos ----------------------------------------
  
  # observeEvent(input$selec.tod,{
  #   tabla.temp <<- hot_to_r(input$datos)    # Tabla temporal para alimentar rhandsontable
  #   
  #   if(input$selec.tod == "Todos"){
  #     tabla.temp[,1] <- TRUE             # Cambia primera columna a seleccionado
  #   }
  #   
  #   if(input$selec.tod == "Ninguno"){
  #     tabla.temp[,1] <- FALSE               # Cambia primera columna a deseleccionado
  #   }
  #   # output$datos <- renderRHandsontable({   # Actualiza rhandsontable
  #   #   tabla.despliegue(tabla.temp, data.grafica()$sel)
  #   # })
  #   # output$map <- renderGoogle_map({
  #   #   mapa.despliegue(tabla.temp, data.grafica()$sel, datos.consulta, TRUE,tabla.datos.valida, input) #, datos.imagen, input)
  #   # })
  #   
  # }, ignoreInit = TRUE)
  
  # Descargar excel -----------------------------------------------------------
  
  output$Descargar <- downloadHandler(
    
    filename = function() { 
      #paste0("Ceros", Sys.Date(), ".csv")
      paste0("ConsumosGeoreferenciados", Sys.Date(), ".xlsx")
    },
    content = function(file) {

      if (is.na(puntos_seleccionados$Datos)) {
        ordenes <- valores_tabla$Data[-1]
      } else {
        ordenes <- puntos_seleccionados$Datos[-1]
      }
      #ordenes <- datos.consulta[input$tbl_rows_selected,]       # Descargar seleccionados datatable
      #ordenes <- subset(ordenes, ordenes[,1] == TRUE)[,-1]      # Filtra aquellos con checkbox activo y omite primera columna
      wbk <- createWorkbook()
      addWorksheet( wb = wbk,  sheetName = "Data" )
      setColWidths(wbk,1,cols = 1:13,
                   widths = c(6, 33,30,30,10,15,15,15,10,10,15,15,30))
      
      addStyle(wbk,sheet = 1, style = createStyle( fontSize = 12, textDecoration = "bold" ), rows = 1:1, cols = 1:ncol(ordenes) )
      
      writeData(wbk,sheet = 1,ordenes,startRow = 1,startCol = 1 )
      saveWorkbook(wbk, file)
    }#,
    #contentType = "csv"
  )
  
  observeEvent(input$MostrarTabla, {
    if (exists("tabla.datos")) {
      if (nrow(data.grafica()$sel) == 0) {
        tabla.temp <- tabla.datos
      }
      if (exists("tabla.temp")){
        tabla.temp[,1] <- TRUE
        # output$datos <- renderRHandsontable({   # Actualiza rhandsontable
        #   tabla.despliegue(tabla.temp, data.grafica()$sel)
        # })
      } 
    }
  }, ignoreInit = TRUE)
  
  
  # observeEvent(input$MostrarMapa, {
  #   if ( exists("tabla.datos")) {
  #     mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta,TRUE,tabla.datos.valida, input) #, datos.imagen, input)
  #   }
  #   #  mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta,TRUE,tabla.datos.valida, input)
  #   # output$map <- renderGoogle_map({
  #   #   mapa.despliegue(tabla.datos, data.grafica()$sel, datos.consulta)
  #   # })
  # }, ignoreInit = TRUE)
  
  # Generar órdenes de inspección en BD ---------------------------------------------------
  observeEvent(input$Guardar,{
    
    showModal(modalDialog(
      
      title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("Generar órdenes"),style="color: #0070ba"),style="text-align: center;"),
      
      "Se guardarán los clientes seleccionados para ser incluidos \n en la lista de órdenes de inspección",
      hr(),
      
      selectInput("variable", 
                  "Seleccione campaña:",
                  nom.camp),
      textAreaInput("observ.orden", label = "Observaciones:",
                    height = "100px", rows = 4, 
                    placeholder = "Comentarios para acompañar la órden", 
                    resize = "vertical"),
      # footer = list(tags$div(id="modal1",modalButton("Cancelar", icon = icon("fas fa-table"))),
      #               actionButton("Guardar2", "Guardar",icon = icon("fas fa-table"),
      #                            style="color: #fff; background-color: #0070ba; border-color: #0070ba")
      # ),
      footer = fluidRow(column(width=2, offset=7,tags$div(id="modal1", 
                                                          modalButton("Cancelar", icon = icon("fas fa-table")))),
                        column(width=2,actionButton("Guardar2", "Guardar",icon = icon("fas fa-table"),
                                                    style="color: #fff; background-color: #0070ba; border-color: #0070ba"))
      ),
      easyClose =TRUE
    )
    )
  }, ignoreInit = TRUE)
  
  
  observeEvent(input$Guardar2, {                                          # Código para botón diálogo modal
    
    #  Grabar órdenes en BD
    
    ordenes <- datos.consulta[input$tbl_rows_selected,]                      # Transforma los datos tomados del objeto rhandsontable.
    #ordenes <- subset(ordenes, ordenes[,1] == TRUE)[,-1]      # Filtra aquellos con checkbox activo y omite primera columna
    
    if (nrow(ordenes) > 0) {
      ordenes<-cbind(ordenes[,1],                                         # Punto de consumo: 'CodigoPuntoConsumo'
                     rep(as.character(input$variable), nrow(ordenes)),    # Línea para tipo de campaña seleccionada: 'NombreCampana'
                     rep("Sequimiento cortados", nrow(ordenes)),          # Reporte origen de las órdenes: 'ReporteOrigen'
                     rep(as.character(Sys.time()), nrow(ordenes)),        # Fecha y hora de generación de las órdenes: 'FechaGeneracion'
                     rep(analista, nrow(ordenes)),                        # Usuario que genera las órdenes: 'AnalistaSolicitante'
                     rep(0.5, nrow(ordenes)),                             # 'Probabilidad' de detección. ** Se debe incluir probabilidad de la campaña, por ahora es 0.5
                     ordenes[,9],                                         # 'RecuperacionMedia': Se asume promedio anterior
                     rep(as.character(input$observ.orden), nrow(ordenes)) #  Observación que acompaña la orden 'ObservacionOrden'
      )
      
      ordenes<-data.frame(ordenes)
      ordenes[,7]<-as.numeric(as.character(ordenes[,7]))                  # Se convierte a texto el dato tomado de la tabla
      
      #conexion2 <- odbcDriverConnect ("driver={SQL Server};server=WMENERTOLIMA\\SQL2017;database=DWSRBI_ENERGUATE;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" )
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      cad.sql<-" INSERT INTO [DWSRBI_ENERGUATE].[Hecho].[OrdenInspeccion]([CodigoPuntoConsumo],[NombreCampana],[ReporteOrigen],[FechaGeneracion],[AnalistaSolicitante],[Probabilidad],[RecuperacionMedia],[ObservacionOrden])"
      cad.sql<-paste (cad.sql,"VALUES (?,?,?,?,?,?,?,?)")
      
      sqlExecute(channel = conexion,
                 cad.sql,
                 data = ordenes)              # En 'ordenes' se incluyen las órdenes a ser incluidas en la tabla 'OrdenInspeccion'
      odbcClose(conexion)
      
      ord.gen <<- ord.gen + nrow(ordenes)     # Se actualiza el contador de órdenes generadas en la sesión. Variable global
      
      output$MensajeOrdenes <- renderMenu({   # Actualiza mensaje en la barra de menú para órdenes generadas
        
        dropdownMenu(type = "notifications",  # Mensaje en barra de encabezado para indicar generación de órdenes
                     headerText = "Tiene una notificación",
                     icon =icon("fas fa-comments"),
                     notificationItem(
                       text = paste(ord.gen, "órdenes generadas en esta sesión"),
                       icon("fas fa-gavel")
                     )
        )
      })
    }
    removeModal()
  })
  
})



# Ejecutar aplicación -----------------------------------------------------


shinyApp(ui = ui, server = server)