# Source helpers:
# ********************** Ceros consecutivos ****************************

library(rhandsontable)




# Función para actualizar controles -----------------------------------------

actualizar.filtros <-
  function (session,
            input,
            atributoCambiado,
            ValoresAtributo,
            valores.atributos, idx) {


    f1 <-
      valores.atributos %>% filter(Atributo == atributoCambiado) %>% filter(Nombre %in% ValoresAtributo)
    
    if (atributoCambiado == "Estrato") {
      idx.filtrado <- idx %>% filter(idx$LlaveEstrato %in% f1$Llave)
    } else     if (atributoCambiado== "Actividad") {
      idx.filtrado <-
        idx %>% filter(idx$LlaveActividadEconomica %in% f1$Llave)
    } else if (atributoCambiado == "Ciclo") {
      idx.filtrado <- idx %>% filter(idx$LlaveCiclo %in% f1$Llave)
    } else if (atributoCambiado == "Circuito") {
      idx.filtrado <- idx %>% filter(idx$LlaveCircuito %in% f1$Llave)
    } else if (atributoCambiado == "Municipio") {
      idx.filtrado <- idx %>% filter(idx$LlaveGeografia %in% f1$Llave)
    }else if (atributoCambiado == "Zona") {
      idx.filtrado <- idx %>% filter(idx$LlaveZona %in% f1$Llave)
    }else if (atributoCambiado == "Transformador") {
      idx.filtrado <- idx %>% filter(idx$LlaveTransformador %in% f1$Llave)
    }
    
    datos.filtrados <- valores.atributos  %>% 
      filter((Atributo=='Zona' & Llave %in% idx.filtrado$LlaveZona) | 
               (Atributo=='Municipio' & Llave %in% idx.filtrado$LlaveGeografia) |
               (Atributo=='Circuito' & Llave %in% idx.filtrado$LlaveCircuito) |
               (Atributo=='Ciclo' & Llave %in% idx.filtrado$LlaveCiclo) |
               (Atributo=='Actividad' & Llave %in% idx.filtrado$LlaveActividad) |
               (Atributo=='Transformador' & Llave %in% idx.filtrado$LlaveTransformador) |
               (Atributo=='Estrato' & Llave %in% idx.filtrado$LlaveEstrato))
    
    # Actualizar controles
    # Actualizar control Estrato
    if (atributoCambiado != "Estrato") {
      valor.seleccionado <- input$estrato
      atr <- valores.atributos %>% filter(Atributo == 'Estrato') %>% filter(Llave %in% idx.filtrado$LlaveEstrato)
      
      updatePickerInput(session,
                        "estrato",
                        choices = c( atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # Actualizar control actividad
    if (atributoCambiado != "Actividad") {
      valor.seleccionado <- input$actividad
      atr <- valores.atributos %>% filter(Atributo == 'Actividad') %>% filter(Llave %in% idx.filtrado$LlaveActividadEconomica)
      
      updatePickerInput(session,
                        "actividad",
                        choices = c( atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # Actualizar control ciclo
    if (atributoCambiado != "Ciclo") {
      valor.seleccionado <- input$ciclo
      atr <- valores.atributos %>% filter(Atributo == 'Ciclo') %>% filter(Llave %in% idx.filtrado$LlaveCiclo)
      
      updatePickerInput(session,
                        "ciclo",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # Actualizar control circuito
    if (atributoCambiado != "Circuito") {
      valor.seleccionado <- input$circuito
      atr <- valores.atributos %>% filter(Atributo == 'Circuito') %>% filter(Llave %in% idx.filtrado$LlaveCircuito)
      
      updatePickerInput(session,
                        "circuito",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    
    # actualizar control municipio
    if (atributoCambiado != "Municipio") {
      valor.seleccionado <- input$municipio
      atr <- valores.atributos %>% filter(Atributo == 'Municipio') %>% filter(Llave %in% idx.filtrado$LlaveGeografia)
      
      #updateSelectInput(session,
      updatePickerInput(session,
                        "municipio",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    # Actualizar control zona
    if (atributoCambiado != "Zona") {
      valor.seleccionado <- input$zona
      atr <- valores.atributos %>% filter(Atributo == 'Zona') %>% filter(Llave %in% idx.filtrado$LlaveZona)
      
      updatePickerInput(session,
                        "zona",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
    # Actualizar control transformador
    if (atributoCambiado != "Transformador") {
      valor.seleccionado <- input$transformador
      atr <- valores.atributos %>% filter(Atributo == 'Transformador') %>% filter(Llave %in% idx.filtrado$LlaveTransformador)
      
      updatePickerInput(session,
                        "transformador",
                        choices = c(atr$Nombre),
                        selected = valor.seleccionado)
    }
  

    
  }


# Función para transformar vista de un objeto rhandsontable con primera columna de hipervínculo a
# un data frame

transf.rhand <- function(ordenes){
 
  
  #ordenes$CodigoPuntoConsumo <- as.character(ordenes$CodigoPuntoConsumo)
  for(i in 1:nrow(ordenes)){                                      # Extrae el número de cliente del hipervínculo
    pos.cliente <- gregexpr(">",ordenes$CodigoCliente[i])
    pos.cliente <- pos.cliente[[1]][1]  + 1
    fin.cad <- nchar(ordenes$CodigoCliente[i]) - 4
    ordenes$CodigoCliente[i] <- substr(ordenes$CodigoCliente[i],pos.cliente,fin.cad)
  }
  ordenes
  
}

