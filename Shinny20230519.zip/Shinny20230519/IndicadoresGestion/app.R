# =============================================================================
#          Análisis Predictivo Probabilidad de Fraude y Recuperación
# =============================================================================
# 
# =============================================================================

# Carga de librerías ------------------------------------------------------
options(useFancyQuotes = FALSE)
library(RODBC)          # Conexión a la base de datos
library(RODBCext)       # Conexión a la base de datos
library(config)
library(shiny)
library(rhandsontable)  # Visualización tablas
library(htmlwidgets)
library(scales)
library(lubridate)
library(shinydashboard)
library(DT)
library(ggplot2)
library(plotly)         # Graficas dinámicas plotly
library(RCurl)
library(shinyjs)
library(shinycssloaders)# Reloj para tiempo de espera
library(shinyWidgets)
#library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(plyr)
library(dplyr)          # Adecuacion de tablas para visualización
library(googleway)      # Presentación de ubicación del punto de consumo en el mapa. Ref absoluta a add_markers
library(stringr)
require(colorspace)
library(shinyBS)        # Utilizada para mostrar tooltip
#library(rintrojs)       # Presentación de ayuda en pantalla
library(openxlsx)




source("helpers.R")
source("_shared/_filtros.R")
#reactlog_enable()

# función para convertir columna de datos jpg a cod64 
aCode64 <- function(objetoJPG) {
  base64Encode(objetoJPG,"text")
}



# Retornar tabla para despliegue ---------------------------------------------
tabla.despliegue <- function(tabla.temp, obj) {
  
  if(is.null(tabla.temp)){
    print('vacio')
    # DF = data.frame(character = c())
    # rhandsontable(DF,
    #               colHeaders = c(
    #                 ''
    #               ),
    #               readOnly = TRUE
    # )
  }else{
    
    rhandsontable(tabla.temp,
                  rowHeaders = TRUE,
                  height =380,
                  search = FALSE,
                  readOnly = TRUE,
                  selectCallback = TRUE)%>% 
      hot_col(1, halign = "htCenter", readOnly = FALSE) %>% 
      hot_col(2, renderer = "html",halign = "htRight") %>%                # Mostrar como hipervínculo
      hot_col(2, renderer = htmlwidgets::JS("safeHtmlRenderer")) %>%      # Mostrar como hipervínculo
      hot_cols(fixedColumnsLeft=2) %>%  
      #hot_col(7,format="#.00", halign="htRight" ) %>% 
      #hot_heatmap(7, color_scale =c("#17F556", "#ED6D47")) %>%  # Habilitar escala de color
      hot_cols(columnSorting = TRUE)  %>%   
      hot_context_menu(allowRowEdit = FALSE, allowColEdit = FALSE) %>%    # Bloquea opciones de menú contextual
      hot_table(highlightCol = TRUE, highlightRow = TRUE)                 # Resalta fila y columna seleccionada
  }
}

# Retornar mapa para despliegue --------------------------------------------
mapa.despliegue<- function(tabla.temp, obj, datos.consulta, banderaRefresco,tabla.datos.valida, input) { #} datos.imagen, input) { 
  
  if (tabla.datos.valida) {
    tabla.temp <-  hot_to_r(input$datos)
    ordenes <- subset(tabla.temp, tabla.temp[,1] == TRUE)[,-1]
  } else if(nrow(obj)!=0) {
    ordenes <- obj
  } else {
    ordenes <- subset(tabla.temp, tabla.temp[,1] == TRUE)[,-1]
  }
  
  
  for(i in 1:nrow(ordenes)){                                      # Extrae el número de cliente del hipervínculo
    pos.cliente <- gregexpr(">",ordenes$CodigoPuntoConsumo[i])
    pos.cliente <- pos.cliente[[1]][1] + 1
    fin.cad <- nchar(ordenes$CodigoPuntoConsumo[i]) - 4
    ordenes$CodigoPuntoConsumo[i] <- substr(ordenes$CodigoPuntoConsumo[i],pos.cliente,fin.cad)
  }
  ordenes$CodigoPuntoConsumo <- unlist(ordenes$CodigoPuntoConsumo)
  
  datos<-left_join(ordenes,datos.consulta,by = "CodigoPuntoConsumo") # Efectua unión para traer coordenadas
  datos.consulta$PromedioActiva6CN<-as.numeric(as.character(datos.consulta$PromedioActiva6CN))  # Convierte a numérico
  datos.consulta$PromedioActiva6CN[is.na(datos.consulta$PromedioActiva6CN)]=0                  # Ajuste de valores nulos
  datos$LatitudPuntoConsumo <-as.numeric(as.character(datos$LatitudPuntoConsumo))
  datos$LongitudPuntoConsumo <-as.numeric(as.character(datos$LongitudPuntoConsumo))
  
  
  if (banderaRefresco) {
    google_map_update(map_id = "map") %>%
      clear_markers() %>%
      googleway::add_markers(data = datos,lat = "LatitudPuntoConsumo", lon = "LongitudPuntoConsumo", 
                             info_window = "Texto1",close_info_window = TRUE)
    #info_window = "texto",close_info_window = TRUE)
  } else {
    google_map(key = api_key, data = datos, style=estilo.map01) %>%
      googleway::add_markers(lat = "LatitudPuntoConsumo", lon = "LongitudPuntoConsumo", 
                             info_window = "Texto1",close_info_window = TRUE)
    #  info_window = "texto",close_info_window = TRUE)
  }
}


# Configuración de bd y código para api google --------------------------------------------------------------
configuracion.conexion <<- 'externalENERG' # Sys.getenv("CONEXIONSHINY") #'windows', 'externalENERG' para energuate
#  'GoogleKey' CodigoParametro api google en [DWSRBI_ENERGUATE].[Aux].[Parametros]
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql <- "SELECT TOP 1 ValorParametro FROM [DWSRBI_ENERGUATE].[Aux].[Parametros] where EstadoParametro = 1 AND   CodigoParametro = 'GoogleKey'"
api_key <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
odbcClose(conexion)
api_key <<- api_key[1,1]


# Contadores y llamadas --------------------------------------------------------------
ord.gen <<- 0  # Contador para presentar la cantidad de órdenes generadas en la sesión
analista <<- "NBC"                     # Cadena para identificación del solicitante
#api_key <- "AIzaSyAYoARt3zU_arrmeiZmMCjXhLEyRoE7Z2Q"  # Solicitar clave a WM y cambiar
Sys.setenv(LANGUAGE="ES")
options(encoding = 'UTF-8')
locale <- Sys.getlocale(category="LC_COLLATE")
if (grepl("Spanish", locale, fixed=TRUE)) {
  separador.csv <<- ';'
} else {
  separador.csv <<- ','
}

# Captura de parámetro para URL servidor shiny -------------
config <- config::get(config=configuracion.conexion)
config.conexion <- config$conexion
conexion <- odbcDriverConnect (config.conexion)
cad.sql<- "SELECT [ValorParametro]  FROM [DWSRBI_ENERGUATE].[Aux].[Parametros]  WHERE [CodigoParametro] = 'URLshiny'"
URL.servidor.shiny <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
URL.servidor.shiny <- URL.servidor.shiny [1,1]
str.http <<- paste(URL.servidor.shiny,"hvurl/?Codigo=",sep="") # Cadena de llamada para vinculo a hoja de vida




# Captura de campañas disponibles en BD -----------------------------------
cad.sql<- "[dbo].[Leer_Campanas1]"
nom.camp <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
colnames(nom.camp)<-"Nombre"
nom.camp <- nom.camp  %>% filter(!is.na(Nombre))

# cad.sql <- "SELECT DISTINCT [NombreServicio] FROM [Dimension].[Servicio] where codigoservicio > 0  ORDER BY [NombreServicio]"
# nom_servicios <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
# colnames(nom_servicios) <- "Nombre"
# nom_servicios <- nom_servicios   %>% filter(!is.na(Nombre))
# nom_servicios <- c("G. clientes", "PIMT", "Masivos", "Consumos fijos", "Autoproductores")

# Consultar datos de filtros
consultarDatosFiltros(conexion)

# Carga contenido filtros
cargarFiltrosIniciales()

odbcClose(conexion)

# UI ----------------------------------------------------------------------
# ref https://stackoverflow.com/questions/31440564/adding-a-company-logo-to-shinydashboard-header

# font negro para pickerinput
col_list2 <- c("black")
colorspi <- paste0("color:",rep(c('black'),each=10),";")

dbHeader <- dashboardHeader()
dbHeader <- dashboardHeader(title = "Indicadores de Gestión",
                            tags$li(div(
                              img(src = 'Kronos.png',
                                  title = "Indicadores de Gestión", height = "30px"),
                              style = "padding-top:10px; padding-bottom:10px; margin-right:10px;"),
                              class = "dropdown"),
                            dropdownMenuOutput("MensajeOrdenes"))  # Presenta mensajes en barra de encabezado)

ui = dashboardPage(
  # evento para capturar uso de column sort en tabla
  # url: https://stackoverflow.com/questions/36176298/preserve-row-order-of-rhandsontable-in-shiny-app
  
  
  # dashboardHeader(
  #    # title = div(tags$a(img(src="LogoEnerguate.svg", height=1000)),
  #    #             style = "position: relative; top: -5px;"), # Navigation bar
  #   title = "Análisis Predictivo Probabilidad de Fraude y Recuperación",
  #   
  #   titleWidth = 500,
  #   
  #   # tags$li(class = "dropdown",            # Presenta vínculo para 'Tour'
  #   #         tags$li(class = "dropdown", actionLink("ayuda", textOutput("Tour")))),
  #   
  #   dropdownMenuOutput("MensajeOrdenes"),  # Presenta mensajes en barra de encabezado
  #   dropdownMenuOutput("MensajeMapa")      # Presenta mensajes en barra de encabezado    
  # ),
  dbHeader,
  
  # Sidebar -----------------------------------------------------------------
  
  dashboardSidebar(width = 260,
                   
                   # Codigo para reducir espacio entre objetos Shiny                   
                   tags$head(
                     tags$style(
                       HTML(".form-group {
                            margin-bottom: 0 !important;
                            }"))),
                   
                   #introjsUI(),   # Se habilita presentación de ayuda
                   
                   # Codigo para no mostrar errores en interfaz Shiny
                   tags$style(type="text/css",
                              ".shiny-output-error { visibility: hidden; }",
                              ".shiny-output-error:before { visibility: hidden; }"
                   ),
                   fluidRow( column(width = 12,offset = 0, style='padding:0px;',
                                    box(id = "Comandos", width = 12, 
                                        status = NULL,  
                                        background = "black",
                                        fluidRow( 
                                          column(width = 2,offset = 1,
                                                 actionButton("ReiniciarControles", label = icon("fas fa-sync"),
                                                              style="color: #fff; background-color: #0070ba; border-color: #0070ba"),
                                                 bsTooltip("ReiniciarControles", "Reiniciar valores de filtro", placement = "bottom", trigger = "hover", options = NULL)
                                          ),
                                          column(width = 2,
                                                 offset = 1,
                                                 actionButton("TraerDatos", label = icon("fas fa-play"),
                                                              style="color: #fff; background-color: #0070ba; border-color: #0070ba"), 
                                                 bsTooltip("TraerDatos", "Ejecutar consulta", placement = "bottom", trigger = "hover", options = NULL)
                                          )
                                        )
                                        
                                    ),
                                    obtenerFiltrosZona()
                                    #obtenerFiltrosEmpresa()
                                    # obtenerFiltrosDepartamento()
                   )
                   # column(width = 6, offset = 0, style='padding:0px;',
                   #        
                   # )
                   )
  ),
  
  # Body --------------------------------------------------------------------
  ##00828F;
  dashboardBody(    
    tags$head(tags$style(HTML('
                              
                              /* Separacion entre objetos */
                              .form-group {
                              margin-bottom: 0 !important;
                              }
                              
                              /* logo */
                              .skin-blue .main-header .logo {
                              background-color: #0070ba;
                              }
                              
                              /* logo when hove red */
                              .skin-blue .main-header .logo:hover {
                              background-color: #0F3D3F;
                              }
                              
                              # /* main sidebar */
                              # .skin-blue .main-sidebar {
                              # background-color: #0070ba;
                              # }
                              
                              /* navbar (rest of the header) */
                              .skin-blue .main-header .navbar {
                              background-color: #0070ba;
                              }
                              
                              /* body */
                              .content-wrapper, .right-side {
                              background-color: #FFFFFF;
                              }
                              
                              /* color para botones modales */
                                #modal1 button.btn.btn-default {
                                color: #fff; background-color: #0070ba; border-color: #0070ba
                                }
                              .content-wrapper{
                               margin-left: 270px;
                              }
                              .rhandsontable{
                               margin: 21px;
                              }
                              '
                              
    )
    )
    ), # Fin estilo
    
    
    # Paneles -----------------------------------------------------------------
    
    tabsetPanel( type = "tabs",           
                 tabPanel("Datos",
                          icon = icon("fas fa-table"),
                          hr(),
                          
                          fluidRow( 
                            box(#height = 420,
                              width = 12,
                              status = "warning",
                              solidHeader = FALSE,
                              title = "Indicadores de Gestión",
                              br()
                            )),
                          fluidRow(
                            column(width=6,plotlyOutput("plotIpMes", height = "200px"),rHandsontableOutput("TablaIpMes")),
                            column(width=6,plotlyOutput("plotIpAcum", height = "200px"),rHandsontableOutput("TablaIpAcum"))
                          ),
                          fluidRow(
                            column(width=6,plotlyOutput("plotIpTAM", height = "236px"),rHandsontableOutput("TablaIpTam"))
                          ),
                          fluidRow(
                            column(width=12,rHandsontableOutput("TablaNormalizaciones"))
                          ),
                          hr(),
                          useShinyjs(),
                          textOutput("GraficaIpMes"),
                          tags$head(tags$style("#GraficaIpMes{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaIpAcum"),
                          tags$head(tags$style("#GraficaIpAcum{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaIpTAM"),
                          tags$head(tags$style("#GraficaIpTAM{color: white;font-size: 20px;font-style: italic;}")),
                          textOutput("GraficaPerdidasTAM"),
                          tags$head(tags$style("#GraficaPerdidasTAM{color: white;font-size: 20px;font-style: italic;}"))
                 ),
                 tabPanel("Ind x Region",
                          icon = icon("fas fa-table"),
                          hr(),
                          
                          fluidRow( 
                            box(#height = 420,
                              width = 12,
                              status = "warning",
                              solidHeader = FALSE,
                              title = "Indicadores de Gestión",
                              br()
                            )),
                          fluidRow(
                            column(width=6,plotlyOutput("plotBarrasInspecciones")),
                            column(width=6,plotlyOutput("plotBarrasNormalizacion"))
                          ),
                          fluidRow(
                            column(width=6,plotlyOutput("plotBarrasEfectividadNorm")),
                            column(width=6,plotlyOutput("plotBarrasRecupero"))
                          ),
                          fluidRow(
                            column(width=6,plotlyOutput("plotBarrasSuministros")),
                            column(width=6,plotlyOutput("plotBarrasCNR"))
                          ),
                          textOutput("GraficaInspecciones"),
                          textOutput("GraficaNormalizacion"),
                          textOutput("GraficaEfectividadNorm"),
                          textOutput("GraficaRecupero"),
                          textOutput("GraficaSuministros"),
                          textOutput("GraficaCNR")
                          
                 ),
                 tabPanel("Acumulado",
                          icon = icon("fas fa-table"),
                          hr(),
                          fluidRow( 
                            box(#height = 420,
                              width = 12,
                              status = "warning",
                              solidHeader = FALSE,
                              title = "Indicadores de Gestión",
                              br()
                            )),
                          fluidRow(
                            column(width=6,plotlyOutput("plotBarrasIpAcumulado")),
                            column(width=6,plotlyOutput("plotBarrasBlindajeAcumulado"))
                          ),
                          fluidRow(
                            column(width=6,plotlyOutput("plotBarrasMayorVentaAcumulado")),
                            column(width=6,plotlyOutput("plotBarrasNormalizacionAcumulado"))
                          ),
                          textOutput("GraficaIpAcumulado"),
                          textOutput("GraficaBlindajeAcumulado"),
                          textOutput("GraficaMayorVentaAcumulado"),
                          textOutput("GraficaNormalizacionAcumulado")
                          
                 ),
                 tabPanel("Ayuda",
                          icon = icon("fas fa-table"),
                          includeMarkdown("Ayuda.Rmd")
                          
                 ),
                 id="TabsApp"
    )
  )
  #   ,tags$script(
  #     '
  # setTimeout(
  #   function() {
  #     HTMLWidgets.find("#datos").hot.addHook(
  #       "afterColumnSort",
  #       function(){
  #         console.log("sort",this);
  #         Shiny.onInputChange(
  #           "datos_sort",
  #           {
  #             data: this.getData()
  #           }
  #         )
  #       }
  #     )
  #   },
  #   1000
  # )
  # ' 
  #   
  #   )
  
)

# Server ------------------------------------------------------------------

server <- shinyServer(function(input, output, session) { # Importante iniciar con shinyServer para que funcione la ayuda
  
  consulta.activa <<- FALSE
  datos.consulta <- NA
  tipo.grafica <- 'P'
  tabla.datos.valida <- FALSE
  valores_validos_zona <<- NA
  valores_validos_region <<- NA
  valores_validos_centro <<- NA
  valores_validos_Geografia_departamento  <<- NA
  valores_validos_Geografia_municipio <<- NA
  
  valores_validos_estado <<- NA
  valores_validos_tarifa <<- NA
  valores_validos_mercado <<- NA
  
  # Ocultar Botones auxiliares para sincronizar paneles, paneles
  shinyjs::hide("MostrarTabla")
  shinyjs::hide("MostrarMapa")
  
  
  
  
  # Ayuda -------------------------------------------------------------------
  
  
  # Cambio de tab ----------------------------------------------------------------------
  observeEvent(input$TabsApp, {
    
    if (input$TabsApp == "Datos") {
      tabla.datos.valida <<- TRUE
    } else if (input$TabsApp == "Mapa") {
      click("MostrarMapa")
    }
  }, ignoreInit = TRUE)
  
  
  # Seleccion de fila en tabla de datos --------------------------------------------------
  observeEvent(
    input$datos_sort
    ,{
      
      xyz <<- input$datos_sort$data
    }
  )
  

  # Carga de datos a listas desplegables
  manejarEventosFiltros(input, output, session)
  
  # Reinicial controles
  manejarReinicioFiltros(input, output, session)
  
  # Hacer consulta basada en valores de filtros  ---------------------------
  observeEvent(input$TraerDatos, {
    noHayValores <- FALSE
    #meses_busqueda <- input$mesesRevisar
    #fecha_minimo <- today() %m-% months(meses_busqueda)
    #fecha_minimo <- paste0(substring(fecha_minimo,1,4),substring(fecha_minimo,6,7),"01")
    condiciones_consulta = " 1>0 " #paste0(" LlaveFecha >= ", fecha_minimo, " ")
    
    if(!is.null(input$zona_comercial)){
      # Construir condiciones de consulta:
      if (seleccion_operativa != "no") {
        if (nrow(valores_validos) == 0) {
          noHayValores <- TRUE
        } else { 
          
          #f1 <- substr(gsub("[\r\n]", "",paste0(unique(valores_validos[c("LlaveZona")]), collapse=",")),1,stop =1000000L)
          valores_validos <- consulta_zona(seleccion_operativa, valores_ZonaOperativa,input)
          
          f1 <- t(unique(valores_validos[c("LlaveZona")]))
          f1 <- paste0(apply(f1, 1, function(x) paste0(x)), collapse=",")
          #f1 <- paste0(gsub(":",",",unique(valores_validos[c("LlaveZona")])), collapse=",")
          f1 <- str_replace(f1, "[(]", "")
          f1 <- str_replace(f1, "[c]", "")
          f1 <- str_replace(f1, "[)]", "")
          # condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
          #                                                  " AND l.Llavezona IN ( ",substr(f1,1,stop =1000000L)," ) ") )
          condiciones_consulta <- gsub("[\r\n]", "",paste0(condiciones_consulta,
                                                           " AND REGION IN (select z.CodigoRegion from Dimension.Zona z WHERE z.LlaveZona IN ( ",substr(f1,1,stop =1000000L),")) "))
        }
      }
    }

    
    
    
    # traer valores de ceros
    
    if (noHayValores) {
      showModal(modalDialog(
        title = tags$p(tags$span(tags$img(src="save.svg" ,alt="", width="24" ,height="24"),tags$strong("No hay resultados"),style="color: #0070ba"),style="text-align: center;"),
        
        "La consulta no genera resultados",
        footer = list(modalButton("Cancelar", icon = icon("fas fa-table"))
        ),
        easyClose =TRUE
      )
      )
    }  else {

      
      disable("ReiniciarControles")  
      disable("TraerDatos")
      config <- config::get(config=configuracion.conexion)
      config.conexion <- config$conexion
      conexion <- odbcDriverConnect (config.conexion)
      
      #IpMes
      cad.sql<-paste0("SELECT 
                      	IdMes,
                      	Valor
                      from Hecho.Indicador2Data
                      where ",condiciones_consulta," AND Indicador = 'IP MES' and Tipo like '%Real%' order by IdMes ASC")
      datos.consultaIpMes <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT 
                      	IdMes,
                      	Valor
                      from Hecho.Indicador2Data
                      where ",condiciones_consulta," AND Indicador = 'IP MES' and Tipo like '%Meta%'  order by IdMes ASC")
      datos.consultaIpMesMeta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      #Acum
      cad.sql<-paste0("SELECT 
                      	IdMes,
                      	Valor
                      from Hecho.Indicador2Data
                      where ",condiciones_consulta," AND Indicador = 'IP ACUM' and Tipo like '%Real%' order by IdMes ASC")
      datos.consultaIpAcum <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT 
                      	IdMes,
                      	Valor
                      from Hecho.Indicador2Data
                      where ",condiciones_consulta," AND Indicador = 'IP ACUM' and Tipo like '%Meta%'  order by IdMes ASC")
      datos.consultaIpAcumMeta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      
      #TAM
      cad.sql<-paste0("SELECT 
                      	IdMes,
                      	Valor
                      from Hecho.Indicador2Data
                      where ",condiciones_consulta," AND Indicador = 'IP TAM' and Tipo like '%Real%' order by IdMes ASC")
      datos.consultaIpTAM <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT 
                      	IdMes,
                      	Valor
                      from Hecho.Indicador2Data
                      where ",condiciones_consulta," AND Indicador = 'IP TAM' and Tipo like '%Meta%'  order by IdMes ASC")
      datos.consultaIpTAMMeta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      #Indicadores
      cad.sql<-paste0("SELECT
                        metaCliente.Indicador,
                        CAST(metaCliente.Meta as INTEGER) as MetaClientes,
                        CAST(realCliente.Real as INTEGER) as Realclientes,
                        CAST((realCliente.Real * 100) / metaCliente.Meta as INTEGER) as AvanceClientes,
                        CAST(metaMasivos.Meta as INTEGER) as MetaMasivos,
                        CAST(realMasivos.Real as INTEGER) as RealMasivos,
                        CAST((realMasivos.Real * 100) / metaMasivos.Meta as INTEGER) as AvanceMasivos,
                        CAST(metaPIMT.Meta as INTEGER) as MetaPIMT,
                        CAST(realPIMT.Real as INTEGER) as RealPIMT,
                        CAST((realPIMT.Real * 100) / metaPIMT.Meta as INTEGER) as AvancePIMT,
                        CAST((metaCliente.Meta + metaMasivos.Meta + metaPIMT.Meta) as INTEGER) as TotalMeta,
                        CAST((realCliente.Real + realMasivos.Real + realPIMT.Real) as INTEGER) as TotalReal,
                        CAST(((realCliente.Real + realMasivos.Real + realPIMT.Real) * 100) / (metaCliente.Meta + metaMasivos.Meta + metaPIMT.Meta) as INTEGER) as TotalAvance
                        from
                        (
                        SELECT 
                        Indicador,
                        Operativa,
                        Tipo,
                        sum(Valor) as Meta
                        from Hecho.Indicador2Data
                        where Indicador in ('Normalizaciones','Mayor Venta') and Operativa like '%Clientes%' and Tipo like '%Meta%'
                        GROUP by Indicador,Tipo,Operativa) metaCliente LEFT JOIN 
                        (
                        SELECT 
                        Indicador,
                        Operativa,
                        Tipo,
                        sum(Valor) as Real
                        from Hecho.Indicador2Data
                        where Indicador in ('Normalizaciones','Mayor Venta') and Operativa like '%Clientes%' and Tipo like '%Real%'
                        GROUP by Indicador,Tipo,Operativa) realCliente on metaCliente.Indicador = realCliente.Indicador LEFT JOIN
                        (
                        SELECT 
                        Indicador,
                        Operativa,
                        Tipo,
                        sum(Valor) as Meta
                        from Hecho.Indicador2Data
                        where Indicador in ('Normalizaciones','Mayor Venta') and Operativa like '%Masivos%' and Tipo like '%Meta%'
                        GROUP by Indicador,Tipo,Operativa) metaMasivos on realCliente.Indicador = metaMasivos.Indicador LEFT JOIN
                        (
                        SELECT 
                        Indicador,
                        Operativa,
                        Tipo,
                        sum(Valor) as Real
                        from Hecho.Indicador2Data
                        where Indicador in ('Normalizaciones','Mayor Venta') and Operativa like '%Masivos%' and Tipo like '%Real%'
                        GROUP by Indicador,Tipo,Operativa) realMasivos on realMasivos.Indicador = metaMasivos.Indicador LEFT JOIN
                        (
                        SELECT 
                        Indicador,
                        Operativa,
                        Tipo,
                        sum(Valor) as Meta
                        from Hecho.Indicador2Data
                        where Indicador in ('Normalizaciones','Mayor Venta') and Operativa like '%PIMT%' and Tipo like '%Meta%'
                        GROUP by Indicador,Tipo,Operativa) metaPIMT on realCliente.Indicador = metaPIMT.Indicador LEFT JOIN
                        (
                        SELECT 
                        Indicador,
                        Operativa,
                        Tipo,
                        sum(Valor) as Real
                        from Hecho.Indicador2Data
                        where Indicador in ('Normalizaciones','Mayor Venta') and Operativa like '%PIMT%' and Tipo like '%Real%'
                        GROUP by Indicador,Tipo,Operativa) realPIMT on realPIMT.Indicador = metaPIMT.Indicador")
      datos.consultaIndicador <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      ################ graficos de barras segundo Tab #####################
      
      #Inspecciones
      cad.sql<-paste0("SELECT 
                          IdMes,
                          CAST(sum(Valor) as INTEGER) as Valor
                          from Hecho.Indicador3DataRegion
                          where ",condiciones_consulta," AND Indicador LIKE '%Inspeccion%' and Tipo LIKE '%Real%'
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaInspecciones <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT 
                          IdMes,
                          CAST(sum(Valor) as INTEGER) as Valor
                          from Hecho.Indicador3DataRegion
                          where ",condiciones_consulta," AND Indicador LIKE '%Inspeccion%' and Tipo LIKE '%Meta%'
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaInspeccionesMeta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      
      #Normalizaciones - barras
      cad.sql<-paste0("SELECT 
                          IdMes,
                          CAST(sum(Valor) as INTEGER) as Valor
                          from Hecho.Indicador3DataRegion
                          where ",condiciones_consulta," AND Indicador LIKE '%Normalizacion%' and Tipo LIKE '%Real%'
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaNormalizacion <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT 
                          IdMes,
                          sum(Valor) as Valor
                          from Hecho.Indicador3DataRegion
                          where ",condiciones_consulta," AND Indicador LIKE '%Normalizacion%' and Tipo LIKE '%Meta%'
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaNormalizacionMeta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      #Recupero - barras
      cad.sql<-paste0("SELECT 
                          IdMes,
                          CAST(sum(Valor) as INTEGER) as Valor
                          from Hecho.Indicador3DataRegion
                          where ",condiciones_consulta," AND Indicador LIKE '%Recupero de Energ%' and Tipo LIKE '%Real%'
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaRecupero <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT 
                          IdMes,
                          CAST(sum(Valor) as INTEGER) as Valor
                          from Hecho.Indicador3DataRegion
                          where ",condiciones_consulta," AND Indicador LIKE '%Recupero de Energ%' and Tipo LIKE '%Meta%'
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaRecuperoMeta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      #Suministros Eventuales - barras
      cad.sql<-paste0("SELECT 
                          IdMes,
                          CAST(sum(Valor) as INTEGER) as Valor
                          from Hecho.Indicador3DataRegion
                          where ",condiciones_consulta," AND Indicador LIKE '%Eventuales%' and Tipo LIKE '%Real%'
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaEventuales <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT 
                          IdMes,
                          CAST(sum(Valor) as INTEGER) as Valor
                          from Hecho.Indicador3DataRegion
                          where ",condiciones_consulta," AND Indicador LIKE '%Eventuales%' and Tipo LIKE '%Meta%'
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaEventualesMeta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      #CNRs - barras
      cad.sql<-paste0("SELECT 
                          IdMes,
                          CAST(sum(Valor) as INTEGER) as Valor
                          from Hecho.Indicador3DataRegion
                          where ",condiciones_consulta," AND Indicador LIKE '%CNR%' and Tipo LIKE '%Real%'
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaCNR <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      cad.sql<-paste0("SELECT 
                          IdMes,
                          CAST(sum(Valor) as INTEGER) as Valor
                          from Hecho.Indicador3DataRegion
                          where ",condiciones_consulta," AND Indicador LIKE '%CNR%' and Tipo LIKE '%Meta%'
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaCNRMeta <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      #Efectividad Normalización
      cad.sql<-paste0("SELECT 
                          IdMes,
                          CAST(sum(Valor) as INTEGER)  as Valor,
                          sum(Efectividad) as Efectividad
                          from Hecho.Indicador4Efectividad
                          where ",condiciones_consulta,"
                          group by IdMes ORDER by IdMes ASC")
      datos.consultaEfectividadNorm <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      ################ graficos de barras Tercer Tab #####################
      
      #IP Acumulado
      cad.sql<-paste0("SELECT
                          iptotal.Indicador,
                          iptotal.Valor as Valor,
                          iptotalMeta.Valor as Meta
                          from
                          (
                          select 
                            Indicador,
                            sum(Valor) as Valor
                          FROM 
                          Hecho.Indicador2Data
                          where ",condiciones_consulta," AND Indicador in('IP MES','IP TAM','IP ACUM') and Tipo like '%Real%' and IdMes BETWEEN 202201 AND 202212
                          group by Indicador
                          ) iptotal left join
                          (
                          select 
                          Indicador,
                          sum(Valor) as Valor
                          FROM 
                          Hecho.Indicador2Data
                          where ",condiciones_consulta," AND Indicador in('IP MES','IP TAM','IP ACUM') and Tipo like '%Meta%' and IdMes BETWEEN 202201 AND 202212
                          group by Indicador
                          ) iptotalMeta on iptotal.Indicador = iptotalMeta.Indicador")
      datos.consultaIpAcumulado <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      
      #Blindajes Acumulado
      cad.sql<-paste0("SELECT
                          blindaje.Operativa as Operativa,
                          blindaje.Valor as Valor,
                          blindajeMeta.Meta as Meta
                          FROM
                          (
                          SELECT
                          Operativa,
                          Indicador,
                          sum(Valor) as Valor
                          FROM 
                          Hecho.Indicador1DataAcumulada
                          where ",condiciones_consulta," AND Indicador like '%Blindaje%' and Tipo like '%Real%' and IdMes BETWEEN 202201 AND 202212
                          group by Operativa, Indicador
                          ) blindaje left JOIN 
                          (
                          SELECT
                          Operativa,
                          Indicador,
                          sum(Valor) as Meta
                          FROM 
                          Hecho.Indicador1DataAcumulada
                          where ",condiciones_consulta," AND Indicador like '%Blindaje%' and Tipo like '%Meta%' and IdMes BETWEEN 202201 AND 202212
                          group by Operativa, Indicador
                          ) blindajeMeta on blindajeMeta.Indicador = blindaje.Indicador")
      datos.consultaBlindajeAcumulado <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      ####### Mayor Venta Acumulado
      cad.sql<-paste0("SELECT 
                          mayorAcumulado.Operativa as Operativa,
                          mayorAcumulado.Valor as Valor,
                          mayorMetaAcumulado.Meta as Meta
                          from
                          (
                          select 
                          Indicador,
                          Operativa,
                          sum(Valor) as Valor
                          from
                          Hecho.Indicador1DataAcumulada
                          where ",condiciones_consulta," AND Indicador LIKE '%Mayor Venta%' and Tipo like '%Real%' AND IdMes BETWEEN 202201 AND 202212
                          GROUP by Operativa, Indicador
                          )mayorAcumulado LEFT JOIN
                          (
                          select 
                          Indicador,
                          Operativa,
                          sum(Valor) as Meta
                          from
                          Hecho.Indicador1DataAcumulada
                          where ",condiciones_consulta," AND Indicador LIKE '%Mayor Venta%' and Tipo like '%Meta%' AND IdMes BETWEEN 202201 AND 202212
                          GROUP by Operativa, Indicador
                          )mayorMetaAcumulado ON mayorAcumulado.Operativa = mayorMetaAcumulado.Operativa")
      datos.consultaMayorVentaAcumulado <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      ####### Normalizacion Acumulado
      cad.sql<-paste0("SELECT 
                          mayorAcumulado.Operativa as Operativa,
                          mayorAcumulado.Valor as Valor,
                          mayorMetaAcumulado.Meta as Meta
                          from
                          (
                          select 
                          Indicador,
                          Operativa,
                          sum(Valor) as Valor
                          from
                          Hecho.Indicador1DataAcumulada
                          where ",condiciones_consulta," AND Indicador LIKE '%Normalizacion%' and Tipo like '%Real%' AND IdMes BETWEEN 202201 AND 202212
                          GROUP by Operativa, Indicador
                          )mayorAcumulado LEFT JOIN
                          (
                          select 
                          Indicador,
                          Operativa,
                          sum(Valor) as Meta
                          from
                          Hecho.Indicador1DataAcumulada
                          where ",condiciones_consulta," AND Indicador LIKE '%Normalizacion%' and Tipo like '%Meta%' AND IdMes BETWEEN 202201 AND 202212
                          GROUP by Operativa, Indicador
                          )mayorMetaAcumulado ON mayorAcumulado.Operativa = mayorMetaAcumulado.Operativa")
      datos.consultaNormalizacionAcumulado <-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
      
      
      
      #Ip Mes
      datos.consultaIpMes <- data.frame(IdMes = datos.consultaIpMes$IdMes, Valor = datos.consultaIpMes$Valor ,stringsAsFactors=FALSE)
      dataSumIpMes <- datos.consultaIpMes %>% group_by(IdMes) %>% summarise(Valor = sum(as.double(Valor)))
      
      datos.consultaIpMesMeta <- data.frame(IdMes = datos.consultaIpMesMeta$IdMes, Valor = datos.consultaIpMesMeta$Valor ,stringsAsFactors=FALSE)
      dataSumIpMesMeta <- datos.consultaIpMesMeta %>% group_by(IdMes) %>% summarise(Valor = sum(as.double(Valor)))
      
      #Ip Acum
      datos.consultaIpAcum <- data.frame(IdMes = datos.consultaIpAcum$IdMes, Valor = datos.consultaIpAcum$Valor ,stringsAsFactors=FALSE)
      dataSumIpAcum <- datos.consultaIpAcum %>% group_by(IdMes) %>% summarise(Valor = sum(as.double(Valor)))
      
      datos.consultaIpAcumMeta <- data.frame(IdMes = datos.consultaIpAcumMeta$IdMes, Valor = datos.consultaIpAcumMeta$Valor ,stringsAsFactors=FALSE)
      dataSumIpAcumMeta <- datos.consultaIpAcumMeta %>% group_by(IdMes) %>% summarise(Valor = sum(as.double(Valor)))
      
      #Ip TAM
      datos.consultaIpTAM <- data.frame(IdMes = datos.consultaIpTAM$IdMes, Valor = datos.consultaIpTAM$Valor ,stringsAsFactors=FALSE)
      dataSumIpTAM <- datos.consultaIpTAM %>% group_by(IdMes) %>% summarise(Valor = sum(as.double(Valor)))
      
      datos.consultaIpTAMMeta <- data.frame(IdMes = datos.consultaIpTAMMeta$IdMes, Valor = datos.consultaIpTAMMeta$Valor ,stringsAsFactors=FALSE)
      dataSumIpTAMMeta <- datos.consultaIpTAMMeta %>% group_by(IdMes) %>% summarise(Valor = sum(as.double(Valor)))
      
      
      
      odbcClose(conexion)
      
      datos.consultaIpMes <- dataSumIpMes
      datos.consultaIpMesMeta <- dataSumIpMesMeta
      datos.consultaIpAcum <- dataSumIpAcum
      datos.consultaIpAcumMeta <- dataSumIpAcumMeta
      datos.consultaIpTAM <- dataSumIpTAM
      datos.consultaIpTAMMeta <- dataSumIpTAMMeta
      
      ############# IPMES ######################
      
      if (nrow(datos.consultaIpMes ) > 0) {
        
        #shinyjs::show('test')
        output$GraficaIpMes <- renderPrint({
          
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          entradas2021 <- datos.consultaIpMes$Valor[1:12]
          entradas2022 <- datos.consultaIpMes$Valor[13:24]
          meta <- datos.consultaIpMesMeta$Valor[1:12]
          
          data <- data.frame(month,entradas2021,entradas2022,meta,stringsAsFactors=FALSE)
          
          
          data$month <- factor(data$month, levels = data[["month"]])
          
          fig <- plot_ly(data, x = ~month, y = ~entradas2021, name = '2021', type = 'scatter', mode = 'lines+markers',line = list(color = 'rgb(98, 201, 239)', width = 2,showlegend = T))
          fig <- fig %>% add_trace(y = ~entradas2022, name = '2022', line = list(color = 'rgb(176, 176, 176)', width = 2,dash = 'dash'))
          fig <- fig %>% add_trace(y = ~meta, name = 'Meta', line = list(color = 'rgb(11, 210, 74)', width = 2))
          #fig <- fig %>% add_text(text=~entradas2021, textposition="top center", showlegend = F)
          fig <- fig %>% layout(title = "% Perdidas Mes",
                                xaxis = list(title = "Meses",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          fig <- fig %>% layout(yaxis = list(ticksuffix = "%"))
          
          fig <- fig %>% layout(showlegend = TRUE)
          output$plotIpMes <- renderPlotly({fig})
          
          
          #Tabla IpMes
          colnames(data) <- c('Año','2021','2022','Meta')
          newTable <- t(data)
          output$TablaIpMes <- renderRHandsontable({
            rhandsontable(newTable, height = 100, readOnly = TRUE)
          })
        })
        
        
      } else{
        disable("Guardar")                                  # Deshabilita el botón para guardar
        disable("Descargar")
        showModal(modalDialog(
          title = "La consulta no encuentra datos que cumplan.",
          footer = tags$div(id="modal1",modalButton("Cerrar")),
          easyClose = TRUE
        ))
      }
      
      ############# IP ACUM ######################
      
      if (nrow(datos.consultaIpAcum ) > 0) {
        
        #shinyjs::show('test')
        output$GraficaIpAcum <- renderPrint({
          
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          entradas2021 <- datos.consultaIpAcum$Valor[1:12]
          entradas2022 <- datos.consultaIpAcum$Valor[13:24]
          meta <- datos.consultaIpAcumMeta$Valor[1:12]
          
          data <- data.frame(month,entradas2021,entradas2022,meta,stringsAsFactors=FALSE)
          
          
          data$month <- factor(data$month, levels = data[["month"]])
          
          fig <- plot_ly(data, x = ~month, y = ~entradas2021, name = '2021', type = 'scatter', mode = 'lines+markers',line = list(color = 'rgb(98, 201, 239)', width = 2,showlegend = T))
          fig <- fig %>% add_trace(y = ~entradas2022, name = '2022', line = list(color = 'rgb(176, 176, 176)', width = 2,dash = 'dash'))
          fig <- fig %>% add_trace(y = ~meta, name = 'Meta', line = list(color = 'rgb(11, 210, 74)', width = 2))
          #fig <- fig %>% add_text(text=~entradas2021, textposition="top center", showlegend = F)
          fig <- fig %>% layout(title = "% Perdidas Acum",
                                xaxis = list(title = "Meses",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          fig <- fig %>% layout(yaxis = list(ticksuffix = "%"))
          
          fig <- fig %>% layout(showlegend = TRUE)
          output$plotIpAcum <- renderPlotly({fig})
          
          #Tabla IpAcum
          colnames(data) <- c('Año','2021','2022','Meta')
          newTable <- t(data)
          output$TablaIpAcum <- renderRHandsontable({
            rhandsontable(newTable, height = 100, readOnly = TRUE)
          })
          
        })
        
      } else{
        disable("Guardar")                                  # Deshabilita el botón para guardar
        disable("Descargar")
        showModal(modalDialog(
          title = "La consulta no encuentra datos que cumplan.",
          footer = tags$div(id="modal1",modalButton("Cerrar")),
          easyClose = TRUE
        ))
      }
      
      
      
      ############# IP TAM ######################
      
      if (nrow(datos.consultaIpTAM ) > 0) {
        
        #shinyjs::show('test')
        output$GraficaIpTAM <- renderPrint({
          
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          entradas2021 <- datos.consultaIpTAM$Valor[1:12]
          entradas2022 <- datos.consultaIpTAM$Valor[13:24]
          meta <- datos.consultaIpTAMMeta$Valor[1:12]
          
          data <- data.frame(month,entradas2021,entradas2022,meta,stringsAsFactors=FALSE)
          
          
          data$month <- factor(data$month, levels = data[["month"]])
          
          fig <- plot_ly(data, x = ~month, y = ~entradas2021, name = '2021', type = 'scatter', mode = 'lines+markers',line = list(color = 'rgb(98, 201, 239)', width = 2,showlegend = T))
          fig <- fig %>% add_trace(y = ~entradas2022, name = '2022', line = list(color = 'rgb(176, 176, 176)', width = 2,dash = 'dash'))
          fig <- fig %>% add_trace(y = ~meta, name = 'Meta', line = list(color = 'rgb(11, 210, 74)', width = 2))
          #fig <- fig %>% add_text(text=~entradas2021, textposition="top center", showlegend = F)
          fig <- fig %>% layout(title = "% Perdidas TAM",
                                xaxis = list(title = "Meses",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          fig <- fig %>% layout(yaxis = list(ticksuffix = "%"))
          
          fig <- fig %>% layout(showlegend = TRUE)
          output$plotIpTAM <- renderPlotly({fig})
          
          #Tabla IpTAM
          colnames(data) <- c('Año','2021','2022','Meta')
          newTable <- t(data)
          output$TablaIpTam <- renderRHandsontable({
            rhandsontable(newTable, height = 100, readOnly = TRUE)
          })
          
        })
        
      }
      
      
      ############# Tabla normalizacion y mayorventa ############
      
      output$TablaNormalizaciones <- renderRHandsontable({
        rhandsontable(datos.consultaIndicador, readOnly = TRUE) %>%
          hot_cols(renderer = "
           function (instance, td, row, col, prop, value, cellProperties) {
             Handsontable.renderers.TextRenderer.apply(this, arguments);
             if(col == 3 || col == 6 || col == 9 || col == 12){
               if (value < 95) {
                td.innerHTML = `<i class='fas fa-arrow-alt-circle-down' style='color:#ff0000'></i> <b>${value}%</b>` 
               } else if (value >= 100) {
                td.innerHTML = `<i class='fas fa-arrow-alt-circle-up' style='color:#009933'></i> <b>${value}%</b>` 
               }
            }}")
      })
      
      
      
      
      
      #################### Graficos de barras indicadores x Region ###########################
      if(nrow(datos.consultaInspecciones) > 0 ){
        
        output$GraficaInspecciones <- renderPrint({
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          valor <- datos.consultaInspecciones$Valor[1:12]
          meta <- datos.consultaInspeccionesMeta$Valor[1:12]
          
          data <- data.frame(month,valor,meta,stringsAsFactors=FALSE)
          
          
          data$month <- factor(data$month, levels = data[["month"]])
          
          fig <- plot_ly(data, x = ~month, y = ~valor, name = '2022', type = 'bar', showlegend = T)
          fig <- fig %>% add_trace(y = ~meta, name = 'Meta',marker = list(color = 'rgb(75,166,255)'))
          #fig <- fig %>% add_text(text=~meta, textposition="top center", showlegend = F,tickangle = 270)
          fig <- fig %>% layout(title = "Inspecciones",
                                xaxis = list(title = "",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
          fig <- fig %>% layout(showlegend = TRUE)
          output$plotBarrasInspecciones <- renderPlotly({fig})
        })
      }
      
      
      ###### Normalizaciones
      if(nrow(datos.consultaNormalizacion) > 0 ){
        
        output$GraficaNormalizacion <- renderPrint({
            month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                       'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
            
            valor <- datos.consultaNormalizacion$Valor[1:12]
            meta <- datos.consultaNormalizacionMeta$Valor[1:12]
            
            data <- data.frame(month,valor,meta,stringsAsFactors=FALSE)
            
            
            data$month <- factor(data$month, levels = data[["month"]])
            
            fig <- plot_ly(data, x = ~month, y = ~valor, name = '2022', type = 'bar', showlegend = T)
            fig <- fig %>% add_trace(y = ~meta, name = 'Meta',marker = list(color = 'rgb(75,166,255)'))
            #fig <- fig %>% add_text(text=~meta, textposition="top center", showlegend = F,tickangle = 270)
            fig <- fig %>% layout(title = "Normalizaciones",
                                  xaxis = list(title = "",dtick = "M1",tickangle = 270),
                                  yaxis = list (title = ""),
                                  font = list(color = "#0070ba"))
            
            fig <- fig %>% layout(showlegend = TRUE)
            output$plotBarrasNormalizacion <- renderPlotly({fig})
        })
      }
      
      ###### Efectividad Normalizacion
      if(nrow(datos.consultaEfectividadNorm) > 0 ){
        
        output$GraficaEfectividadNorm <- renderPrint({
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          valor <- datos.consultaEfectividadNorm$Valor[1:12]
          Efectividad <- as.numeric(datos.consultaEfectividadNorm$Efectividad[1:12]) * 100
          
          data <- data.frame(month,valor,Efectividad,stringsAsFactors=FALSE)
          
          
          data$month <- factor(data$month, levels = data[["month"]])
          
          fig <- plot_ly(data, x = ~month, y = ~valor, name = 'Valor', type = 'bar', showlegend = T)
          fig <- fig %>% add_trace(data, x = ~month, y = ~Efectividad, name = 'Efectividad', type = 'scatter',  mode = 'lines+markers')
          #fig <- fig %>% add_text(text=~meta, textposition="top center", showlegend = F,tickangle = 270)
          fig <- fig %>% layout(title = "Efectividad Normalización",
                                xaxis = list(title = "",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
          fig <- fig %>% layout(showlegend = TRUE)
          output$plotBarrasEfectividadNorm <- renderPlotly({fig})
        })
      }
      
      ###### REcupero
      if(nrow(datos.consultaRecupero) > 0 ){
        
        output$GraficaRecupero <- renderPrint({
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          valor <- datos.consultaRecupero$Valor[1:12]
          meta <- datos.consultaRecuperoMeta$Valor[1:12]
          
          data <- data.frame(month,valor,meta,stringsAsFactors=FALSE)
          
          
          data$month <- factor(data$month, levels = data[["month"]])
          
          fig <- plot_ly(data, x = ~month, y = ~valor, name = '2022', type = 'bar', showlegend = T)
          fig <- fig %>% add_trace(y = ~meta, name = 'Meta',marker = list(color = 'rgb(75,166,255)'))
          #fig <- fig %>% add_text(text=~meta, textposition="top center", showlegend = F,tickangle = 270)
          fig <- fig %>% layout(title = "Recupero Energia (Mvh)",
                                xaxis = list(title = "",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
          fig <- fig %>% layout(showlegend = TRUE)
          output$plotBarrasRecupero <- renderPlotly({fig})
        })
      }
      
      ###### Suministros
      if(nrow(datos.consultaEventuales) > 0 ){
        
        output$GraficaSuministros <- renderPrint({
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          valor <- datos.consultaEventuales$Valor[1:12]
          meta <- datos.consultaEventualesMeta$Valor[1:12]
          
          data <- data.frame(month,valor,meta,stringsAsFactors=FALSE)
          
          
          data$month <- factor(data$month, levels = data[["month"]])
          
          fig <- plot_ly(data, x = ~month, y = ~valor, name = '2022', type = 'bar', showlegend = T)
          fig <- fig %>% add_trace(y = ~meta, name = 'Meta',marker = list(color = 'rgb(75,166,255)'))
          #fig <- fig %>% add_text(text=~meta, textposition="top center", showlegend = F,tickangle = 270)
          fig <- fig %>% layout(title = "Suministros Eventuales (Mvh)",
                                xaxis = list(title = "",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
          fig <- fig %>% layout(showlegend = TRUE)
          output$plotBarrasSuministros <- renderPlotly({fig})
        })
      }
      
      ###### CNR
      if(nrow(datos.consultaCNR) > 0 ){
        
        output$GraficaCNR <- renderPrint({
          month <- c('Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul',
                     'Ago', 'Sep', 'Oct', 'Nov', 'Dic')
          
          valor <- datos.consultaCNR$Valor[1:12]
          meta <- datos.consultaCNRMeta$Valor[1:12]
          
          data <- data.frame(month,valor,meta,stringsAsFactors=FALSE)
          
          
          data$month <- factor(data$month, levels = data[["month"]])
          
          fig <- plot_ly(data, x = ~month, y = ~valor, name = '2022', type = 'bar', showlegend = T)
          fig <- fig %>% add_trace(y = ~meta, name = 'Meta',marker = list(color = 'rgb(75,166,255)'))
          #fig <- fig %>% add_text(text=~meta, textposition="top center", showlegend = F,tickangle = 270)
          fig <- fig %>% layout(title = "CNR's (Mvh)",
                                xaxis = list(title = "",dtick = "M1",tickangle = 270),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          
          fig <- fig %>% layout(showlegend = TRUE)
          output$plotBarrasCNR<- renderPlotly({fig})
        })
      }
      
      
      ############ Graficos barras Acumulado ####################
      
      ###### IP #######
      if(nrow(datos.consultaIpAcumulado) > 0 ){
        
        output$GraficaIpAcumulado <- renderPrint({

          valor <- round(as.numeric(datos.consultaIpAcumulado$Valor), digits = 2)
          meta <- datos.consultaIpAcumulado$Meta
          indicador <- datos.consultaIpAcumulado$Indicador
          
          data <- datos.consultaIpAcumulado
          
          fig <- plot_ly(data, x = ~valor, y = ~indicador, name = '2022', type = 'bar', orientation='h', showlegend = T)
          fig <- fig %>% add_trace(x = ~meta, name = 'Meta',marker = list(color = 'rgb(75,166,255)'))
          #fig <- fig %>% add_text(text=~meta, textposition="top center", showlegend = F,tickangle = 270)
          fig <- fig %>% layout(title = "IP",
                                xaxis = list(title = "", zeroline = FALSE, showline = FALSE, showticklabels = TRUE, showgrid = TRUE),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          fig <- fig %>% layout(xaxis = list(ticksuffix = "%"))
          fig <- fig %>% layout(showlegend = TRUE)
          output$plotBarrasIpAcumulado <- renderPlotly({fig})
        })
      }
      
      ###### Blindaje #######
      if(nrow(datos.consultaBlindajeAcumulado) > 0 ){
        
        output$GraficaBlindajeAcumulado <- renderPrint({
          
          data <- datos.consultaBlindajeAcumulado
          
          valor <- round(as.numeric(data$Valor), digits = 2)
          meta <- round(as.numeric(data$Meta), digits = 2)
          operativa <- data$Operativa
          
          
          fig <- plot_ly(data, x = ~valor, y = ~operativa, name = '2022', type = 'bar', orientation = 'h', showlegend = T)
          fig <- fig %>% add_trace(x = ~meta, name = 'Meta',marker = list(color = 'rgb(75,166,255)'))
          #fig <- fig %>% add_text(text=~valor, showlegend = T)
          fig <- fig %>% layout(title = "Blindajes",
                                xaxis = list(title = "", zeroline = FALSE, showline = FALSE, showticklabels = TRUE, showgrid = TRUE),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          #fig <- fig %>% layout(xaxis = list(ticksuffix = "%"))
          #fig <- fig %>% layout(showlegend = TRUE)
          output$plotBarrasBlindajeAcumulado <- renderPlotly({fig})
        })
      }
      
      ###### MayorVenta Acumulado #######
      
      if(nrow(datos.consultaMayorVentaAcumulado) > 0 ){
        
        output$GraficaMayorVentaAcumulado <- renderPrint({
          
          data <- datos.consultaMayorVentaAcumulado
          
          valor <- round(as.numeric(data$Valor), digits = 2)
          meta <- round(as.numeric(data$Meta), digits = 2)
          operativa <- data$Operativa
          
          
          fig <- plot_ly(data, x = ~valor, y = ~operativa, name = '2022', type = 'bar', orientation = 'h', showlegend = T)
          fig <- fig %>% add_trace(x = ~meta, name = 'Meta',marker = list(color = 'rgb(75,166,255)'))
          #fig <- fig %>% add_text(text=~valor, showlegend = T)
          fig <- fig %>% layout(title = "Mayor Venta",
                                xaxis = list(title = "", zeroline = FALSE, showline = FALSE, showticklabels = TRUE, showgrid = TRUE),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          #fig <- fig %>% layout(xaxis = list(ticksuffix = "%"))
          #fig <- fig %>% layout(showlegend = TRUE)
          output$plotBarrasMayorVentaAcumulado <- renderPlotly({fig})
        })
      }
      
      
      ###### Normalizacion Acumulado #######
      
      if(nrow(datos.consultaNormalizacionAcumulado) > 0 ){
        
        output$GraficaNormalizacionAcumulado <- renderPrint({
          
          data <- datos.consultaMayorVentaAcumulado
          
          valor <- round(as.numeric(data$Valor), digits = 2)
          meta <- round(as.numeric(data$Meta), digits = 2)
          operativa <- data$Operativa
          
          
          fig <- plot_ly(data, x = ~valor, y = ~operativa, name = '2022', type = 'bar', orientation = 'h', showlegend = T)
          fig <- fig %>% add_trace(x = ~meta, name = 'Meta',marker = list(color = 'rgb(75,166,255)'))
          #fig <- fig %>% add_text(text=~valor, showlegend = T)
          fig <- fig %>% layout(title = "Normalizaciónes",
                                xaxis = list(title = "", zeroline = FALSE, showline = FALSE, showticklabels = TRUE, showgrid = TRUE),
                                yaxis = list (title = ""),
                                font = list(color = "#0070ba"))
          #fig <- fig %>% layout(xaxis = list(ticksuffix = "%"))
          #fig <- fig %>% layout(showlegend = TRUE)
          output$plotBarrasNormalizacionAcumulado <- renderPlotly({fig})
        })
      }
      
      shinyjs::enable("ReiniciarControles")
      shinyjs::enable("TraerDatos")
    }
    
  }, ignoreInit = TRUE)
  
  
})



# Ejecutar aplicación -----------------------------------------------------


shinyApp(ui = ui, server = server)