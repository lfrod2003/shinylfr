# =============================================================================
#                             Helpers Hoja de vida
# =============================================================================
# 
# Autor:                Nelson Beltrán Celis
# Fecha de creación:    08.04.2020
# Descripción:
#
# Permite visualizar datos de detalle para cada punto de consumo  que son tomados
# de la base de datos mediante la ejecucion de diferentes procedimientos almacenados.
#
# =============================================================================

# Parametros --------------------------------------------------------------

# Ninguno

# Librerias utilizadas ----------------------------------------------------

library(RODBC)
library(RODBCext)
library(config)
library(strucchange) 
library(shiny)
library(plotly)
library(ggplot2)
library(plyr)

# PuntoCons = 482331


# Funciones ---------------------------------------------------------------

# Cadena para ejecución en Windows:
#cadena.conexion <- "driver={SQL Server};server=192.168.56.1\\SQL2017;database=DWSRBI_Huila;Uid=profesional.BI;Pwd=123Canea7;trustedconnection=true" 
config <- config::get(config='windows')
cadena.conexion <- config$conexion

# Preparar texto svg para gráfica de consumo 12 meses en popup  -----------------
texto.popup <- function(l) {
  l[is.na(l)] <- 0  # reemplazar NA por 0
  x0 <- 2
  espacio.vertical = 48
  y0 <- ceiling(max(l))
  escala.vertical = 48 / y0
  colwidth <- 5
  xwidth <- 8
  texto.svg <- ""
  for (i in 1:length(l)) 
  {
    colheight = ceiling(l[i]*escala.vertical)
    texto.svg <- paste0(texto.svg,"<rect y='", espacio.vertical-colheight
                        ,"' x='",x0 + xwidth*(i-1),"' height='",colheight ,"' width='5'"
                        ," style='opacity:1;fill:#008b8a;stroke:#008b8a;' />")
  }
  texto.svg
}

# Retornar mapa vacío ----------------------------------------------------------
mapa.vacio<- function(){
  
  #conexion <- odbcDriverConnect ("driver={SQL Server};server=192.168.56.1\\SQL2017;database=DWSRBI_Huila;Uid=profesional.bi;Pwd=123Canea7;trustedconnection=true" )
  config <- config::get(config=configuracion.conexion)
  conexion <- odbcDriverConnect(config$conexion)
  cad.sql<- "[dbo].[Lista_extremos_geografia]"
  datos.geo <- sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  odbcClose(conexion)
  names(datos.geo) <- c('lat','lon')
  datos.geo$lat <- as.numeric(datos.geo$lat)
  datos.geo$lon <- as.numeric(datos.geo$lon)
  # Retornar mapa de área operativa, sin usuarios
  google_map(key = api_key, location=c(datos.geo$lat, datos.geo$lon), zoom = 9,style=estilo.map01)
  
  
}


# 1. Traer datos comerciales -------------------------------------------------

trae.DatosCom <- function(PuntoCons,conexion) { # Utiliza el procedimiento almacenado "DatosComercialesHDV" para presentar informacion comercial
      cad.sql<-paste0("select 
                pc.CodigoPuntoConsumo 'Punto de consumo:',
                LatitudPuntoConsumo 'Latitud:',
                LongitudPuntoConsumo 'Longuitud:',
                pc.CodigoPuntoConsumo 'Nombre:',
                DireccionPuntoConsumo 'Dirección:',
                TipoPuntoConsumo 'Tipo:',
                NombreEstadoPuntoConsumo 'Estado:',
                z.NombreZona 'Zona:',
                z.NombreRegion 'Región:',
                z.CodigoCentro 'Centro:',
                g.NombreDepartamentoGeografia 'Departamento:',
                g.NombreMunicipioGeografia 'Municipio:',
                g.NombreLocalidadZonaGeografia 'Localidad'
            from Dimension.PuntoConsumo pc
                left join Hecho.Llaves l on l.codigoPuntoConsumo = pc.CodigoPuntoConsumo
                left join Dimension.Zona z on z.LlaveZona = l.llaveZona
                left join Dimension.Geografia g on g.LlaveGeografia = l.llaveGeografia
            where pc.CodigoPuntoConsumo =  ",PuntoCons);
    
    # Datos del Cliente 
    DataCliente<-sqlExecute(channel = conexion, query = cad.sql, fetch= T,as.is=T)
    
    DatosCom<-data.frame(
      "Nombre"=names(DataCliente),
      "Origen"=unlist(DataCliente[1,], use.names = FALSE)
    )
  DatosCom
}

# 2. Traer datos técnicos ----------------------------------------------------

trae.DatosTec <- function(PuntoCons,conexion) { # Utiliza el procedimiento almacenado "Perfil_Cliente" para presentar informacion comercial
  cad.sql<-paste0("select pc.CodigoPuntoConsumo 'Punto de consumo:',
                t.NombreTarifa 'Tarifa:',
                c.Nombrecircuito 'Circuito:',
                m.CodigoMedidor 'Medidor:',
                m.CodigoMarcaMedidor 'Marca:',
                m.CodigoModeloMedidor 'Modelo:',
                m.TensionNominalMedidor 'Tensión:'
            from Dimension.PuntoConsumo pc
                left join Hecho.Llaves l on l.codigoPuntoConsumo = pc.CodigoPuntoConsumo
                left join Dimension.Circuito c on c.LlaveCircuito = l.llaveCircuito
                left join Dimension.Medidor m on m.LlaveMedidor = l.llaveMedidor
                left join Dimension.Tarifa t on t.LlaveTarifa = l.llaveTarifa
            where pc.CodigoPuntoConsumo = ",PuntoCons);
  # Datos del Cliente 
  DataCliente<-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  DatosTec<-data.frame(
    "Nombre"=names(DataCliente),
    "Origen"=unlist(DataCliente[1,], use.names = FALSE)
  )
  
  DatosTec
  
}

# 3. Traer consumos ----------------------------------------------------------

trae.Consumo <- function(PuntoCons,conexion) {
  cad.sql<-paste0("select 
              ROW_NUMBER() OVER(ORDER BY cn.LlaveFecha ASC) AS Cons,
              pc.CodigoPuntoConsumo,
              cn.LlaveFecha,
              LEFT(cn.LlaveFecha, 6) Periodo,
              cn.EnergiaActivakWhCN EnergiaActivakWhFacturacion,
              cn.csmo_n ConsumoNormalizadoActivaCN,
              cn.PromedioActiva3CN,
              cn.PromedioActiva6CN,
              cn.PromedioActiva12CN,
              cn.csmo_d,
              cn.DiasFacturadosCN
          from Dimension.PuntoConsumo pc
              inner join Hecho.ConsumoNormalizado cn on pc.LlavePuntoConsumo = cn.LlavePuntoConsumo
          where cn.LlaveFecha > 0 and pc.CodigoPuntoConsumo =  ",PuntoCons,
          "ORDER BY Periodo")
  
  DataConsumo<-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

  DataConsumo$ConsumoNormalizadoActivaCN<-as.numeric(DataConsumo$ConsumoNormalizadoActivaCN)
  DataConsumo$EnergiaActivakWhFacturacion<-as.numeric(DataConsumo$EnergiaActivakWhFacturacion)

  DataConsumo
}

# 4. Traer lecturas ----------------------------------------------------------

trae.lecturas<-function(PuntoCons,conexion) {
  cad.sql<-paste0("select 
              ROW_NUMBER() OVER(ORDER BY cn.LlaveFecha ASC) AS Cons,
              pc.CodigoPuntoConsumo,
              cn.LlaveFecha,
              LEFT(cn.LlaveFecha, 6) Periodo,
              CAST(cn.EnergiaActivakWhCN as INTEGER)  'Energia kwh',
              CAST(CAST(ROUND(cn.csmo_n, 2) AS DECIMAL(20,2)) AS VARCHAR(20)) 'Consumo normalizado',
              CAST(CAST(ROUND(cn.PromedioActiva3CN, 2) AS DECIMAL(20,2)) AS VARCHAR(20)) 'Prom 3',
              CAST(CAST(ROUND(cn.PromedioActiva6CN, 2) AS DECIMAL(20,2)) AS VARCHAR(20)) 'Prom 6',
              CAST(CAST(ROUND(cn.PromedioActiva12CN, 2) AS DECIMAL(20,2)) AS VARCHAR(20)) 'Prom 12',
              CAST(CAST(ROUND(cn.csmo_d, 2) AS DECIMAL(20,2)) AS VARCHAR(20)) 'Consumo diario',
              cn.DiasFacturadosCN 'Días facturados'
          from Dimension.PuntoConsumo pc
              inner join Hecho.ConsumoNormalizado cn on pc.LlavePuntoConsumo = cn.LlavePuntoConsumo
          where cn.LlaveFecha > 0 and pc.CodigoPuntoConsumo = ",PuntoCons,
          "ORDER BY cn.LlaveFecha desc");

  # Datos del Cliente 
  DatosLect<-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  DatosLect
}


# 5. Traer datos del medidor -------------------------------------------------

trae.DatosMed<-function(PuntoCons,conexion){
    cad.sql<-paste0("select m.CodigoMedidor 'Medidor',
                  m.CodigoMarcaMedidor 'Marca',
                  m.TensionNominalMedidor 'Tensión nominal'
              from hecho.Llaves l
                  inner join Dimension.Medidor m on l.llaveMedidor = m.LlaveMedidor
                  INNER join Dimension.PuntoConsumo pc on l.llavePuntoConsumo = pc.LlavePuntoConsumo
              where pc.CodigoPuntoConsumo = ",PuntoCons);
   
    DatosMed<-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
    
    DatosMed
}

# 6. Traer datos de inspecciones ---------------------------------------------

trae.DatosInsp<-function(PuntoCons,conexion){
  cad.sql<-
    paste0("select 
          i.LlavePuntoConsumo,
          i.CodigoInspeccion,
          i.LlaveFechaCreacion,
          i.LlaveFechaEjecucion,
          i.AreaOrigenInspeccion,
          i.SolicitanteInspeccion,
          i.EstadoInspeccion,
          i.RepresentaPerdidaInspeccion,
          i.ObservacionInspeccion,
          i.ObservacionOrden,
          rc.NombreResultadoCNR,
          i.TipoInspeccion
      FROM Hecho.Inspeccion i 
          INNER JOIN Dimension.PuntoConsumo B ON B.LlavePuntoConsumo = i.LlavePuntoConsumo 
          INNER JOIN Dimension.ResultadoCNR rc ON i.llaveResultadoCNR = rc.LlaveResultadoCNR
          --	inner join Dimension.Actor a  on i.LlaveActor = a.LlaveActor 
          -- INNER join Dimension.Cliente c on i.LlaveCliente = c.LlaveCliente
      where B.LlavePuntoConsumo = ",PuntoCons);

  DatosInsp<-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)

  DatosInsp
}

trae.DatosAnomalias <-function(PuntoCons,conexion){
  cad.sql<- paste0(
    "select pc.CodigoPuntoConsumo,
          a.LlaveFecha 'Fecha',
          LEFT(a.LlaveFecha, 6) Periodo,
          a.CodigoInspeccionAnomalia 'Código',
          DescripcionAnomalia 'Anomalia',
          ObservacionAnomalia 'Observación'
      from hecho.Anomalia a
          INNER JOIN Dimension.PuntoConsumo pc ON a.LlavePuntoConsumo = pc.LlavePuntoConsumo
      where a.llaveFecha > 0 and pc.CodigoPuntoConsumo = ",PuntoCons,
    "order by a.llaveFecha");
  
  DatosAnomalias<-sqlExecute(channel = conexion, query = cad.sql,fetch= T,as.is=T)
  
  DatosAnomalias
}

# 7. Traer datos de corte y reconexion ------------------------------------

trae.DatosCorteReconexion<-function(PuntoCons,conexion){

  cad.sql<- paste0("select c.CodigoCorte,
              c.LlaveFecha 'Fecha',
              LEFT(c.LlaveFecha, 6) Periodo,
              c.Resultado 'Resultado',
              c.Motivo 'Motivo'
          from hecho.Corte c
              inner join Dimension.PuntoConsumo pc ON pc.LlavePuntoConsumo = c.LlavePuntoConsumo
          where c.LlaveFecha > 0 and pc.CodigoPuntoConsumo = ",PuntoCons); 

  DatosCorteReconexion<-sqlExecute(channel = conexion, query = cad.sql, fetch= T,as.is=T)
  
  DatosCorteReconexion<-DatosCorteReconexion[,-1]
}

# 8 .Traer informacion de contactos PQR -----------------------------------

trae.DatosPQR<-function(PuntoCons,conexion){

  cad.sql<-"EXEC [dbo].[PQRHDV] @CodPtoConNum = ?"
  
  DatosPQR<-sqlExecute(channel = conexion, query = cad.sql,PuntoCons,fetch= T,as.is=T)
  #odbcClose(conexion)
  
  DatosPQR<-DatosPQR[,-1]
}

# 9. Generar estadisticas de facturacion -------------------------------------

estadisticas.consumo<-function(DataConsumo){
  if(nrow(DataConsumo)>0){
    cant.facturas <- length(na.omit(DataConsumo$EnergiaActivakWhFacturacion))
    cant.ceros <- length(which(DataConsumo$EnergiaActivakWhFacturacion ==0))
    cons.min <- min(DataConsumo$EnergiaActivakWhFacturacion,na.rm = TRUE)
    cons.prom <- mean(DataConsumo$EnergiaActivakWhFacturacion,na.rm = TRUE)
    cons.med <- median(DataConsumo$EnergiaActivakWhFacturacion, na.rm = TRUE)
    cons.max <- max(DataConsumo$EnergiaActivakWhFacturacion,na.rm = TRUE)
    
    # Nota: sd calcula desviación de muestra, no de población. ver:
    # https://stackoverflow.com/questions/44339070/calculating-population-standard-deviation-in-r
    n.consumo <- nrow(DataConsumo)
    cons.sd <- sqrt((n.consumo-1)/n.consumo)  * sd(DataConsumo$EnergiaActivakWhFacturacion, na.rm = TRUE)
  }else{
    cant.facturas <- 0
    cant.ceros <- 0
    cons.min <- 0
    cons.prom <- 0
    cons.med <- 0
    cons.max <- 0
    cons.sd <- 0
  }
  
  if (is.nan(cons.prom) || cons.prom == 0){
    cons.cv<-0
    } 
  else {
    cons.cv<-sd(DataConsumo$EnergiaActivakWhFacturacion,na.rm = T)
    cons.cv<-100*(cons.cv/cons.prom)
  }
  
  estado<-data.frame( "variable" = c(
    'Facturas',
    'Cant. ceros',
    'Cons. min. [kWh]',
    'Cons. prom. [kWh]' ,
    'Cons. med. [kWh]',
    'Cons. max. [kWh]',
    'Desviación [kWh]',
    'Coef. var. [%]'
    ), "valor"= c(
    cant.facturas,
    cant.ceros, 
    cons.min,
    cons.prom,
    cons.med,
    cons.max,
    cons.sd,
    cons.cv
    )
    )

  estado$valor<-round(estado$valor,2)
  estado

}

# 10. Extraccion de datos -----------------------------------------------------

carga.datos<-function(PuntoCons){   # Funcion que consolida la extraccion
  
  #conexion <- odbcDriverConnect (cadena.conexion)
  config <- config::get(config=configuracion.conexion)
  config.conexion <- config$conexion
  conexion <- odbcDriverConnect (config.conexion)

  DatosCom<<-trae.DatosCom(PuntoCons,conexion) # Datos comerciales del Cliente (Incluye pos x,y)
  DatosTec<<-trae.DatosTec(PuntoCons,conexion) # Datos tecnicos del Cliente
  DatosCons<<-trae.Consumo(PuntoCons,conexion) # Datos de consumo del Cliente
  DatosLect<<-trae.lecturas(PuntoCons,conexion) # Datos de lecturas del Cliente
  DatosMed<<-trae.DatosMed(PuntoCons,conexion) # Datos de medidores
  
  DatosInsp<<-trae.DatosInsp(PuntoCons,conexion) # Datos de inspecciones
  
  DatosAnomalias<<-trae.DatosAnomalias(PuntoCons,conexion) # Datos de anomalias
  
  DatosCorteReconexion<<-trae.DatosCorteReconexion(PuntoCons,conexion) # Datos de corte y reconexion
  DatosPQR<<-trae.DatosPQR(PuntoCons,conexion) # Datos de contactos de PQR
  datos.map<<-data.frame(lat = DatosCom[2,2], lon = DatosCom[3,2], text = paste("Dir:",DatosCom[5,2]))
  DatosEst<<-estadisticas.consumo(DatosCons)  # Tabla de estadisticas de consumo

  odbcClose(conexion)
  
}
#odbcClose(conexion)

# 11. Convertir formato fecha AAAAMMDD a cadena -------------------------------

conv.fecha<-function(fecha.cad){
  paste0(
    substring(fecha.cad,1,4),
    "-",
    substring(fecha.cad,5,6),
    "-",
    substring(fecha.cad,7,8)
    )
}

# 12. Procesar Parámetro de código de cliente en URL ----------------------------
parse.URL<-function(session){
  
  query <- parseQueryString(session$clientData$url_search)
  
  if (length(query) > 0 ) {
    codigoCliente <- as.numeric(query[["Codigo"]])
    if (!is.na(codigoCliente && nchar(codigoCliente) > 0)) {
      
      if (codigoCliente != codigoClienteXURL ) {
        
        codigoClienteXURL <<- codigoCliente
        usarCodigoURL <<- TRUE
        
        click("actualiza")
      }
    }
    else {

      updateTextInput(session = session, inputId 	= "NumCliente", value = as.character(DatosCom[1,2]))
    }
  } 
}

# Estilo Aubergine mapa JSON ---------------------------------------------------

estilo.map01 <-
  
  '[
    {
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#8ec3b9"
        }
        ]
    },
    {
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1a3646"
        }
        ]
    },
    {
      "featureType": "administrative.country",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#4b6878"
        }
        ]
    },
    {
      "featureType": "administrative.land_parcel",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#64779e"
        }
        ]
    },
    {
      "featureType": "administrative.province",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#4b6878"
        }
        ]
    },
    {
      "featureType": "landscape.man_made",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#334e87"
        }
        ]
    },
    {
      "featureType": "landscape.natural",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#023e58"
        }
        ]
    },
    {
      "featureType": "poi",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#283d6a"
        }
        ]
    },
    {
      "featureType": "poi",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#6f9ba5"
        }
        ]
    },
    {
      "featureType": "poi",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "featureType": "poi.park",
      "elementType": "geometry.fill",
      "stylers": [
        {
          "color": "#023e58"
        }
        ]
    },
    {
      "featureType": "poi.park",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#3C7680"
        }
        ]
    },
    {
      "featureType": "road",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#304a7d"
        }
        ]
    },
    {
      "featureType": "road",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#98a5be"
        }
        ]
    },
    {
      "featureType": "road",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#2c6675"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "geometry.stroke",
      "stylers": [
        {
          "color": "#255763"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#b0d5ce"
        }
        ]
    },
    {
      "featureType": "road.highway",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#023e58"
        }
        ]
    },
    {
      "featureType": "transit",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#98a5be"
        }
        ]
    },
    {
      "featureType": "transit",
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#1d2c4d"
        }
        ]
    },
    {
      "featureType": "transit.line",
      "elementType": "geometry.fill",
      "stylers": [
        {
          "color": "#283d6a"
        }
        ]
    },
    {
      "featureType": "transit.station",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#3a4762"
        }
        ]
    },
    {
      "featureType": "water",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#0e1626"
        }
        ]
    },
    {
      "featureType": "water",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#4e6d70"
        }
        ]
    }
    ]'

# Estilo mapa Retro JSON  ------------------------------------------------------------

estilo.map02 <-

'[
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#ebe3cd"
      }
      ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#523735"
      }
      ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#f5f1e6"
      }
      ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#c9b2a6"
      }
      ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#dcd2be"
      }
      ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#ae9e90"
      }
      ]
  },
  {
    "featureType": "landscape.natural",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "poi",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#93817c"
      }
      ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#a5b076"
      }
      ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#447530"
      }
      ]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f5f1e6"
      }
      ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#fdfcf8"
      }
      ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f8c967"
      }
      ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#e9bc62"
      }
      ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#e98d58"
      }
      ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#db8555"
      }
      ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#806b63"
      }
      ]
  },
  {
    "featureType": "transit.line",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "transit.line",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#8f7d77"
      }
      ]
  },
  {
    "featureType": "transit.line",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#ebe3cd"
      }
      ]
  },
  {
    "featureType": "transit.station",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
      ]
  },
  {
    "featureType": "water",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#b9d3c2"
      }
      ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#92998d"
      }
      ]
  }
  ]'



